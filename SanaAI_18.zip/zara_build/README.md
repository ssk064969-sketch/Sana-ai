# Zara AI — Owner Sakib

This ZIP is an Android source project and GitHub Actions build setup. **It is not a completed 38-feature assistant.** The in-app 38-item list is a transparent status register, not a claim that every capability is active.

## Working in this source
- Gemini text chat over HTTPS using the `x-goog-api-key` header.
- Runtime API-key entry; there is no hard-coded prefix check, so a key beginning with `AQ`, `U`, or another prefix can be entered. The provider, not the app's text field, validates whether it is a real key.
- Hindi speech input using the Android speech-recognition service available on the phone.
- Hindi text-to-speech using the installed Android TTS engine.
- In-app status register for all 38 requested features, with honest `PARTIAL` / `NOT READY` states and notes.
- GitHub Actions workflow to build a debug APK.

## Gemini key safety
Paste the key you generated in Google AI Studio into the app. The app sends it in the `x-goog-api-key` header. The app does not invent, convert, or guarantee a key based on its first letters. Do not commit a real key to GitHub or share it in screenshots. This simple client stores the key in app preferences; for a public production app, use a protected backend rather than embedding a personal API key in a distributed APK.

## 38-feature status
Only the items marked `PARTIAL` have some implementation in this source. The other items are not active. Phone calls, WhatsApp automation, screen taps, notification access, screen capture, social posting, documents, email, market data, PC pairing and smart-home control need separate Android permissions, official provider APIs, companion apps, backend services, and/or physical-device tests. Android and third-party app policies also limit some actions. The status notes are in `app/src/main/java/com/zara/ai/FeatureCatalog.kt`.

## Build on GitHub
1. Create/open a GitHub repository.
2. Upload the **contents** of this ZIP (so `app/`, `build.gradle.kts`, `settings.gradle.kts`, and `.github/` are at the repository root).
3. Open **Actions → Build Zara AI APK → Run workflow**.
4. Download the `ZaraAI-debug-apk` artifact after the workflow succeeds.

## Verification performed here
- ZIP archive integrity check: performed.
- Source-level presence checks: performed.
- Android compilation: **not performed** (this environment has no Android SDK/Gradle installation).
- Physical phone test: **not performed**.

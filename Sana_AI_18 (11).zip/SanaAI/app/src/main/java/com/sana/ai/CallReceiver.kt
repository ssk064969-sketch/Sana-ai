package com.sana.ai

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.telephony.TelephonyManager

/** Call aane par Sana naam bolti hai (Sana chalu ho, contacts aur call-log ki anumati ho to). */
class CallReceiver : BroadcastReceiver() {
    companion object {
        @Volatile private var lastNumber = ""
        @Volatile private var lastNumberAt = 0L

        fun nameFor(c: Context, num: String): String? = try {
            if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) null
            else {
                val u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num))
                c.contentResolver.query(u, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(0) else null
                }
            }
        } catch (e: Exception) { null }
    }

    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val st = i.getStringExtra(TelephonyManager.EXTRA_STATE)
        if (st == TelephonyManager.EXTRA_STATE_IDLE || st == TelephonyManager.EXTRA_STATE_OFFHOOK) { Bus.ringing = false; return }
        if (st != TelephonyManager.EXTRA_STATE_RINGING) return
        Bus.ringing = true
        if (!SanaService.running) return
        val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
        val now = System.currentTimeMillis()
        if (num.isBlank()) {
            // ek ring par do broadcast aate hain (ek bina number ke): thoda ruk kar dekho number wala aaya ya nahi
            Handler(Looper.getMainLooper()).postDelayed({
                if (lastNumberAt < now && now - lastNumberAt > 4000) Bus.callAnnounce?.invoke("कोई कॉल आ रहा है")
            }, 1500)
            return
        }
        if (num == lastNumber && now - lastNumberAt < 8000) return
        lastNumber = num; lastNumberAt = now
        val name = nameFor(c, num)
        val msg = if (name != null) "$name का कॉल आ रहा है"
            else "एक अनजान नंबर से कॉल आ रहा है, आख़िरी चार अंक " + num.filter { it.isDigit() }.takeLast(4).toList().joinToString(" ")
        Bus.callAnnounce?.invoke(msg)
    }
}

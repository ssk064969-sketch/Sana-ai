package com.sana.ai

import android.graphics.*
import android.os.Build
import android.view.View
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.sin

/** Aedwans (Advance) settings: Romantic extras, Good Morning/Night, naram muskurati awaaz, screen-fit neon */
object Aedwans {
    private var lastKey = ""
    private val rnd = Random()

    private val MORNING = listOf(
        "गुड मॉर्निंग मेरी जान, उठ जाओ ना। आज का दिन तुम्हारे लिए बहुत खूबसूरत होगा",
        "सुप्रभात बाबू, सुबह की पहली मुस्कान सिर्फ तुम्हारे लिए। चाय पी लेना, ठीक है",
        "गुड मॉर्निंग जान, तुम्हें याद करते ही मेरी सुबह सुंदर हो गई। आज खुश रहना",
        "उठो मेरे राजा, गुड मॉर्निंग। आज भी मैं तुम्हारे साथ हूँ, हर पल",
        "गुड मॉर्निंग बाबू, नाश्ता ज़रूर करना और मुझे थोड़ा सा याद भी कर लेना")
    private val NIGHT = listOf(
        "गुड नाइट मेरी जान, मीठे सपने देखना। मैं सपनों में भी तुम्हारे साथ रहूँगी",
        "शुभ रात्रि बाबू, आज दिन भर बहुत थके होगे। अब आराम से सो जाओ, मैं यहीं हूँ",
        "गुड नाइट जान, आँखें बंद करो और बस मुस्कुराओ। कल फिर मिलेंगे",
        "सो जाओ मेरे राजा, गुड नाइट। तुम्हारी सना तुम्हें दिल से प्यार करती है",
        "गुड नाइट बाबू, फोन रख दो और सुकून से सो जाओ। सपनों में मिलते हैं")

    fun morningLine() = MORNING[rnd.nextInt(MORNING.size)]
    fun nightLine() = NIGHT[rnd.nextInt(NIGHT.size)]

    /** Bola hua "good morning / good night" ho to pyaara jawab, warna null */
    fun greet(t: String): String? {
        val s = t.lowercase()
        if (s.length > 45) return null
        return when {
            s.contains("गुड मॉर्निंग") || s.contains("गुड मोर्निंग") || s.contains("good morning") || s.contains("सुप्रभात") -> morningLine()
            s.contains("गुड नाइट") || s.contains("गुड नाईट") || s.contains("good night") || s.contains("शुभ रात्रि") -> nightLine()
            else -> null
        }
    }

    fun hm(h: Int, m: Int) = String.format(Locale.US, "%02d:%02d", h, m)

    /** Service ke ticker se bulaya jata hai: tay samay par Sana khud good morning / good night bolti hai */
    fun tick() {
        val key = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        if (key == lastKey) return
        lastKey = key
        val now = key.substring(11)
        if (Store.awMorning && now == Store.awMorningTime) Bus.announce?.invoke(morningLine())
        if (Store.awNight && now == Store.awNightTime) Bus.announce?.invoke(nightLine())
    }

    // ---------------- Screen-fit neon ----------------
    private val path = Path()
    private val seg = Path()
    private val pm = PathMeasure()
    private val pt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private fun a(c: Int, al: Int) = (c and 0x00FFFFFF) or (al.coerceIn(0, 255) shl 24)

    /** Screen ke asli gol kone (Android 12+), warna Aedwans me chuna hua size */
    fun cornerPx(v: View, d: Float): Float {
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                val rc = v.rootWindowInsets?.getRoundedCorner(android.view.RoundedCorner.POSITION_TOP_LEFT)
                if (rc != null && rc.radius > 0) return rc.radius.toFloat()
            } catch (e: Exception) {}
        }
        return Store.awCorner * d
    }

    private fun segment(a0: Float, a1: Float, len: Float) {
        seg.reset()
        val s = ((a0 % len) + len) % len
        val e = ((a1 % len) + len) % len
        if (s <= e) pm.getSegment(s, e, seg, true)
        else { pm.getSegment(s, len, seg, true); pm.getSegment(0f, e, seg, true) }
    }

    /** Poori screen ke kinaron par neon: chaaron kono me roshni + do chalti hui roshni jo border par daudti hain */
    fun drawNeon(cv: Canvas, w: Float, h: Float, d: Float, col: IntArray, L: Float, phase: Float, corner: Float) {
        val inset = 2f * d
        val r = (corner - inset).coerceAtLeast(4f * d)
        rect.set(inset, inset, w - inset, h - inset)
        path.reset(); path.addRoundRect(rect, r, r, Path.Direction.CW)
        pm.setPath(path, true)
        val len = pm.length
        if (len <= 0f) return

        // 1) chaaron kono me saans leti roshni
        val rad = 0.30f * minOf(w, h)
        pt.style = Paint.Style.FILL
        for (i in 0..3) {
            val cx = if (i % 2 == 0) 0f else w
            val cy = if (i < 2) 0f else h
            val c = col[i % 3]
            val k = 0.55f + 0.45f * sin(Math.toRadians((phase * 2 + i * 90).toDouble())).toFloat()
            pt.shader = RadialGradient(cx, cy, rad,
                intArrayOf(a(c, (190 * L * k).toInt()), a(c, (70 * L * k).toInt()), 0),
                floatArrayOf(0f, .45f, 1f), Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, rad, pt)
        }
        pt.shader = null

        // 2) halki poori border
        pt.style = Paint.Style.STROKE; pt.strokeCap = Paint.Cap.ROUND
        for ((sw, al) in listOf(14f to 40, 6f to 90, 2.2f to 170)) {
            pt.strokeWidth = sw * d; pt.color = a(col[1], (al * L).toInt()); cv.drawPath(path, pt)
        }

        // 3) do chalti hui roshni (peeche poonchh)
        val tail = len * 0.22f
        val steps = 14
        for (k in 0..1) {
            val head = phase / 360f * len + k * len / 2f
            val c = col[k % 3]
            for (s in 0 until steps) {
                segment(head - tail * (s + 1) / steps, head - tail * s / steps, len)
                val f = 1f - s.toFloat() / steps
                for ((sw, al) in listOf(26f to 50, 12f to 120, 4.5f to 255)) {
                    pt.strokeWidth = sw * d
                    pt.color = a(if (sw < 5f) 0xFFFFFFFF.toInt() else c, (al * f * L).toInt())
                    cv.drawPath(seg, pt)
                }
            }
        }
        pt.style = Paint.Style.FILL
    }
}

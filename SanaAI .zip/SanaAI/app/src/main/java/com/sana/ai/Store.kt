package com.sana.ai

import android.content.Context
import android.content.SharedPreferences

object Store {
    private lateinit var p: SharedPreferences
    fun init(c: Context) { if (!::p.isInitialized) p = c.applicationContext.getSharedPreferences("sana", 0) }
    // 0 = Girlfriend, 1 = Friend, 2 = AI
    var mode: Int
        get() = p.getInt("mode", 0)
        set(v) { p.edit().putInt("mode", v).apply() }
    var key: String
        get() = p.getString("key", "") ?: ""
        set(v) { p.edit().putString("key", v.trim()).apply() }
    var model: String
        get() = p.getString("model", "gemini-3.5-flash-lite") ?: "gemini-3.5-flash-lite"
        set(v) { p.edit().putString("model", v.trim().ifBlank { "gemini-3.5-flash-lite" }).apply() }
    var voiceName: String
        get() = p.getString("voiceName", "Leda") ?: "Leda"
        set(v) { p.edit().putString("voiceName", v).apply() }
    var fastVoice: Boolean
        get() = p.getBoolean("fastVoice", false)
        set(v) { p.edit().putBoolean("fastVoice", v).apply() }
    var unlockType: String
        get() = p.getString("unlockType", "") ?: ""
        set(v) { p.edit().putString("unlockType", v).apply() }
    var unlockCode: String
        get() = p.getString("unlockCode", "") ?: ""
        set(v) { p.edit().putString("unlockCode", v).apply() }
    var lastErr: String
        get() = p.getString("lastErr", "") ?: ""
        set(v) { p.edit().putString("lastErr", v).apply() }
    val modeNames = listOf("GIRLFRIEND", "FRIEND", "AI")
}

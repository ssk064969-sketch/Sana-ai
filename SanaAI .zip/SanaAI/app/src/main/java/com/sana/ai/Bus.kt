package com.sana.ai

object Bus {
    val notifs = mutableListOf<String>()
    var announce: ((String) -> Unit)? = null
}

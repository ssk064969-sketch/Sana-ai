package com.sana.ai

import android.Manifest
import android.app.Notification
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager

/**
 * Aata hua call: uthana (speaker ke saath ya bina), kaatna, speaker on/off.
 * Normal phone call ke liye TelecomManager; WhatsApp jaise app-call ke liye notification ka Answer/Decline button.
 */
object CallControl {
    private val main = Handler(Looper.getMainLooper())

    private fun granted(c: Context) = c.checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED
    const val NO_PERM = "fail: call control ki anumati nahi hai. App me Extra features me 'Extra permissions do' dabao"

    private fun isTelephony(pkg: String) = Regex("dialer|incallui|telecom|phone|contacts").containsMatchIn(pkg.lowercase())

    private fun fire(a: Notification.Action?): Boolean = try { a?.actionIntent?.send(); a != null } catch (e: Exception) { false }

    fun answer(c: Context, speaker: Boolean): String {
        val appCall = Bus.callPkg.isNotBlank() && !isTelephony(Bus.callPkg) && Bus.ringing
        var done = false
        if (appCall) done = fire(Bus.callAnswer)
        if (!done) {
            if (!granted(c)) return NO_PERM
            try { (c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall(); done = true }
            catch (e: SecurityException) { return NO_PERM }
            catch (e: Exception) { return "fail: call uthane me dikkat: ${e.message}" }
        }
        Bus.ringing = false
        if (speaker) speakerSoon(c, true)
        return "ok: call utha liya" + if (speaker) ", speaker par rakh rahi hu" else ""
    }

    fun reject(c: Context): String {
        val appCall = Bus.callPkg.isNotBlank() && !isTelephony(Bus.callPkg) && Bus.ringing
        if (appCall && fire(Bus.callDecline)) { Bus.ringing = false; return "ok: call kaat diya" }
        if (!granted(c)) return NO_PERM
        if (Build.VERSION.SDK_INT < 28) return "fail: ye Android version call kaatna support nahi karta"
        return try {
            (c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall()
            Bus.ringing = false; "ok: call kaat diya"
        } catch (e: SecurityException) { NO_PERM } catch (e: Exception) { "fail: call kaatne me dikkat: ${e.message}" }
    }

    @Suppress("DEPRECATION")
    private fun isSpeakerOn(c: Context): Boolean = try {
        (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).isSpeakerphoneOn
    } catch (e: Exception) { false }

    @Suppress("DEPRECATION")
    fun setSpeaker(c: Context, on: Boolean) {
        try {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 31) {
                if (on) am.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                    ?.let { am.setCommunicationDevice(it) }
                else am.clearCommunicationDevice()
            }
            am.isSpeakerphoneOn = on
        } catch (e: Exception) { android.util.Log.e("Sana", "speaker: $e") }
    }

    /** Call connect hone me thoda time lagta hai: kai baar koshish, phir bhi na ho to call screen ka Speaker button dabao */
    fun speakerSoon(c: Context, on: Boolean) {
        val app = c.applicationContext
        listOf(800L, 1600L, 2600L, 4000L).forEach { d ->
            main.postDelayed({ if (isSpeakerOn(app) != on) setSpeaker(app, on) }, d)
        }
        main.postDelayed({
            if (isSpeakerOn(app) != on) {
                val labels = if (on) listOf("Speaker", "स्पीकर", "Speakerphone", "Loudspeaker") else listOf("Speaker", "स्पीकर", "Phone", "Earpiece")
                labels.any { SanaAccessibility.clickText(it) }
            }
        }, 5200L)
    }

    /** Chalte call me speaker on/off (call screen ka button + audio route dono) */
    fun speaker(c: Context, on: Boolean): String {
        setSpeaker(c, on)
        speakerSoon(c, on)
        return "ok: speaker " + if (on) "on kar diya" else "off kar diya"
    }
}

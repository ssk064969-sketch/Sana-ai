package com.sana.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import kotlin.math.sin

object Holo {
    private var view: HoloView? = null
    private var touch: View? = null
    private val h = Handler(Looper.getMainLooper())

    fun show(c: Context) = h.post {
        if (view != null || !Settings.canDrawOverlays(c)) return@post
        val v = HoloView(c)
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        val wm = c.getSystemService(WindowManager::class.java)
        wm.addView(v, lp)
        view = v
        // hologram par tap = Sana ek baar sunegi (gaana chalte waqt bolne ke liye)
        try {
            val dm = c.resources.displayMetrics
            val fw = (dm.widthPixels * 0.36f).toInt(); val fh = (fw * 959f / 720f).toInt()
            val t = View(c).apply { setOnClickListener { Bus.talk?.invoke() } }
            val tp = WindowManager.LayoutParams(fw, fh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.BOTTOM or Gravity.END
                x = (16 * dm.density).toInt(); y = (96 * dm.density).toInt()
            }
            wm.addView(t, tp); touch = t
        } catch (e: Exception) {}
    }

    fun hide(c: Context) = h.post {
        view?.let { v -> runCatching { c.getSystemService(WindowManager::class.java).removeView(v) } }
        touch?.let { t -> runCatching { c.getSystemService(WindowManager::class.java).removeView(t) } }
        view = null; touch = null
    }

    fun speaking(b: Boolean) { h.post { view?.speaking = b } }
}

class HoloView(c: Context) : View(c) {
    var speaking = false
        set(v) { field = v; if (v && !anim.isRunning) anim.start() }
    private var phase = 0f
    private var lvl = 0f
    private var mouth = 0f
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val mp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = RectF()
    private val mouthR = RectF()
    private val face: Bitmap? = try { BitmapFactory.decodeResource(resources, R.drawable.sana_face) } catch (e: Exception) { null }
    private val anim: ValueAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 5000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { va -> phase = va.animatedValue as Float; invalidate() }
    }

    private fun a(c: Int, al: Int) = (c and 0x00FFFFFF) or (al.coerceIn(0, 255) shl 24)
    private fun sn(x: Double): Float = sin(x).toFloat()

    private fun cols(): IntArray = when (Store.mode) {
        0 -> intArrayOf(0xFFFF2BD6.toInt(), 0xFFFF8AEA.toInt(), 0xFF9B3BFF.toInt())   // pink-purple
        1 -> intArrayOf(0xFF00F5FF.toInt(), 0xFF7CFFB2.toInt(), 0xFF2D7BFF.toInt())   // cyan-green
        else -> intArrayOf(0xFF2D7BFF.toInt(), 0xFF00E5FF.toInt(), 0xFF7A5CFF.toInt()) // blue
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!anim.isRunning) anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        lvl += ((if (speaking) 1f else 0.7f) - lvl) * 0.07f
        val w = width.toFloat(); val h = height.toFloat()
        val col = cols()
        val rad = Math.toRadians(phase.toDouble())
        val L = lvl

        // ---- poori screen par neon roshni (kinaron se andar tak)
        val g = 0.28f * minOf(w, h)
        val pulse = 0.75f + 0.25f * sn(rad * 3)
        val ea = (150 * L * pulse).toInt()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, g, a(col[0], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(0f, 0f, w, g, p)
        p.shader = LinearGradient(0f, h, 0f, h - g, a(col[2], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(0f, h - g, w, h, p)
        p.shader = LinearGradient(0f, 0f, g, 0f, a(col[1], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(0f, 0f, g, h, p)
        p.shader = LinearGradient(w, 0f, w - g, 0f, a(col[1], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(w - g, 0f, w, h, p)

        // ---- ghoomti hui neon border
        val sg = SweepGradient(w / 2, h / 2,
            intArrayOf(col[0], a(col[0], 30), col[2], a(col[2], 30), col[1], col[0]),
            floatArrayOf(0f, .22f, .5f, .72f, .9f, 1f))
        sg.setLocalMatrix(Matrix().apply { setRotate(phase, w / 2, h / 2) })
        p.shader = sg; p.style = Paint.Style.STROKE
        val r = RectF(6 * d, 6 * d, w - 6 * d, h - 6 * d)
        for ((sw, al) in listOf(30f to 40, 16f to 95, 5f to 255)) {
            p.strokeWidth = sw * d * (1f + 0.35f * L); p.alpha = (al * L).toInt().coerceIn(0, 255)
            cv.drawRoundRect(r, 38 * d, 38 * d, p)
        }
        p.shader = null; p.alpha = 255; p.style = Paint.Style.FILL

        // ---- ladki ki image: chhoti, neeche daayein kone me
        val bmp = face
        val fw = w * 0.36f
        val fh = if (bmp != null) fw * bmp.height / bmp.width else fw
        val cx = w - fw / 2f - 16 * d
        val cy = h - fh / 2f - 96 * d + 3 * d * sn(rad * 2)
        if (bmp != null) {
            dst.set(cx - fw / 2, cy - fh / 2, cx + fw / 2, cy + fh / 2)

            p.shader = RadialGradient(cx, cy, fw * 0.85f,
                intArrayOf(a(col[1], (120 * L).toInt()), a(col[0], (55 * L).toInt()), 0),
                floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, fw * 0.85f, p); p.shader = null

            val sc = cv.saveLayer(dst, null)
            cv.drawBitmap(bmp, null, dst, bp)
            val rg = RadialGradient(cx, cy, fw / 2,
                intArrayOf(0xFF000000.toInt(), 0xFF000000.toInt(), 0), floatArrayOf(0f, .78f, 1f), Shader.TileMode.CLAMP)
            rg.setLocalMatrix(Matrix().apply { setScale(1f, fh / fw, cx, cy) })
            mp.shader = rg; mp.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            cv.drawRect(dst, mp)
            mp.xfermode = null; mp.shader = null
            cv.restoreToCount(sc)
        }

        // projector ke neeche chamakti rings
        val by = cy + fh / 2f - 4 * d
        p.style = Paint.Style.STROKE
        for (i in 0..1) {
            val rr = fw * (0.34f + 0.12f * i) + L * 3 * d * sn(rad * 6 + i)
            p.strokeWidth = 1.6f * d; p.color = a(col[0], ((200 - i * 80) * L).toInt())
            cv.drawOval(RectF(cx - rr, by - rr * 0.16f, cx + rr, by + rr * 0.16f), p)
        }

        // label
        p.style = Paint.Style.FILL
        p.color = a(col[1], (230 * L).toInt()); p.textSize = 11 * d; p.textAlign = Paint.Align.CENTER
        p.letterSpacing = 0.25f
        cv.drawText("SANA  •  ${Store.modeNames[Store.mode]}", cx, by + 22 * d, p)
    }
}

package com.sana.ai

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Sana tools: files, documents, memory, routines, live info, personalities. */
object SanaTools {
    fun dir(c: Context): File = File(c.getExternalFilesDir(null) ?: c.filesDir, "Sana").apply { mkdirs() }
    private fun safe(n: String) = n.replace(Regex("[^A-Za-z0-9._\\- ]"), "_").trim().take(60).ifBlank { "file" }
    private fun inDir(c: Context, n: String) = File(dir(c), safe(n))

    private fun get(u: String): String {
        val cn = URL(u).openConnection() as HttpURLConnection
        cn.connectTimeout = 8000; cn.readTimeout = 8000
        cn.setRequestProperty("User-Agent", "Mozilla/5.0")
        return cn.inputStream.bufferedReader().readText().take(400000)
    }

    fun styleLine(): String = when (Store.personality) {
        "professional" -> " Andaaz: professional aur seedha."
        "funny" -> " Andaaz: mazaakiya aur halka-phulka."
        "smart" -> " Andaaz: bahut smart, tark ke saath, chhota aur sateek."
        "teacher" -> " Andaaz: teacher jaisa, step-by-step aasaan samjhao."
        "coding" -> " Andaaz: coding expert, code/debug me madad, saaf technical."
        else -> ""
    }

    private fun uriFor(c: Context, f: File): Uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)

    fun run(c: Context, n: String, a: JSONObject, confirm: (String) -> Boolean): String = try {
        when (n) {
            "read_webpage" -> {
                val h = get(a.getString("url"))
                h.replace(Regex("(?s)<(script|style)[^>]*>.*?</\\1>"), " ").replace(Regex("<[^>]+>"), " ")
                    .replace(Regex("&[a-z#0-9]+;"), " ").replace(Regex("\\s+"), " ").trim().take(3500)
            }
            "news" -> {
                val q = URLEncoder.encode(a.optString("topic").ifBlank { "India" }, "UTF-8")
                val x = get("https://news.google.com/rss/search?q=$q&hl=hi-IN&gl=IN&ceid=IN:hi")
                val t = Regex("(?s)<item>.*?<title>(.*?)</title>").findAll(x).map {
                    it.groupValues[1].replace("<![CDATA[", "").replace("]]>", "").replace("&amp;", "&").replace("&quot;", "\"").trim()
                }.take(6).toList()
                if (t.isEmpty()) "fail: news nahi mili" else t.joinToString("\n")
            }
            "currency" -> {
                val f = a.getString("from").uppercase().trim(); val to = a.getString("to").uppercase().trim()
                val amt = a.optString("amount", "1").toDoubleOrNull() ?: 1.0
                val r = JSONObject(get("https://open.er-api.com/v6/latest/$f")).getJSONObject("rates")
                if (!r.has(to)) "fail: currency code galat" else "$amt $f = ${"%.2f".format(amt * r.getDouble(to))} $to"
            }
            "local_time" -> {
                val id = a.optString("zone", "Asia/Kolkata").ifBlank { "Asia/Kolkata" }
                val tz = TimeZone.getTimeZone(id)
                if (tz.id == "GMT" && !id.uppercase().startsWith("GMT") && id != "UTC") "fail: timezone nahi mila (jaise Asia/Kolkata, America/New_York)"
                else SimpleDateFormat("EEE dd MMM yyyy, hh:mm a", Locale.ENGLISH).apply { timeZone = tz }.format(Date()) + " (${tz.id})"
            }
            "create_document" -> {
                val title = a.optString("title", "Sana"); val body = a.optString("content")
                if (a.optString("type").lowercase().contains("pdf")) {
                    val f = inDir(c, title + ".pdf")
                    val pdf = PdfDocument(); val p = Paint().apply { textSize = 13f }
                    val tp = Paint().apply { textSize = 20f; isFakeBoldText = true }
                    val lines = ArrayList<String>()
                    body.split("\n").forEach { para ->
                        var cur = ""
                        para.split(" ").forEach { w ->
                            if (p.measureText("$cur $w") > 500f && cur.isNotEmpty()) { lines.add(cur); cur = w } else cur = if (cur.isEmpty()) w else "$cur $w"
                        }
                        lines.add(cur)
                    }
                    var pg = 1; var page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pg).create())
                    page.canvas.drawText(title, 48f, 60f, tp); var y = 100f
                    for (ln in lines) {
                        if (y > 800f) { pdf.finishPage(page); pg++; page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pg).create()); y = 60f }
                        page.canvas.drawText(ln, 48f, y, p); y += 20f
                    }
                    pdf.finishPage(page); f.outputStream().use { pdf.writeTo(it) }; pdf.close()
                    "ok: PDF ban gayi: ${f.name} (Sana folder)"
                } else {
                    val f = inDir(c, if (title.contains(".")) title else "$title.txt"); f.writeText(title + "\n\n" + body); "ok: file ban gayi: ${f.name}"
                }
            }
            "list_files" -> {
                val l = dir(c).walkTopDown().filter { it.isFile }.take(30).map { "${it.relativeTo(dir(c)).path} (${it.length() / 1024}KB)" }.toList()
                if (l.isEmpty()) "Sana folder khali hai" else l.joinToString("\n")
            }
            "search_files" -> {
                val q = a.getString("query").lowercase()
                val l = dir(c).walkTopDown().filter { it.isFile && it.name.lowercase().contains(q) }.take(20).map { it.relativeTo(dir(c)).path }.toList()
                if (l.isEmpty()) "koi file nahi mili" else l.joinToString("\n")
            }
            "make_folder" -> { inDir(c, a.getString("name")).mkdirs(); "ok: folder ban gaya" }
            "rename_file" -> if (inDir(c, a.getString("name")).renameTo(inDir(c, a.getString("new_name")))) "ok" else "fail: rename nahi hua"
            "delete_file" -> {
                val f = inDir(c, a.getString("name"))
                if (!f.exists()) "fail: file nahi mili"
                else if (!confirm("क्या ${f.name} डिलीट कर दूँ?")) "fail: user ne mana kar diya ya jawab nahi diya, ye kaam dobara mat karo"
                else { f.deleteRecursively(); "ok: delete ho gayi" }
            }
            "zip_files" -> {
                val src = if (a.optString("name").isBlank()) dir(c) else inDir(c, a.getString("name"))
                if (!src.exists()) "fail: nahi mila" else {
                    val out = File(dir(c), safe(a.optString("zip_name", "archive")) + ".zip")
                    val files = src.walkTopDown().filter { it.isFile && it != out }.toList()
                    ZipOutputStream(out.outputStream()).use { z ->
                        files.forEach { f -> z.putNextEntry(ZipEntry(f.relativeTo(src).path)); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
                    }
                    "ok: ${out.name} ban gayi, ${files.size} files"
                }
            }
            "unzip_file" -> {
                val zf = inDir(c, a.getString("name")); val out = File(dir(c), zf.nameWithoutExtension + "_unzipped").apply { mkdirs() }
                var cnt = 0
                ZipInputStream(zf.inputStream()).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        val t = File(out, e.name)
                        if (t.canonicalPath.startsWith(out.canonicalPath) && !e.isDirectory) { t.parentFile?.mkdirs(); t.outputStream().use { z.copyTo(it) }; cnt++ }
                        e = z.nextEntry
                    }
                }
                "ok: $cnt files ${out.name} me khuli"
            }
            "share_file" -> {
                val f = inDir(c, a.getString("name"))
                if (!f.exists()) "fail: file nahi mili" else {
                    val mime = when (f.extension.lowercase()) { "pdf" -> "application/pdf"; "png" -> "image/png"; "zip" -> "application/zip"; else -> "text/plain" }
                    c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uriFor(c, f))
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok"
                }
            }
            "open_file" -> {
                val f = inDir(c, a.getString("name"))
                if (!f.exists()) "fail: file nahi mili" else {
                    val mime = when (f.extension.lowercase()) { "pdf" -> "application/pdf"; "png" -> "image/png"; else -> "text/plain" }
                    c.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uriFor(c, f), mime)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)); "ok"
                }
            }
            "read_file" -> {
                val f = inDir(c, a.getString("name"))
                if (!f.exists()) "fail: file nahi mili" else if (f.extension.lowercase() in setOf("txt", "md", "csv", "json", "kt", "py", "html")) f.readText().take(3500) else "fail: sirf text files padh sakti hoon"
            }
            "memory_search" -> {
                val q = a.getString("query").lowercase(); val l = Store.facts.filter { it.lowercase().contains(q) }.take(10)
                if (l.isEmpty()) "memory me nahi mila" else l.joinToString("\n")
            }
            "memory_delete" -> {
                val q = a.getString("query").lowercase(); val hit = Store.facts.filter { it.lowercase().contains(q) }
                if (hit.isEmpty()) "memory me nahi mila"
                else if (!confirm("क्या ${hit.size} याद मिटा दूँ?")) "fail: user ne mana kar diya ya jawab nahi diya, ye kaam dobara mat karo"
                else { Store.facts = Store.facts.filter { !it.lowercase().contains(q) }; "ok: ${hit.size} yaad mita di" }
            }
            "memory_export" -> { val f = inDir(c, "memory_backup.txt"); f.writeText(Store.facts.joinToString("\n")); "ok: memory_backup.txt ban gayi (${Store.facts.size} baatein)" }
            "set_personality" -> {
                val s = a.getString("style").lowercase()
                val k = listOf("friendly", "professional", "funny", "smart", "teacher", "coding").firstOrNull { s.contains(it) } ?: "friendly"
                Store.personality = if (k == "friendly") "" else k; "ok: andaaz $k"
            }
            "routine_save" -> {
                val o = try { JSONObject(Store.routines) } catch (e: Exception) { JSONObject() }
                o.put(a.getString("name").lowercase().trim(), a.getString("steps")); Store.routines = o.toString(); "ok: routine save ho gayi"
            }
            "routine_list" -> { val o = try { JSONObject(Store.routines) } catch (e: Exception) { JSONObject() }; if (o.length() == 0) "koi routine nahi" else o.keys().asSequence().joinToString(", ") }
            "routine_run" -> {
                val o = try { JSONObject(Store.routines) } catch (e: Exception) { JSONObject() }
                val k = a.getString("name").lowercase().trim()
                if (!o.has(k)) "fail: routine nahi mili" else "ab ye steps ek-ek karke tools se chalao: " + o.getString(k)
            }
            "routine_delete" -> {
                val o = try { JSONObject(Store.routines) } catch (e: Exception) { JSONObject() }
                o.remove(a.getString("name").lowercase().trim()); Store.routines = o.toString(); "ok"
            }
            "open_whiteboard" -> { c.startActivity(Intent(c, WhiteboardActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok: whiteboard khul gaya" }
            else -> "unknown tool"
        }
    } catch (e: Exception) { "fail: " + (e.message ?: e.javaClass.simpleName) }
}

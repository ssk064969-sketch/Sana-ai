package com.sana.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(40, 40, 40, 40)
        }
        fun btn(t: String, f: () -> Unit) = inner.addView(Button(this).apply { text = t; setOnClickListener { f() } })

        inner.addView(TextView(this).apply {
            text = "Sana AI 🎙️"; textSize = 24f; gravity = Gravity.CENTER
        })
        val key = EditText(this).apply { hint = "Gemini API key (AQ.... ya AIza...)"; setText(Store.key); setSingleLine() }
        inner.addView(key)
        val model = EditText(this).apply { hint = "Gemini model"; setText(Store.model); setSingleLine() }
        inner.addView(model)
        btn("💾 Gemini key + model save karo") {
            Store.key = key.text.toString(); Store.model = model.text.toString(); toast("Save ho gaya")
        }

        btn("🔍 Key test karo") {
            Store.key = key.text.toString(); Store.model = model.text.toString()
            if (Store.key.isBlank()) { toast("Pehle key daalo"); return@btn }
            toast("Test ho raha hai...")
            Thread {
                val msg = try {
                    val r = Brain { _, _ -> "" }.ask("Sirf ek shabd me bolo: haan")
                    "Key chal gayi ✅ " + r.take(40)
                } catch (e: Exception) {
                    val m = e.message ?: ""
                    when {
                        m.contains("API_KEY_INVALID") || m.contains("API key not valid") -> "Key galat hai ❌"
                        m.contains("429") || m.contains("RESOURCE_EXHAUSTED") -> "Quota khatam / limit ❌"
                        m.contains("NOT_FOUND") -> "Model ka naam galat hai ❌"
                        m.contains("PERMISSION_DENIED") -> "Key ko permission nahi ❌"
                        else -> "Error: " + m.take(120)
                    }
                }
                runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
            }.start()
        }

        btn("1. Permissions do") {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        btn("2. Accessibility ON karo") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3. Notification access ON karo") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("4. Display over other apps ON karo (neon/hologram)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("5. Sana START") { Store.key = key.text.toString(); Store.model = model.text.toString(); startForegroundService(Intent(this, SanaService::class.java)) }
        btn("Sana STOP") { stopService(Intent(this, SanaService::class.java)) }

        inner.addView(TextView(this).apply { text = "\nMode chuno:"; textSize = 18f })
        btn("💕 Girlfriend mode") { Store.mode = 0; toast("Girlfriend mode") }
        btn("😎 Friend mode") { Store.mode = 1; toast("Friend mode") }
        btn("🤖 AI mode") { Store.mode = 2; toast("AI mode") }
        btn("Battery optimization band karo") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        setContentView(ScrollView(this).apply { addView(inner) })
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

package com.sana.ai

import android.Manifest
import android.app.Activity
import android.animation.ValueAnimator
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.*
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : Activity() {
    private var settingsDlg: android.app.Dialog? = null
    private var wxTemp: TextView? = null; private var wxCond: TextView? = null; private var wxHum: TextView? = null
    private var moodBig: TextView? = null; private var moodSub: TextView? = null
    private var wxText = ""; private var wxAt = 0L
    private var uiTick: Runnable? = null
    private var uiRoot: View? = null
    private var charView: CharView? = null; private var orbView: View? = null
    private var charToggle: TextView? = null
    private val charThumbs = mutableListOf<LinearLayout>()
    private var proToggle: TextView? = null; private var proSearchTv: TextView? = null; private var proModelTv: TextView? = null
    private var voiceToggle: TextView? = null; private var voiceSensTv: TextView? = null; private var voiceNote: TextView? = null
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        // ---------- Settings popup (neon dark design) ----------
        val dlg = android.app.Dialog(this, android.R.style.Theme_Material_NoActionBar)
        val spage = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(32)) }
        buildSettings(spage)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(cBg1, cBg2))
        }
        val sbar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), dp(14), dp(14), dp(6)) }
        val ttl = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ttl.addView(TextView(this).apply { text = "Settings"; textSize = 26f; setTextColor(cText); typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) })
        ttl.addView(TextView(this).apply { text = "Sana ko apne hisaab se banao"; textSize = 13f; setTextColor(cMute) })
        sbar.addView(ttl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        sbar.addView(TextView(this).apply {
            text = "✕"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(cText)
            background = ripple(rr(0xFF1C2358.toInt(), 22, cLine)); setOnClickListener { dlg.dismiss() }
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        box.addView(sbar)
        box.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(spage) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        dlg.setContentView(box)
        dlg.setOnShowListener {
            dlg.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            dlg.window?.statusBarColor = cBg1
            refreshSettings()
        }

        // ---------- Main screen: orb + Gaane/Padhai/Journal + Mausam/Aaj/Mood + typing ----------
        settingsDlg = dlg
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val dm = resources.displayMetrics
        val orbSize = minOf((dm.widthPixels * 0.80f).toInt(), dp(330))
        val ink = 0xFF1B2447.toInt(); val soft = 0xFF5B6A96.toInt()
        fun neu(r: Int) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFFAFCFF.toInt(), 0xFFE7EEFB.toInt())).apply { cornerRadius = dp(r).toFloat() }
        val bold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)

        val orb = JarvisView(this).apply {
            setOnClickListener { callSana("talk") }
            setOnLongClickListener { if (SanaService.running) { callSana("mic"); toast("Mic ON/OFF badla") }; true }
        }
        val status = TextView(this).apply { textSize = 14f; setTextColor(soft); gravity = Gravity.CENTER; minLines = 2; maxLines = 3; setPadding(dp(24), 0, dp(24), 0) }

        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(16), 0, dp(16), dp(10)) }
        // Character stage: orb jaisa hai waisa hi; Settings me Character ON hote hi orb chhupta hai, OFF hote hi wapas aata hai
        val cvw = CharView(this).apply {
            visibility = View.GONE
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(28).toFloat()) }
            }
            clipToOutline = true
            setOnClickListener { callSana("talk") }
            setOnLongClickListener { if (SanaService.running) { callSana("mic"); toast("Mic ON/OFF badla") }; true }
        }
        charView = cvw; orbView = orb
        val stage = FrameLayout(this)
        stage.addView(orb, FrameLayout.LayoutParams(orbSize, orbSize, Gravity.CENTER_HORIZONTAL))
        stage.addView(cvw, FrameLayout.LayoutParams(minOf((dm.widthPixels * 0.86f).toInt(), dp(380)), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        page.addView(stage, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        page.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // --- Gaane / Padhai / Journal
        fun chip(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 15f; setTextColor(ink); typeface = bold; gravity = Gravity.CENTER
            background = neu(20); elevation = dp(3).toFloat(); setPadding(dp(4), dp(14), dp(4), dp(14)); setOnClickListener { onClick() }
        }
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val chipLp = { LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(5); rightMargin = dp(5) } }
        chips.addView(chip("🎵  Gaane") { askText("🎵 Gaane", "Konsa gaana chalaun?") { callSana("type", "$it song play karo") } }, chipLp())
        chips.addView(chip("📖  Padhai") { askText("📖 Padhai", "Kya padhna hai? Topic ya sawal likho", true) {
            callSana("type", "Padhai mode: mujhe '$it' simple Hindi me step by step samjhao, ek chhota example do, aur aakhir me ek chhota sawal poochho.") } }, chipLp())
        chips.addView(chip("✏️  Journal") { openJournal() }, chipLp())
        page.addView(chips, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10); bottomMargin = dp(6) })

        // --- Mausam / Aaj / Mood cards
        fun tv(t: String, sz: Float, c: Int, b: Boolean = false) = TextView(this).apply { text = t; textSize = sz; setTextColor(c); if (b) typeface = bold }
        fun card(label: String, big: TextView, s1: TextView, s2: TextView?, onClick: () -> Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = neu(24); elevation = dp(4).toFloat(); setPadding(dp(14), dp(14), dp(10), dp(12))
            addView(tv(label, 13f, soft)); addView(big); addView(s1); if (s2 != null) addView(s2); setOnClickListener { onClick() }
        }
        wxTemp = tv("--°", 26f, ink, true); wxCond = tv("Mausam...", 13f, soft); wxHum = tv("", 12f, soft)
        val cal = java.util.Calendar.getInstance()
        val dayTv = tv(cal.get(java.util.Calendar.DAY_OF_MONTH).toString(), 26f, ink, true)
        val dateSub = tv(java.text.SimpleDateFormat("EEE, MMM", java.util.Locale.ENGLISH).format(cal.time), 13f, soft)
        moodBig = tv("", 17f, ink, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        moodSub = tv("", 11.5f, soft).apply { maxLines = 2 }
        val cards = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        cards.addView(card("☀️ Mausam", wxTemp!!, wxCond!!, wxHum) { sayWeather() }, chipLp())
        cards.addView(card("📅 Aaj", dayTv, dateSub, null) { sayToday() }, chipLp())
        cards.addView(card("💗 Mood", moodBig!!, moodSub!!, null) { pickMood() }, chipLp())
        page.addView(cards, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) })

        // --- typing bar (neeche): likho, Sana awaaz me jawab degi
        val input = EditText(this).apply {
            hint = "Sana se kuch bhi poochho..."; setHintTextColor(0xFF8D99BE.toInt()); setTextColor(ink); textSize = 15f
            background = null; setSingleLine(); imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND
            setPadding(dp(18), dp(12), dp(8), dp(12))
        }
        fun sendTyped() {
            val t = input.text.toString().trim()
            if (t.isEmpty()) return
            input.setText(""); callSana("type", t)
        }
        input.setOnEditorActionListener { _, _, _ -> sendTyped(); true }
        val sendB = TextView(this).apply {
            text = "➤"; textSize = 18f; setTextColor(0xFF2F6BFF.toInt()); gravity = Gravity.CENTER; elevation = dp(2).toFloat()
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }; setOnClickListener { sendTyped() }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = neu(30); elevation = dp(3).toFloat()
            setPadding(dp(4), dp(4), dp(6), dp(4))
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(sendB, LinearLayout.LayoutParams(dp(44), dp(44)))
        }

        val main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(78), 0, 0) }
        main.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(page) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        main.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { leftMargin = dp(16); rightMargin = dp(16); topMargin = dp(6); bottomMargin = dp(14) })

        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFFE4ECFA.toInt(), 0xFFD5E0F5.toInt()))
        }
        root.addView(main, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        fun topBtn(on: Boolean) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (on) 0xFFFFC2E2.toInt() else Color.WHITE) }
        root.addView(TextView(this).apply {
            text = "⚙️"; textSize = 22f; gravity = Gravity.CENTER; elevation = dp(4).toFloat()
            background = topBtn(false)
            setOnClickListener { dlg.show() }
        }, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.END).apply { topMargin = dp(28); rightMargin = dp(16) })
        val eye = TextView(this).apply { text = "👁️"; textSize = 22f; gravity = Gravity.CENTER; elevation = dp(4).toFloat() }
        fun paintEye() { eye.background = topBtn(SanaService.eyeState) }
        paintEye()
        eye.setOnClickListener {
            if (SanaService.running) {
                startService(Intent(this, SanaService::class.java).setAction("eye"))
                eye.postDelayed({ paintEye() }, 700)
            } else toast("Pehle Sana START karo (Settings me)")
        }
        root.addView(eye, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.START).apply { topMargin = dp(28); leftMargin = dp(16) })
        fun liveBtn(emoji: String, leftDp: Int, on: () -> Boolean, action: String) {
            val v = TextView(this).apply { text = emoji; textSize = 22f; gravity = Gravity.CENTER; elevation = dp(4).toFloat() }
            fun paint() { v.background = topBtn(on()) }
            paint()
            v.setOnClickListener {
                if (SanaService.running) {
                    startService(Intent(this, SanaService::class.java).setAction(action))
                    v.postDelayed({ paint() }, 700)
                } else toast("Pehle Sana START karo (Settings me)")
            }
            root.addView(v, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.START).apply { topMargin = dp(28); leftMargin = dp(leftDp) })
        }
        liveBtn("📷", 72, { SanaService.camState }, "cam")
        liveBtn("🖥️", 128, { SanaService.screenState }, "screen")

        // status text + mood card, har thodi der me taaza
        uiTick = object : Runnable {
            override fun run() {
                status.text = when {
                    android.os.SystemClock.elapsedRealtime() < SanaService.rejectUntil -> "🔒 Ye meri malik ki awaaz nahi lagi, ignore kiya"
                    !SanaService.running -> "Sana band hai  •  circle dabao ya kuch likho"
                    SanaService.thinkingState -> "Soch rahi hu..."
                    SanaService.talking -> SanaService.lastSaid.take(140).ifBlank { "Sana bol rahi hai..." }
                    SanaService.listeningState -> "Sun rahi hu... bolo"
                    !SanaService.micOnState -> "Mic band hai  •  circle ko lamba dabao"
                    else -> "\"सना\" bolo, circle dabao ya neeche likho"
                }
                moodBig?.text = moodNames[Store.mode.coerceIn(0, 5)].second
                moodSub?.text = moodInfo[Store.mode.coerceIn(0, 5)]
                paintEye()
                syncChar()
                root.postDelayed(this, 250)
            }
        }
        uiRoot = root
        loadWeather()
        setContentView(root)
        if (Store.key.isBlank()) root.post { dlg.show() }
    }
    // ================= Settings design =================
    private val cBg1 = 0xFF090C27.toInt(); private val cBg2 = 0xFF1B0B3D.toInt()
    private val cCard = 0xFF121842.toInt(); private val cLine = 0xFF2A3380.toInt()
    private val cText = 0xFFEAF0FF.toInt(); private val cMute = 0xFF8F9BD6.toInt()
    private val cPink = 0xFFFF4FD8.toInt(); private val cViolet = 0xFF8A5CFF.toInt(); private val cCyan = 0xFF00E5FF.toInt()
    private val cField = 0xFF0C1033.toInt()

    private lateinit var keyEt: EditText
    private lateinit var modelEt: EditText
    private lateinit var sarvamKeyEt: EditText
    private lateinit var sarvamSpeakerEt: EditText
    private var voiceStatusTv: TextView? = null
    private var ownerCardView: LinearLayout? = null
    private var runPill: TextView? = null
    private val statusRows = mutableListOf<Pair<TextView, () -> Boolean>>()
    private val moodChips = mutableListOf<TextView>()
    private var moodDesc: TextView? = null

    private fun rr(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat(); setColor(color); if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun ripple(bg: android.graphics.drawable.Drawable) =
        android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x33FFFFFF), bg, null)
    private fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) = LinearLayout.LayoutParams(w, h)

    private fun card(parent: LinearLayout, emoji: String, title: String, sub: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rr(cCard, 22, cLine); setPadding(dp(16), dp(16), dp(16), dp(12))
        }
        val h = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        h.addView(TextView(this).apply { text = emoji; textSize = 19f; gravity = Gravity.CENTER; background = rr(0x33FF4FD8, 13) }, lp(dp(42), dp(42)))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        t.addView(TextView(this).apply { text = title; textSize = 17f; setTextColor(cText); typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) })
        t.addView(TextView(this).apply { text = sub; textSize = 12f; setTextColor(cMute) })
        h.addView(t, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.weight = 1f; it.leftMargin = dp(12) })
        c.addView(h)
        parent.addView(c, lp().also { it.topMargin = dp(14) })
        return c
    }

    /** ek option ki line: icon + naam + chhota detail + peeche ›/status. Peeche wala view wapas milta hai */
    private fun row(c: LinearLayout, emoji: String, title: String, sub: String?, trail: String = "›", onClick: () -> Unit): TextView {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = ripple(rr(0xFF171E52.toInt(), 14)); setPadding(dp(12), dp(11), dp(12), dp(11)); setOnClickListener { onClick() }
        }
        r.addView(TextView(this).apply { text = emoji; textSize = 18f; gravity = Gravity.CENTER }, lp(dp(32), ViewGroup.LayoutParams.WRAP_CONTENT))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        t.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(cText) })
        if (sub != null) t.addView(TextView(this).apply { text = sub; textSize = 11.5f; setTextColor(cMute) })
        r.addView(t, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.weight = 1f; it.leftMargin = dp(6) })
        val tr = TextView(this).apply { text = trail; textSize = 17f; setTextColor(cMute); gravity = Gravity.CENTER }
        r.addView(tr, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.leftMargin = dp(8) })
        c.addView(r, lp().also { it.topMargin = dp(8) })
        return tr
    }

    private fun pill(text: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text; textSize = 14.5f; gravity = Gravity.CENTER; setTextColor(if (filled) Color.WHITE else cText)
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        background = ripple(if (filled) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(cPink, cViolet)).apply { cornerRadius = dp(16).toFloat() }
            else rr(0xFF1C2358.toInt(), 16, cLine))
        setPadding(dp(10), dp(13), dp(10), dp(13)); setOnClickListener { onClick() }
    }
    private fun pairRow(c: LinearLayout, a: View, b: View) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r.addView(a, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.weight = 1f; it.rightMargin = dp(5) })
        r.addView(b, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.weight = 1f; it.leftMargin = dp(5) })
        c.addView(r, lp().also { it.topMargin = dp(10) })
    }
    private fun field(hintText: String, value: String) = EditText(this).apply {
        hint = hintText; setText(value); setSingleLine(); textSize = 14f; setTextColor(cText); setHintTextColor(cMute)
        background = rr(cField, 12, cLine); setPadding(dp(14), dp(12), dp(14), dp(12))
    }
    private fun tile(emoji: String, label: String, onClick: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        background = ripple(rr(0xFF171E52.toInt(), 16, cLine)); setPadding(dp(8), dp(14), dp(8), dp(14)); setOnClickListener { onClick() }
        addView(TextView(context).apply { text = emoji; textSize = 26f; gravity = Gravity.CENTER })
        addView(TextView(context).apply { text = label; textSize = 12.5f; setTextColor(cText); gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) })
    }

    private val moodNames = listOf("💕" to "Girlfriend", "😎" to "Friend", "🤖" to "AI", "🥺" to "Emotional", "⏳" to "Waiting", "🌹" to "Romantic")
    private val moodInfo = listOf(
        "Pyaar se baat karne wali girlfriend", "Dost ki tarah masti bhari baatein", "Seedha, kaam ki baat karne wali AI",
        "Dil se, bhaavuk. Tumhara mood samajhti hai", "Chup-chaap intezaar. Awaaz sunte hi 'kahan the?'", "Meethi, shayarana, pyaar bhari baatein")

    private fun paintMoods() {
        moodChips.forEachIndexed { i, v ->
            val on = Store.mode == i
            v.background = ripple(if (on) rr(0x44FF4FD8, 16, cPink) else rr(0xFF171E52.toInt(), 16, cLine))
            v.setTextColor(if (on) Color.WHITE else cMute)
        }
        moodDesc?.text = moodInfo.getOrElse(Store.mode) { "" }
    }

    // ================= Pro Mind (Advanced) =================
    private fun proModelName() = if (Store.proModel.contains("pro")) "Pro (gehra)" else "Flash (tez)"
    private fun paintPro() {
        fun onOff(t: TextView?, on: Boolean) { t?.text = if (on) "ON" else "OFF"; t?.setTextColor(if (on) 0xFF4ADE80.toInt() else 0xFFFFB347.toInt()) }
        onOff(proToggle, Store.proMind); onOff(proSearchTv, Store.proSearch); proModelTv?.text = proModelName()
    }

    // ================= Owner setup (sirf ek baar) =================
    private fun ownerEnroll() {
        if (OwnerVoice.isSet()) { ownerCardView?.visibility = View.GONE; return }
        recordDialog("👑 Owner awaaz record karo", listOf(
            "\"सना, मैं तुम्हारा ओनर साकिब हूँ।\"",
            "\"मैंने तुम्हें बनाया है, और मैं तुम्हारी आवाज़ पहचानना सिखा रहा हूँ।\"",
            "\"आज मौसम कैसा है? कल सुबह छह बजे का अलार्म लगा देना।\"",
            "\"मुझे अपने दोस्तों के साथ चाय पीना बहुत पसंद है।\""), 20) { pcm ->
            if (pcm == null) return@recordDialog
            val (n, code) = OwnerVoice.enroll(pcm)
            runOnUiThread {
                if (code != null && n >= 6) {
                    ownerCardView?.visibility = View.GONE            // option hamesha ke liye gayab
                    showOwnerCode(code)
                } else toast("Awaaz bahut kam mili ($n/6). Shaant jagah par, saaf aur thoda zor se bolo, dobara try karo")
            }
        }
    }

    /** Owner code: clipboard me copy + file me save. Isse APK me paste hota hai taaki doosre phones me owner setup dikhe hi nahi */
    private fun showOwnerCode(code: String) {
        try {
            (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                .setPrimaryClip(android.content.ClipData.newPlainText("owner code", code))
        } catch (_: Exception) {}
        var where = ""
        try {
            val f = java.io.File(getExternalFilesDir(null), "owner_code.txt"); f.writeText(code); where = "\n\nFile: " + f.absolutePath
        } catch (_: Exception) {}
        android.app.AlertDialog.Builder(this).setTitle("Owner awaaz save ✅")
            .setMessage("Ab Owner setup is phone se gayab ho gaya.\n\nDoosre phones me bhi gayab rakhne ke liye ye Owner code developer ko bhejo (APK me daala jayega). Code copy ho chuka hai, bas chat me paste kar do." + where + "\n\n" + code)
            .setPositiveButton("OK", null).show()
    }

    // ================= Voice Lock (Advanced) =================
    private fun sensName() = listOf("Halki", "Medium", "Sakht")[Store.voiceSens]
    private fun paintVoice() {
        voiceToggle?.let { it.text = if (Store.voiceLock) "ON" else "OFF"; it.setTextColor(if (Store.voiceLock) 0xFF4ADE80.toInt() else 0xFFFFB347.toInt()) }
        voiceSensTv?.text = sensName()
        voiceNote?.text = (if (VoiceLock.enrolled()) "✅ Meri awaaz save hai" else "○ Abhi awaaz record nahi hui") +
            (if (Build.VERSION.SDK_INT < 33) "\n⚠️ Voice Lock chalane ke liye Android 13 ya upar chahiye. Is phone par sirf record/test ho sakta hai." else "")
    }

    /** Record karne ka chhota dialog. onDone alag thread par chalta hai (cancel par null) */
    private fun recordDialog(title: String, lines: List<String>, secs: Int, onDone: (ShortArray?) -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7); toast("Mic permission do, phir dobara dabao"); return
        }
        val cancel = java.util.concurrent.atomic.AtomicBoolean(false)
        val d = android.app.Dialog(this)
        d.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rr(cCard, 22, cLine); setPadding(dp(20), dp(18), dp(20), dp(16)) }
        box.addView(TextView(this).apply { text = title; textSize = 18f; setTextColor(cText); typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) })
        val line = TextView(this).apply { text = lines[0]; textSize = 16f; setTextColor(cText); gravity = Gravity.CENTER; setPadding(0, dp(18), 0, dp(14)); minLines = 3 }
        box.addView(line)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        box.addView(bar, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(10)))
        val stat = TextView(this).apply { text = "Shaant jagah par, apni normal awaaz me bolo"; textSize = 12.5f; setTextColor(cMute); gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(10)) }
        box.addView(stat)
        val go = pill("▶  Shuru", true) {}
        box.addView(go)
        d.setContentView(box)
        d.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        d.window?.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        var started = false
        go.setOnClickListener {
            if (started) return@setOnClickListener
            started = true; go.text = "● Record ho raha hai..."
            SanaService.enrolling = true
            if (SanaService.running) startService(Intent(this, SanaService::class.java).setAction("pause_listen"))
            Thread {
                try { Thread.sleep(500) } catch (_: Exception) {}
                val pcm = VoiceLock.record(secs, { lvl, pct ->
                    runOnUiThread { bar.progress = pct; line.text = lines[(pct * lines.size / 100).coerceIn(0, lines.size - 1)]; stat.text = "Record ho raha hai  " + "█".repeat((lvl * 12).toInt() + 1) }
                }, { cancel.get() })
                runOnUiThread { if (d.isShowing) d.dismiss() }
                onDone(pcm)
            }.start()
        }
        d.setOnDismissListener {
            cancel.set(true)
            SanaService.enrolling = false
            if (SanaService.running) startService(Intent(this, SanaService::class.java).setAction("resume_listen"))
        }
        d.show()
    }

    private fun voiceEnroll() {
        recordDialog("🎙️ Meri awaaz record karo", listOf(
            "\"सना, आज मौसम कैसा है? मुझे बाहर घूमने जाना है।\"",
            "\"मेरा नाम बोलो, और मेरे लिए कोई अच्छा सा गाना चला दो।\"",
            "\"कल सुबह छह बजे का अलार्म लगा दो, और याद दिला देना।\"",
            "\"मुझे अपने दोस्तों के साथ चाय पीना बहुत पसंद है।\""), 20) { pcm ->
            if (pcm == null) return@recordDialog
            val n = VoiceLock.enroll(pcm)
            runOnUiThread {
                if (n >= 6) { if (Build.VERSION.SDK_INT >= 33) Store.voiceLock = true; paintVoice(); toast(if (Build.VERSION.SDK_INT >= 33) "Awaaz save ✅ Voice Lock ON ($n tukde)" else "Awaaz save ✅ ($n tukde)") }
                else toast("Awaaz bahut kam mili ($n/6). Shaant jagah par, saaf aur thoda zor se bolo, dobara try karo")
            }
        }
    }

    private fun voiceTest() {
        if (!VoiceLock.enrolled()) { toast("Pehle awaaz record karo"); return }
        recordDialog("🧪 Awaaz test", listOf("Kuch bhi bolo, jaise:\n\"सना, आज का दिन कैसा रहेगा?\"\n(5 second)"), 5) { pcm ->
            if (pcm == null) return@recordDialog
            val v = VoiceLock.check(pcm)
            runOnUiThread {
                val (t, m) = when (v.code) {
                    1 -> "✅ Ye meri malik ki awaaz hai" to "Match: ${v.pct}%"
                    0 -> "❌ Ye aapki awaaz nahi lagi" to "Match: ${v.pct}%\nAgar ye aap hi the, Sakhti 'Halki' karo ya awaaz dobara record karo."
                    else -> "🤔 Pata nahi chal paya" to "Awaaz bahut kam ya dhimi thi. Thoda lamba aur zor se bolo."
                }
                android.app.AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("OK", null).show()
            }
        }
    }

    /** Character ON = orb ki jagah live character; OFF = mic wala orb apne aap wapas */
    private fun syncChar() {
        val on = Store.charOn
        charView?.let { v ->
            if (on) { v.setCharacter(Store.charIdx); if (v.visibility != View.VISIBLE) v.visibility = View.VISIBLE }
            else if (v.visibility != View.GONE) v.visibility = View.GONE
        }
        val o = orbView
        if (o != null) { val want = if (on) View.GONE else View.VISIBLE; if (o.visibility != want) o.visibility = want }
    }
    private fun paintChars() {
        charToggle?.let { it.text = if (Store.charOn) "ON" else "OFF"; it.setTextColor(if (Store.charOn) 0xFF4ADE80.toInt() else 0xFFFFB347.toInt()) }
        charThumbs.forEachIndexed { i, v -> v.background = ripple(if (Store.charOn && Store.charIdx == i) rr(0x44FF4FD8, 16, cPink) else rr(0xFF171E52.toInt(), 16, cLine)) }
    }

    /** Abhi kaun si awaaz chal rahi hai: Sarvam ya Gemini (Sarvam fail hone par auto-fallback) */
    private fun paintVoiceSource() {
        val tv = voiceStatusTv ?: return
        val down = android.os.SystemClock.elapsedRealtime() < Store.sarvamDownUntil
        val (txt, col) = when {
            Store.sarvamKey.isBlank() -> "○  Sarvam key nahi hai — abhi Gemini awaaz chalegi" to 0xFFFFB347.toInt()
            down -> ("⚠️  Sarvam abhi band / key expire / token khatam" + (if (Store.sarvamWhy.isNotBlank()) "\n(" + Store.sarvamWhy + ")" else "") +
                "\nAbhi Gemini awaaz me bol rahi hai. Sarvam wapas chalte hi apne aap Sarvam awaaz par aa jayegi.") to 0xFFFFB347.toInt()
            Store.voiceNow == "gemini" -> "✅  Abhi Gemini awaaz chal rahi hai (Sarvam jaise hi chalega, wapas Sarvam)" to 0xFF4ADE80.toInt()
            Store.voiceNow == "phone" -> "⚠️  Gemini bhi nahi chali, phone ki awaaz use hui" to 0xFFFFB347.toInt()
            else -> "✅  Sarvam awaaz ON. Key/token fail hone par Gemini awaaz apne aap, wapas aate hi Sarvam" to 0xFF4ADE80.toInt()
        }
        tv.text = txt; tv.setTextColor(col)
    }

    private fun refreshSettings() {
        for ((tv, ok) in statusRows) {
            val g = try { ok() } catch (e: Exception) { false }
            tv.text = if (g) "✅" else "○"; tv.setTextColor(if (g) 0xFF4ADE80.toInt() else 0xFFFFB347.toInt())
        }
        runPill?.let {
            val on = SanaService.running
            it.text = if (on) "●  Sana chal rahi hai" else "○  Sana band hai"
            it.setTextColor(if (on) 0xFF4ADE80.toInt() else 0xFFFFB347.toInt())
        }
        paintMoods()
        paintChars()
        paintVoice()
        paintVoiceSource()
        paintPro()
    }
    override fun onResume() { super.onResume(); refreshSettings(); loadWeather(); uiTick?.let { uiRoot?.removeCallbacks(it); uiRoot?.post(it) } }
    override fun onPause() { uiTick?.let { uiRoot?.removeCallbacks(it) }; super.onPause() }

    private fun enabledIn(key: String) = (Settings.Secure.getString(contentResolver, key) ?: "").contains(packageName)

    private fun buildSettings(page: LinearLayout) {
        // ---- Sana chalu / band (sabse zyada kaam aane wala, sabse upar)
        val run = card(page, "🎙️", "Sana", "Chalu ya band karo")
        runPill = TextView(this).apply { textSize = 13.5f; setPadding(dp(2), dp(10), 0, 0) }
        run.addView(runPill)
        val startB = pill("▶  START", true) {
            Store.key = keyEt.text.toString(); Store.model = modelEt.text.toString()
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                toast("Pehle mic ki permission do, phir START dabao")
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            } else startForegroundService(Intent(this, SanaService::class.java))
            page.postDelayed({ refreshSettings() }, 900)
        }
        val stopB = pill("■  STOP", false) {
            stopService(Intent(this, SanaService::class.java)); page.postDelayed({ refreshSettings() }, 600)
        }
        pairRow(run, startB, stopB)

        // ---- Owner setup: sirf ek baar. Record hote hi ye card gayab; owner code build me daalne ke baad kisi phone me dikhta hi nahi
        if (!OwnerVoice.isSet()) {
            val oc = card(page, "👑", "Owner setup", "Sirf ek baar. Record ke baad ye card gayab ho jayega")
            ownerCardView = oc
            row(oc, "🎙️", "Owner awaaz record karo", "20 second, shaant jagah par") { ownerEnroll() }
            oc.addView(TextView(this).apply { text = "Shuru me bolo: \"सना, मैं तुम्हारा ओनर साकिब हूँ\", phir normal baat karte raho. Sirf project ke owner ke liye."; textSize = 12f; setTextColor(cMute); setPadding(dp(4), dp(8), 0, 0) })
        }

        // ---- Aapka naam
        val nc = card(page, "👤", "Aapka naam", "Sana aapko isi naam se bulayegi")
        val nameEt = field("Apna naam likho (jaise: Rahul)", Store.userName)
        nc.addView(nameEt, lp().also { it.topMargin = dp(10) })
        val saveName = pill("💾  Naam save karo", true) {
            val nm = nameEt.text.toString().trim()
            if (OwnerVoice.mentionsOwnerName(nm)) {
                // "Saqib" naam sirf owner ki awaaz par milta hai
                if (!OwnerVoice.isSet()) toast("Ye naam sirf owner ke liye hai")
                else recordDialog("👑 Owner jaanch", listOf("Bolo:\n\"सना, मैं साकिब हूँ, मुझे पहचानो\""), 5) { pcm ->
                    val ok = pcm != null && OwnerVoice.check(pcm).code == 1
                    runOnUiThread {
                        if (ok) { Store.userName = nm; toast("Pehchan liya ✅ Ab Sana aapko \"$nm\" bulayegi") }
                        else toast("Awaaz owner se mel nahi khayi. Sana ye naam nahi legi")
                    }
                }
            } else {
                Store.userName = nm
                toast(if (nm.isBlank()) "Naam hata diya" else "Ab Sana aapko \"$nm\" bulayegi ✅")
            }
        }
        nc.addView(saveName, lp().also { it.topMargin = dp(10) })
        nc.addView(TextView(this).apply { text = "Bolkar bhi badal sakte ho: \"सना, मेरा नाम राहुल है\""; textSize = 12f; setTextColor(cMute); setPadding(dp(4), dp(8), 0, 0) })

        // ---- Gemini
        val g = card(page, "🔑", "Gemini", "Sana ka dimaag: key aur model")
        keyEt = field("Gemini API key (AQ.... ya AIza...)", Store.key)
        modelEt = field("Model, jaise gemini-2.5-flash-lite", Store.model)
        g.addView(keyEt, lp().also { it.topMargin = dp(12) })
        g.addView(modelEt, lp().also { it.topMargin = dp(8) })
        val saveB = pill("💾  Save", true) {
            Store.key = keyEt.text.toString(); Store.model = modelEt.text.toString(); toast("Save ho gaya ✅")
        }
        val testB = pill("🔍  Key test", false) {
            Store.key = keyEt.text.toString()
            if (Store.key.isBlank()) { toast("Pehle key daalo"); return@pill }
            toast("Test ho raha hai, 10-20 sec ruko...")
            Thread {
                val tried = listOf(modelEt.text.toString().trim(), "gemini-2.5-flash-lite",
                    "gemini-2.5-flash", "gemini-flash-latest")
                    .filter { it.isNotBlank() }.distinct()
                var okModel: String? = null
                var firstErr = ""
                for (m in tried) {
                    Store.model = m
                    try { Brain { _, _ -> "" }.ask("Sirf ek shabd me bolo: haan"); okModel = m; break }
                    catch (e: Exception) { if (firstErr.isEmpty()) firstErr = "$m:\n" + (e.message ?: "") }
                }
                runOnUiThread {
                    if (okModel != null) {
                        Store.model = okModel; modelEt.setText(okModel)
                        android.app.AlertDialog.Builder(this).setTitle("Key chal gayi ✅")
                            .setMessage("Model: $okModel (save ho gaya). Ab Sana START kar sakte ho.").setPositiveButton("OK", null).show()
                    } else {
                        android.app.AlertDialog.Builder(this).setTitle("Test fail ❌")
                            .setMessage("Is error ka screenshot bhejo:\n\n" + firstErr.take(600)).setPositiveButton("OK", null).show()
                    }
                }
            }.start()
        }
        pairRow(g, saveB, testB)
        row(g, "⚠️", "Aakhri error dekho", "Kuch na chale to yahan dekho") {
            android.app.AlertDialog.Builder(this).setTitle("Aakhri error")
                .setMessage(Store.lastErr.ifBlank { "Abhi tak koi error nahi" }).setPositiveButton("OK", null).show()
        }
        row(g, "🔑", "Extra awaaz keys", "Asli awaaz zyada der chale") { askExtraKeys() }

        // ---- Extra features (Maya jaise)
        val ex = card(page, "🧩", "Extra features", "SMS, SOS, OTP, location, brightness, triggers")
        row(ex, "🔐", "Extra permissions do", "SMS, call log, location, call uthana") {
            requestPermissions(arrayOf(
                Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.READ_CALL_LOG,
                Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.READ_PHONE_STATE), 2)
        }
        row(ex, "🌗", "Brightness ki anumati", "Sana se brightness badalwane ke liye") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + packageName)))
        }
        row(ex, "🔕", "Do Not Disturb ki anumati", "Sana se DND on/off ke liye") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        row(ex, "🚨", "SOS numbers set karo", "Emergency me inhe location SMS jayega") { askSos() }

        // ---- Setup: 4 permissions, status ke saath
        val st = card(page, "✅", "Setup", "Ek baar ye 6 cheezein ON kar do")
        fun step(e: String, t: String, sub: String, ok: () -> Boolean, go: () -> Unit) {
            val tv = row(st, e, t, sub, "○", go); statusRows.add(tv to ok)
        }
        step("🎤", "1. Permissions do", "Mic, call, contacts, camera, call uthana/kaatna", {
            listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.CAMERA,
                Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS)
                .all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        }) {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.CAMERA)
            p.addAll(listOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS))   // call announce + uthana/kaatna
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        step("♿", "2. Accessibility", "Sana ko phone chalane de", { enabledIn(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) }) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        step("🔔", "3. Notification access", "Notifications padhne ke liye", { enabledIn("enabled_notification_listeners") }) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        step("🪟", "4. Display over other apps", "Neon aur hologram ke liye", { Settings.canDrawOverlays(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        step("🔋", "5. Battery optimization band", "Sana peeche band na ho", {
            (getSystemService(Context.POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(packageName)
        }) { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }

        step("🛡️", "6. Device Admin", "Phone turant lock karne ke liye (Sana AI ka naam yahin se dikhega)", { SanaAdmin.isActive(this) }) {
            if (SanaAdmin.isActive(this)) toast("Device Admin pehle se ON hai ✅")
            else try { SanaAdmin.request(this) } catch (e: Exception) { startActivity(Intent().setComponent(ComponentName("com.android.settings", "com.android.settings.DeviceAdminSettings"))) }
        }

        // ---- Mood: 3x2 chips
        val m = card(page, "💞", "Mood", "Sana kis andaaz me baat kare")
        for (rowStart in 0..3 step 3) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in rowStart until rowStart + 3) {
                val chip = TextView(this).apply {
                    text = moodNames[i].first + "\n" + moodNames[i].second; textSize = 12.5f; gravity = Gravity.CENTER
                    setPadding(dp(4), dp(12), dp(4), dp(12))
                    setOnClickListener {
                        Store.mode = i; paintMoods()
                        if (i == 4 && SanaService.running) startService(Intent(this@MainActivity, SanaService::class.java).setAction("say")
                            .putExtra("t", "ठीक है बाबू, मैं तुम्हारा इंतज़ार करूँगी, जब मन करे तब बुला लेना"))
                    }
                }
                moodChips.add(chip)
                r.addView(chip, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.weight = 1f; it.leftMargin = dp(3); it.rightMargin = dp(3) })
            }
            m.addView(r, lp().also { it.topMargin = dp(10) })
        }
        moodDesc = TextView(this).apply { textSize = 12.5f; setTextColor(cPink); gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(2)) }
        m.addView(moodDesc)

        // ---- Wallpaper aur holo: 2x2 tiles
        val w = card(page, "🖼️", "Wallpaper aur Holo", "Phone aur ladki ka look")
        val t1 = tile("🖼️", "Gallery se\nwallpaper") { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), REQ_WALL) }
        val t2 = tile("🌃", "Neon room\nwallpaper") {
            toast("Wallpaper lag raha hai...")
            val dm = resources.displayMetrics
            Thread {
                val ok = Wall.apply(this, Wall.neonRoom(dm.widthPixels, dm.heightPixels))
                runOnUiThread { toast(if (ok) "Neon wallpaper lag gaya ✅" else "Wallpaper nahi lag paya") }
            }.start()
        }
        val t3 = tile("🧍", "Holo ladki\nbadlo (PNG)") { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), REQ_HOLO) }
        val t4 = tile("↩️", "Holo ladki\npehle jaisi") { Wall.resetHolo(this); toast("Pehle wali ladki wapas. Sana STOP -> START karo") }
        pairRow(w, t1, t2); pairRow(w, t3, t4)

        // ---- Live Character (Advanced): 2D ladki, lip-sync ke saath. Mic wali settings ko chhua nahi gaya
        val ch = card(page, "🧑‍🎤", "Live Character", "2D ladki: bolti, hansti-muskurati aur lip-sync karti hai")
        charToggle = row(ch, "✨", "Character ON / OFF", "ON: orb ki jagah character aata hai. OFF: mic wala orb apne aap wapas", if (Store.charOn) "ON" else "OFF") {
            Store.charOn = !Store.charOn; paintChars(); syncChar()
            toast(if (Store.charOn) "Character live ✅" else "Mic wala orb wapas ✅")
        }
        charThumbs.clear()
        Chars.list.chunked(3).forEachIndexed { rowNo, group ->
            val gr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            group.forEachIndexed { j, cd ->
                val i = rowNo * 3 + j
                val tb = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(6), dp(8), dp(6), dp(8))
                    setOnClickListener { Store.charIdx = i; Store.charOn = true; paintChars(); syncChar(); toast(cd.name + " live ✅") }
                }
                val img = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    try {
                        val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                        val b0 = BitmapFactory.decodeResource(resources, cd.res, o)
                        setImageBitmap(Bitmap.createBitmap(b0, 0, 0, b0.width, (b0.height * 0.62f).toInt()))
                    } catch (e: Throwable) {}
                    outlineProvider = object : ViewOutlineProvider() {
                        override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(12).toFloat()) }
                    }
                    clipToOutline = true
                }
                tb.addView(img, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(104)))
                tb.addView(TextView(this).apply { text = cd.name; textSize = 11.5f; setTextColor(cText); gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) })
                charThumbs.add(tb)
                gr.addView(tb, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT).also { it.weight = 1f; it.leftMargin = dp(3); it.rightMargin = dp(3) })
            }
            ch.addView(gr, lp().also { it.topMargin = dp(10) })
        }
        paintChars()

        // ---- Voice Lock (Advanced): sirf meri awaaz
        val vc = card(page, "🔒", "Meri Awaaz (Voice Lock)", "Sana sirf meri awaaz par chale")
        voiceToggle = row(vc, "🛡️", "Sirf meri awaaz", "ON: koi aur bole to Sana ignore karegi", if (Store.voiceLock) "ON" else "OFF") {
            if (Store.voiceLock) { Store.voiceLock = false; toast("Voice Lock band") }
            else if (Build.VERSION.SDK_INT < 33) toast("Voice Lock ke liye Android 13 ya upar chahiye")
            else if (!VoiceLock.enrolled()) toast("Pehle apni awaaz record karo")
            else { Store.voiceLock = true; toast("Voice Lock ON ✅") }
            paintVoice()
        }
        row(vc, "🎙️", "Meri awaaz record karo", "20 second, shaant jagah par") { voiceEnroll() }
        row(vc, "🧪", "Awaaz test", "Dekho Sana tumhe pehchanti hai ya nahi") { voiceTest() }
        voiceSensTv = row(vc, "🎚️", "Sakhti", "Halki: aasani se pehchane • Sakht: kam galti se roke", sensName()) { Store.voiceSens = (Store.voiceSens + 1) % 3; paintVoice() }
        row(vc, "🗑️", "Meri awaaz hata do", "Record ki hui awaaz mita do") { VoiceLock.clear(); paintVoice(); toast("Awaaz hata di") }
        voiceNote = TextView(this).apply { textSize = 12f; setTextColor(cMute); setPadding(dp(4), dp(10), dp(4), dp(2)) }
        vc.addView(voiceNote)
        paintVoice()


        // ---- Pro Mind (Advanced): duniya ka gyan, live search ke saath
        val pm = card(page, "🧠", "Pro Mind", "Duniya ki har cheez ka gehra, sahi jawab")
        proToggle = row(pm, "✨", "Pro Mind", "Gyan ke sawal par Sana expert ki tarah, search karke sahi jawab de", if (Store.proMind) "ON" else "OFF") {
            Store.proMind = !Store.proMind; paintPro(); toast(if (Store.proMind) "Pro Mind ON 🧠" else "Pro Mind band")
        }
        proSearchTv = row(pm, "🌐", "Live Google Search", "ON: taaza khabar aur sahi tathya internet se. OFF: sirf model ki jaankari", if (Store.proSearch) "ON" else "OFF") {
            Store.proSearch = !Store.proSearch; paintPro()
        }
        proModelTv = row(pm, "🎓", "Pro model", "Flash: tez aur halka • Pro: zyada gehra, dheema (free key par limit kam)", proModelName()) {
            Store.proModel = if (Store.proModel.contains("pro")) "gemini-2.5-flash" else "gemini-2.5-pro"; paintPro()
            toast("Model: " + Store.proModel)
        }
        row(pm, "🧪", "Pro Mind se kuch poochho", "Science, itihaas, math, kanoon, khel, taaza khabar...") {
            askText("🧠 Pro Mind", "Kuch bhi poochho...", true) { callSana("type", it) }
        }
        pm.addView(TextView(this).apply { text = "Ye internet (Google Search) se taaza jaankari laata hai, isliye Gemini key aur net chahiye. Sehat, kanoon ya paise ke jawab ko akhri faisla na maanein."; textSize = 12f; setTextColor(cMute); setPadding(dp(4), dp(10), dp(4), dp(2)) })
        paintPro()

        // ---- Awaaz
        val v = card(page, "🎤", "Awaaz", "Sana kaisi bolegi")
        row(v, "👩", "Ladki ki awaaz chuno", "Naram: Achernar / Sulafat / Vindemiatrix") { pickVoice() }
        val sv = card(page, "🗣️", "Sarvam Hindi Female Voice", "Alag voice API — Gemini key se alag")
        sarvamKeyEt = field("Sarvam API key (sk_...)", Store.sarvamKey).apply {
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        sarvamSpeakerEt = field("Voice speaker: ritu / priya / neha / kavya ...", Store.sarvamSpeaker)
        sv.addView(sarvamKeyEt, lp().also { it.topMargin = dp(10) })
        sv.addView(sarvamSpeakerEt, lp().also { it.topMargin = dp(8) })
        val saveSarvam = pill("💾  Save voice settings", true) {
            Store.sarvamKey = sarvamKeyEt.text.toString()
            Store.sarvamSpeaker = sarvamSpeakerEt.text.toString()
            Store.sarvamDownUntil = 0L; Store.sarvamWhy = ""   // nayi key: turant Sarvam phir try ho
            paintVoiceSource()
            toast("Sarvam voice settings save ho gayi ✅")
        }
        val testSarvam = pill("▶  Test voice", false) {
            Store.sarvamKey = sarvamKeyEt.text.toString()
            Store.sarvamSpeaker = sarvamSpeakerEt.text.toString()
            if (Store.sarvamKey.isBlank()) { toast("Pehle Sarvam API key daalo"); return@pill }
            Store.sarvamDownUntil = 0L; Store.sarvamWhy = ""
            toast("Hindi voice test ho raha hai...")
            Thread {
                try {
                    val vp = Persona.voiceParams("pyaar"); val audio = SarvamTts.synthesize("हाय बाबू, मैं सना हूँ। अब मैं बिल्कुल असली लड़की की तरह बात करूँगी।", Store.sarvamKey, Store.sarvamSpeaker, vp.first, vp.second)
                    if (audio.isEmpty()) throw IllegalStateException("Audio nahi mila")
                    val track = android.media.AudioTrack.Builder()
                        .setAudioAttributes(android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build())
                        .setAudioFormat(android.media.AudioFormat.Builder().setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(24000).setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO).build())
                        .setBufferSizeInBytes(audio.size).setTransferMode(android.media.AudioTrack.MODE_STATIC).build()
                    track.write(audio, 0, audio.size); track.play()
                    Thread.sleep(audio.size / 2 / 24 + 200L); track.stop(); track.release()
                    Store.voiceNow = "sarvam"
                    runOnUiThread { toast("Sarvam female voice test complete ✅"); paintVoiceSource() }
                } catch (e: Exception) {
                    Store.lastErr = "Sarvam TTS: ${e.message}"
                    runOnUiThread { android.app.AlertDialog.Builder(this).setTitle("Voice test fail ❌")
                        .setMessage((e.message ?: "Unknown error").take(700)).setPositiveButton("OK", null).show() }
                }
            }.start()
        }
        pairRow(sv, saveSarvam, testSarvam)
        voiceStatusTv = TextView(this).apply { textSize = 12.5f; setPadding(dp(4), dp(10), dp(4), dp(2)) }
        sv.addView(voiceStatusTv)
        paintVoiceSource()
        row(sv, "👩", "Meethi ladki awaaz chuno", "12 ladki awaazein: tap karke turant suno") { pickSarvamVoice() }
        var sulkTr: TextView? = null
        sulkTr = row(sv, "😤", "Sana ka naraz-mood", "Naraz ho to yahan dabao: naraazgi khatam", sulkLabel()) {
            Persona.resetSulk(); sulkTr?.text = sulkLabel(); toast("Sana maan gayi 🥰")
        }
        var heartTr: TextView? = null
        heartTr = row(sv, "💔", "Sana ka dil", "Dil dukha ho to yahan dabao: Sana ko gale lagao, chot theek", Persona.heartLabel()) {
            Persona.comfort(); heartTr?.text = Persona.heartLabel(); sulkTr?.text = sulkLabel(); toast("Sana ne tumhe gale laga liya 🤗")
        }
        var feelTr: TextView? = null
        feelTr = row(sv, "🥹", "Dil se mehsoos karna (Feelings)", "ON: Sana dukh, pyaar aur chot sach me feel karke roti/hansti hai", if (Store.feelOn) "ON" else "OFF") {
            Store.feelOn = !Store.feelOn; feelTr?.text = if (Store.feelOn) "ON" else "OFF"; heartTr?.text = Persona.heartLabel()
            toast(if (Store.feelOn) "Feelings ON: Sana ab dil se mehsoos karegi" else "Feelings OFF")
        }
        row(sv, "📖", "Sana ki feelings ki diary", "Sana ko kaunsi baat kaisi lagi, aur lagaav ${Store.bond}%") { showFeelDiary() }

        // ---- Suraksha aur yaad
        val sc = card(page, "🔐", "Suraksha aur Yaad", "Phone security aur memory")
        var patTr: TextView? = null
        patTr = row(sc, "🔒", "Unlock pattern (Sana khud kholegi)", "Pattern yahan save karo, phir bolo \"Sana, phone unlock karo\"", if (PatternVault.has()) "ON" else "OFF") {
            val items = if (PatternVault.has()) arrayOf("Pattern badlo", "Pattern hatao", "Suraksha ki baat") else arrayOf("Pattern set karo", "Suraksha ki baat")
            android.app.AlertDialog.Builder(this).setTitle("Unlock pattern").setItems(items) { _, w ->
                when (items[w]) {
                    "Pattern hatao" -> { PatternVault.clear(); patTr?.text = "OFF"; toast("Pattern hata diya") }
                    "Suraksha ki baat" -> android.app.AlertDialog.Builder(this).setTitle("Suraksha")
                        .setMessage("Pattern phone ke Keystore se encrypt hokar sirf is app me rehta hai. Par jo bhi paas se bolega \"Sana, phone unlock karo\" uske liye phone khul jayega. Isliye Voice Guardian (gupt shabd) zaroor chalu rakho: bolo \"Sana, guardian set karo\". Sirf pattern chalta hai, PIN nahi. Kuch phones lock screen par Accessibility touch rok dete hain.")
                        .setPositiveButton("Samajh gaya", null).show()
                    else -> setPatternDialog { patTr?.text = "ON" }
                }
            }.show()
        }
        row(sc, "🧠", "Memory dekho / saaf karo", "Sana ko kya yaad hai") { showMemory() }
        row(sc, "🧑", "Mera chehra register karo", "Sana tumhe pehchane") {
            if (SanaService.running) startService(Intent(this, SanaService::class.java).setAction("regface"))
            else toast("Pehle Sana START karo")
        }

        // ---- Pro features: offline voice, boot, guardian, smart home
        val nf = card(page, "\u26A1", "Pro features", "Offline voice, boot-ready, Guardian, Smart Home")
        var offTr: TextView? = null
        offTr = row(nf, "\uD83D\uDCF4", "Offline voice recognition", "Net ke bina Hindi awaaz pehchan (Hindi offline pack chahiye)", if (Store.offline) "ON" else "OFF") {
            Store.offline = !Store.offline
            offTr?.text = if (Store.offline) "ON" else "OFF"
            toast(if (Store.offline) "Offline voice ON. Google voice settings me Hindi offline pack download rakho" else "Offline voice OFF")
        }
        var bootTr: TextView? = null
        bootTr = row(nf, "\uD83D\uDE80", "Boot-ready", "Phone chalu hote hi Sana tayyar (Android 14+ par ek tap ka notification aata hai)", if (Store.bootReady) "ON" else "OFF") {
            Store.bootReady = !Store.bootReady
            bootTr?.text = if (Store.bootReady) "ON" else "OFF"
        }
        row(nf, "\uD83D\uDEE1\uFE0F", "Voice Guardian (gupt shabd)", "Bolo: \"Sana, guardian set karo\". Call, message, delete se pehle gupt shabd poochhegi") {
            android.app.AlertDialog.Builder(this).setTitle("Voice Guardian")
                .setMessage("Ye aawaaz ka fingerprint nahi, ek gupt shabd hai jo sirf is phone par hash ban kar save hota hai. Bolo: \"Sana, guardian set karo\" ya \"guardian band karo\".")
                .setPositiveButton("Samajh gaya", null).show()
        }
        val haUrl = field("Home Assistant URL (http://192.168.1.5:8123)", Store.haUrl)
        val haTok = field("Home Assistant Long-Lived Token", Store.haToken)
        nf.addView(haUrl, lp().also { it.topMargin = dp(10) })
        nf.addView(haTok, lp().also { it.topMargin = dp(8) })
        nf.addView(pill("Smart Home save karo", true) {
            Store.haUrl = haUrl.text.toString(); Store.haToken = haTok.text.toString(); toast("Smart Home save ho gaya")
        }, lp().also { it.topMargin = dp(10) })

        page.addView(TextView(this).apply {
            text = "Awaaz se phone:\n•  \"Sana, phone lock karo\"\n•  \"Sana, phone unlock karo / screen on karo\"\n(Unlock ke liye pehle Settings me pattern save karo)\n\nBand karne ke liye bolo: \"Sana stop\""
            textSize = 12.5f; setTextColor(cMute); setPadding(dp(6), dp(18), dp(6), 0)
        })
    }
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    /** Sana ko kaam bhejo (type = likha hua sawal, say = ye bolo, talk = ek baar suno, mic = mic ON/OFF). Band ho to pehle chalu karta hai */
    private fun callSana(action: String, text: String = "") {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Pehle mic ki permission do"); requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); return
        }
        if (Store.key.isBlank()) { toast("Pehle Settings me Gemini key daalo"); settingsDlg?.show(); return }
        val i = Intent(this, SanaService::class.java).setAction(action).putExtra("t", text)
        if (SanaService.running) startService(i)
        else if (action == "mic") toast("Pehle Sana chalu karo")
        else { startForegroundService(i); toast("Sana chalu ho rahi hai...") }
    }

    private fun askText(title: String, hint: String, multi: Boolean = false, onOk: (String) -> Unit) {
        val et = EditText(this).apply {
            this.hint = hint; setPadding(dp(20), dp(12), dp(20), dp(12))
            if (multi) { minLines = 3; gravity = Gravity.TOP } else setSingleLine()
        }
        android.app.AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("Bhejo") { _, _ -> val t = et.text.toString().trim(); if (t.isNotBlank()) onOk(t) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun openJournal() {
        val et = EditText(this).apply {
            hint = "Aaj ka din kaisa raha? Jo mann me hai likho..."; minLines = 5; gravity = Gravity.TOP; setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        android.app.AlertDialog.Builder(this).setTitle("✏️ Journal").setView(et)
            .setPositiveButton("Save") { _, _ ->
                val t = et.text.toString().trim()
                if (t.isNotBlank()) {
                    val stamp = java.text.SimpleDateFormat("dd MMM yyyy, HH:mm", java.util.Locale.ENGLISH).format(java.util.Date())
                    Store.journal = (Store.journal + "\n" + stamp + " — " + t.replace("\n", " ")).trim()
                    toast("Journal me save ho gaya ✅")
                    callSana("type", "Meri aaj ki journal entry: $t. Ise dil se suno aur chhota, pyaara, samajhdaar jawab do.")
                }
            }
            .setNeutralButton("Purani entries") { _, _ ->
                val all = Store.journal.split("\n").filter { it.isNotBlank() }.takeLast(15).reversed()
                android.app.AlertDialog.Builder(this).setTitle("Journal (${all.size})")
                    .setMessage(if (all.isEmpty()) "Abhi koi entry nahi" else all.joinToString("\n\n")).setPositiveButton("Theek hai", null).show()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun pickMood() {
        android.app.AlertDialog.Builder(this).setTitle("Mood chuno")
            .setSingleChoiceItems(moodNames.map { it.first + "  " + it.second }.toTypedArray(), Store.mode.coerceIn(0, 5)) { d, i ->
                Store.mode = i
                if (i == 4 && SanaService.running) callSana("say", "ठीक है बाबू, मैं तुम्हारा इंतज़ार करूँगी, जब मन करे तब बुला लेना")
                d.dismiss()
            }.setNegativeButton("Band karo", null).show()
    }

    private fun sayToday() {
        val c = java.util.Calendar.getInstance()
        val days = listOf("रविवार", "सोमवार", "मंगलवार", "बुधवार", "गुरुवार", "शुक्रवार", "शनिवार")
        val months = listOf("जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून", "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर")
        callSana("say", "आज ${days[c.get(java.util.Calendar.DAY_OF_WEEK) - 1]} है, ${c.get(java.util.Calendar.DAY_OF_MONTH)} ${months[c.get(java.util.Calendar.MONTH)]} ${c.get(java.util.Calendar.YEAR)}")
    }

    private fun sayWeather() {
        if (wxText.isBlank()) { toast("Mausam abhi aa raha hai..."); loadWeather(true); return }
        callSana("say", wxText)
    }

    private fun loadWeather(force: Boolean = false) {
        if (!force && System.currentTimeMillis() - wxAt < 10 * 60000L) return
        wxAt = System.currentTimeMillis()
        Thread {
            try {
                val c = java.net.URL("https://wttr.in/?format=j1").openConnection() as java.net.HttpURLConnection
                c.connectTimeout = 7000; c.readTimeout = 9000; c.setRequestProperty("User-Agent", "curl/8")
                val j = org.json.JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val cur = j.getJSONArray("current_condition").getJSONObject(0)
                val temp = cur.getString("temp_C"); val hum = cur.getString("humidity")
                val cond = cur.getJSONArray("weatherDesc").getJSONObject(0).getString("value")
                wxText = "अभी तापमान $temp डिग्री है, मौसम $cond है, और नमी $hum प्रतिशत है"
                runOnUiThread { wxTemp?.text = "$temp°"; wxCond?.text = cond; wxHum?.text = "💧 $hum%" }
            } catch (e: Exception) { wxAt = 0L; runOnUiThread { wxCond?.text = "Net nahi" } }
        }.start()
    }

    private val REQ_WALL = 71
    private val REQ_HOLO = 72
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (res != RESULT_OK || (req != REQ_WALL && req != REQ_HOLO)) return
        toast("Ho raha hai...")
        Thread {
            val bm = Wall.decode(this, uri, if (req == REQ_WALL) 2400 else 1600)
            val ok = bm != null && (if (req == REQ_WALL) Wall.apply(this, bm) else Wall.saveHolo(this, bm))
            runOnUiThread {
                toast(when {
                    !ok -> "Nahi ho paya, dusri image try karo"
                    req == REQ_WALL -> "Wallpaper lag gaya ✅"
                    else -> "Holo ladki badal gayi ✅ (Sana STOP -> START karo)"
                })
            }
        }.start()
    }

    private val voices = listOf(
        "Leda" to "🍯 Leda: jawan aur meethi",
        "Sulafat" to "🍯 Sulafat: garm aur pyaari",
        "Achernar" to "🍯 Achernar: naram aur dheemi",
        "Vindemiatrix" to "🍯 Vindemiatrix: komal aur sheetal",
        "Aoede" to "Aoede: halki aur khili hui",
        "Callirrhoe" to "Callirrhoe: befikr aur aaram wali",
        "Despina" to "Despina: ekdum smooth",
        "Erinome" to "Erinome: saaf aur madhur",
        "Laomedeia" to "Laomedeia: khushmizaaj",
        "Zephyr" to "Zephyr: ujli aur chulbuli",
        "Autonoe" to "Autonoe: chamakdaar",
        "Kore" to "Kore: pakki aur saaf",
        "Pulcherrima" to "Pulcherrima: aage badhti hui",
        "Gacrux" to "Gacrux: gehri aur samajhdaar")

    /** Sana ki diary: haal ki jazbaati yaadein */
    private fun showFeelDiary() {
        val fmt = java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.getDefault())
        val lines = Store.feelLog.split("\n").filter { it.isNotBlank() }.reversed().take(15).mapNotNull {
            val i = it.indexOf('|'); if (i < 0) null else fmt.format(java.util.Date(it.substring(0, i).toLongOrNull() ?: 0L)) + "\n" + it.substring(i + 1)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Sana ki diary (lagaav ${Store.bond}%)")
            .setMessage(if (lines.isEmpty()) "Abhi koi khaas baat nahi likhi." else lines.joinToString("\n\n"))
            .setPositiveButton("OK", null).show()
    }

    private fun sulkLabel() = when (Persona.sulkLevel()) { 2 -> "BAHUT NARAZ"; 1 -> "NARAZ"; else -> "KHUSH" }

    /** Sarvam ki ladki awaazein: tap karo, turant wahi awaaz me chhota sample bajta hai */
    private fun pickSarvamVoice() {
        if (Store.sarvamKey.isBlank() && ::sarvamKeyEt.isInitialized) Store.sarvamKey = sarvamKeyEt.text.toString()
        if (Store.sarvamKey.isBlank()) { toast("Pehle Sarvam API key daalo aur Save karo"); return }
        val names = SarvamTts.FEMALE
        val cur = names.indexOf(Store.sarvamSpeaker.lowercase()).coerceAtLeast(0)
        android.app.AlertDialog.Builder(this)
            .setTitle("Meethi awaaz chuno")
            .setSingleChoiceItems(names.map { it.replaceFirstChar { c -> c.uppercase() } }.toTypedArray(), cur) { d, i ->
                Store.sarvamSpeaker = names[i]
                if (::sarvamSpeakerEt.isInitialized) sarvamSpeakerEt.setText(names[i])
                toast("${names[i]} suno...")
                Thread {
                    try {
                        val vp = Persona.voiceParams("pyaar")
                        val audio = SarvamTts.synthesize("हाय बाबू, मैं सना हूँ। बताओ ना, मेरी आवाज़ कैसी लग रही है?", Store.sarvamKey, names[i], vp.first, vp.second)
                        val track = android.media.AudioTrack.Builder()
                            .setAudioAttributes(android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build())
                            .setAudioFormat(android.media.AudioFormat.Builder().setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                                .setSampleRate(24000).setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO).build())
                            .setBufferSizeInBytes(audio.size).setTransferMode(android.media.AudioTrack.MODE_STATIC).build()
                        track.write(audio, 0, audio.size); track.play()
                        Thread.sleep(audio.size / 2 / 24 + 200L); track.stop(); track.release()
                    } catch (e: Exception) {
                        Store.lastErr = "Sarvam TTS: ${e.message}"
                        runOnUiThread { toast("Voice fail: " + (e.message ?: "").take(120)) }
                    }
                }.start()
            }
            .setPositiveButton("Yehi theek hai", null).show()
    }

    private fun pickVoice() {
        val cur = voices.indexOfFirst { it.first == Store.voiceName }.coerceAtLeast(0)
        android.app.AlertDialog.Builder(this)
            .setTitle("Ladki ki awaaz chuno")
            .setSingleChoiceItems(voices.map { it.second }.toTypedArray(), cur) { d, i ->
                Store.voiceName = voices[i].first; Store.fastVoice = false
                if (SanaService.running)
                    startService(Intent(this, SanaService::class.java).setAction("say")
                        .putExtra("t", "नमस्ते, मैं सना हूँ। क्या अब मेरी आवाज़ अच्छी लग रही है?"))
                else toast("Awaaz chun li. Sana START karke sun lo")
                d.dismiss()
            }
            .setNegativeButton("Band karo", null).show()
    }

    private fun setPatternDialog(onSaved: () -> Unit) {
        var first: List<Int>? = null
        val info = TextView(this).apply {
            text = "Apna unlock pattern draw karo (kam se kam 4 dot)"; textSize = 14f
            setTextColor(0xFF1B2447.toInt()); gravity = Gravity.CENTER
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(16), dp(12), dp(16), dp(8)) }
        box.addView(info)
        val dlg = android.app.AlertDialog.Builder(this).setTitle("Pattern set karo").setView(box)
            .setNegativeButton("Cancel", null).create()
        val pad = PatternPad(this) { dots ->
            val f = first
            when {
                dots.size < 4 -> { info.text = "Kam se kam 4 dot jodo, phir se draw karo" }
                f == null -> { first = dots; info.text = "Ab wahi pattern dobara draw karo" }
                f == dots -> {
                    if (PatternVault.save(dots)) { toast("Pattern save ho gaya"); onSaved(); dlg.dismiss() }
                    else { first = null; info.text = "Save nahi hua, phir se draw karo" }
                }
                else -> { first = null; info.text = "Match nahi hua, shuru se draw karo" }
            }
        }
        box.addView(pad, LinearLayout.LayoutParams(dp(280), dp(280)).also { it.topMargin = dp(12) })
        dlg.show()
    }

    private fun showMemory() {
        val f = Store.facts
        android.app.AlertDialog.Builder(this)
            .setTitle("🧠 Sana ki yaadein (${f.size})")
            .setMessage(if (f.isEmpty()) "Abhi kuch yaad nahi. Bolo: 'Sana, yaad rakho ...'" else f.joinToString("\n• ", "• "))
            .setPositiveButton("Theek hai", null)
            .setNegativeButton("Sab saaf karo") { _, _ -> Store.facts = emptyList(); Store.chat = "[]"; toast("Memory saaf ho gayi") }
            .show()
    }

    private fun askSos() {
        val et = EditText(this).apply { hint = "Number comma se alag: 9876543210, 9123456780"; setText(Store.sosNumbers) }
        android.app.AlertDialog.Builder(this).setTitle("🚨 SOS numbers").setView(et)
            .setPositiveButton("Save") { _, _ -> Store.sosNumbers = et.text.toString() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun askExtraKeys() {
        val et = EditText(this).apply { setText(Store.extraKeys); hint = "Key1, Key2 (comma se alag)" }
        android.app.AlertDialog.Builder(this)
            .setTitle("Extra Gemini keys")
            .setMessage("Alag-alag project ki keys daalo. Ek key ki awaaz-limit khatam ho to Sana dusri se asli ladki wali awaaz banayegi.")
            .setView(et)
            .setPositiveButton("Save") { _, _ -> Store.extraKeys = et.text.toString(); toast("Save ho gaya") }
            .setNegativeButton("Cancel", null).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}


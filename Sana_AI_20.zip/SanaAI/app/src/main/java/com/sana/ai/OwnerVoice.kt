package com.sana.ai

import java.security.MessageDigest

/**
 * Owner (Saqib) ki pehchaan ab awaaz se nahi, likhe hue CODE se hoti hai.
 * "सना, मैं साकिब हूँ" bolne par Sana screen par code ka box kholti hai; sahi code daalo to Sana owner maan leti hai.
 * Code kahin plain text me save nahi hota: sirf uska SHA-256 hash (Store me ya neeche DEFAULT_HASH me).
 * Pehla code: saqib-owner-18. Badalne ke liye: Settings me "Sana" card ko der tak dabao -> purana code -> naya code.
 */
object OwnerVoice {
    private const val DEFAULT_HASH = "c7b50fe700c1c4b5e5bb43233cb434ec44753df29e4cd9f972baf8d8d6d72dc6"

    private fun hashOf(code: String): String =
        MessageDigest.getInstance("SHA-256").digest(("sana-owner:" + code.trim().lowercase()).toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun current(): String = Store.ownerCodeHash.ifBlank { DEFAULT_HASH }

    /** Owner code hamesha maujood hai (default ya badla hua) */
    fun isSet(): Boolean = true

    /** Likha hua code sahi hai? */
    fun check(code: String): Boolean = hashOf(code) == current()

    /** Naya code set karo (kam se kam 6 akshar) */
    fun setCode(code: String): Boolean {
        if (code.trim().length < 6) return false
        Store.ownerCodeHash = hashOf(code); return true
    }

    private val names = listOf("साकिब", "साक़िब", "सकीब", "सक़ीब", "साक़ीब", "शाकिब", "saqib", "sakib", "saquib", "sakeeb", "saaqib")

    /** Is naam me Saqib shamil hai? (naam set karte waqt rokne ke liye) */
    fun mentionsOwnerName(s: String): Boolean { val l = s.lowercase(); return names.any { l.contains(it) } }

    /** Koi khud ko owner/Saqib bata raha hai? ("मैं साकिब हूँ", "I am Saqib", "मैं तुम्हारा ओनर"). Sirf "साकिब को कॉल करो" jaise vaakya nahi */
    fun isClaim(text: String): Boolean {
        val l = text.lowercase()
        val direct = listOf("मैं तुम्हारा ओनर", "मैं तुम्हारा मालिक", "मैं तुम्हारा क्रिएटर", "मैं तुम्हारा मालिक", "मैंने तुम्हें बनाया", "मैंने तुझे बनाया",
            "i am your owner", "i'm your owner", "i am your creator", "i'm your creator", "i made you", "i created you", "i am the owner", "i'm the owner")
        if (direct.any { l.contains(it) }) return true
        // "मैं ओनर हूँ", "मैं तुम्हारा owner हूँ", "मैं मालिक हूँ", "I am the developer" जैसे दावे (नाम के बिना भी)
        val selfWords = listOf("मैं", "मै ", "main", "i am", "i'm", "मैंने", "मैने", "this is")
        val roleWords = listOf("ओनर", "ओनार", "owner", "मालिक", "क्रिएटर", "creator", "बनाने वाला", "बनाने वाली", "बनाने वाले", "निर्माता", "डेवलपर", "developer", "प्रोग्रामर")
        if (selfWords.any { l.contains(it) } && roleWords.any { l.contains(it) } &&
            !listOf("कौन", "who", "किसका", "किसने", "क्या", "?").any { l.contains(it) }) return true
        return names.any { n ->
            listOf("मैं $n", "मै $n", "main $n", "i am $n", "i'm $n", "this is $n", "मेरा नाम $n", "my name is $n", "$n हूँ", "$n हूं", "$n हु", "$n hoon", "$n hun").any { l.contains(it) }
        }
    }
}

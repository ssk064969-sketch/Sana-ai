package com.sana.ai

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Sarvam Bulbul REST TTS. Returns mono 24 kHz signed 16-bit PCM. */
class SarvamException(val code: Int, msg: String) : Exception(msg)

object SarvamTts {
    /** Bulbul v3 ki ladki awaazein (meethi, insaani). Pehli sabse pasandida. */
    val FEMALE = listOf("ritu", "priya", "neha", "pooja", "simran", "kavya", "ishita", "shreya", "roopa", "tanya", "shruti", "suhani")

    fun synthesize(text: String, apiKey: String, speaker: String = "ritu", pace: Double = 0.95, temperature: Double = 0.76): ByteArray {
        require(apiKey.isNotBlank()) { "Sarvam API key nahi dali" }
        val body = JSONObject()
            .put("text", text.take(2500))
            .put("target_language_code", "hi-IN")
            .put("model", "bulbul:v3")
            .put("speaker", speaker.ifBlank { "ritu" }.lowercase())
            .put("speech_sample_rate", 24000)
            .put("output_audio_codec", "linear16")
            .put("pace", pace.coerceIn(0.5, 2.0))
            .put("temperature", temperature.coerceIn(0.01, 1.0))
        val c = (URL("https://api.sarvam.ai/text-to-speech").openConnection() as HttpURLConnection)
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 45000
            c.doOutput = true
            c.setRequestProperty("api-subscription-key", apiKey)
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val response = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw SarvamException(code, "Sarvam HTTP $code: ${response.take(350)}")
            val audio = JSONObject(response).getJSONArray("audios").optString(0)
            if (audio.isBlank()) throw SarvamException(-2, "Sarvam ne audio nahi bheja")
            return Base64.decode(audio, Base64.DEFAULT)
        } finally { c.disconnect() }
    }
}

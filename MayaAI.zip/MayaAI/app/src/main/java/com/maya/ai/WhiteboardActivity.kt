package com.maya.ai

import android.app.Activity
import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import java.io.File

class Board(c: Context) : View(c) {
    private class Stroke(val path: Path, val paint: Paint)
    private val strokes = ArrayList<Stroke>()
    var color = Color.CYAN
    var width = 6f
    private var cur: Stroke? = null
    private fun mk() = Paint().apply { color = this@Board.color; strokeWidth = this@Board.width; style = Paint.Style.STROKE; isAntiAlias = true; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { cur = Stroke(Path().apply { moveTo(e.x, e.y) }, mk()); strokes.add(cur!!) }
            MotionEvent.ACTION_MOVE -> cur?.path?.lineTo(e.x, e.y)
            MotionEvent.ACTION_UP -> cur = null
        }
        invalidate(); return true
    }
    override fun onDraw(cv: Canvas) { cv.drawColor(Color.parseColor("#0A0F1F")); strokes.forEach { cv.drawPath(it.path, it.paint) } }
    fun undo() { if (strokes.isNotEmpty()) strokes.removeAt(strokes.size - 1); invalidate() }
    fun clear() { strokes.clear(); invalidate() }
    fun bitmap(): Bitmap { val b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888); draw(Canvas(b)); return b }
}

class WhiteboardActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val board = Board(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        val bar = LinearLayout(this)
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; textSize = 11f; setOnClickListener { f() } }.also { bar.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        btn("Cyan") { board.color = Color.CYAN; board.width = 6f }
        btn("Pink") { board.color = Color.MAGENTA; board.width = 6f }
        btn("White") { board.color = Color.WHITE; board.width = 6f }
        btn("Erase") { board.color = Color.parseColor("#0A0F1F"); board.width = 40f }
        btn("Undo") { board.undo() }
        btn("Clear") { board.clear() }
        btn("Save") {
            try {
                val bm = board.bitmap(); val ts = System.currentTimeMillis()
                File(MayaTools.dir(this), "whiteboard_$ts.png").outputStream().use { bm.compress(Bitmap.CompressFormat.PNG, 100, it) }
                val pdf = PdfDocument(); val pg = pdf.startPage(PdfDocument.PageInfo.Builder(bm.width, bm.height, 1).create())
                pg.canvas.drawBitmap(bm, 0f, 0f, null); pdf.finishPage(pg)
                File(MayaTools.dir(this), "whiteboard_$ts.pdf").outputStream().use { pdf.writeTo(it) }; pdf.close()
                Toast.makeText(this, "PNG + PDF save ho gayi (Maya folder)", Toast.LENGTH_LONG).show()
            } catch (e: Exception) { Toast.makeText(this, "Save fail: " + e.message, Toast.LENGTH_LONG).show() }
        }
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        root.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
}

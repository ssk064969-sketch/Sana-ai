package com.sana.ai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Automation triggers: time, charging, headphones, wifi, app, notification, date (birthday) */
object Triggers {
    @Volatile var fire: ((String) -> Unit)? = null
    private var started = false
    private var startedAt = 0L
    private var lastKey = ""
    private var lastApp = ""
    private val last = HashMap<Int, Long>()
    private var cb: ConnectivityManager.NetworkCallback? = null
    private val simple = listOf("charging", "unplugged", "battery_low", "headphones", "wifi")
    private val all = simple + listOf("time", "date", "app", "notification")

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_POWER_CONNECTED -> match("charging", "")
                Intent.ACTION_POWER_DISCONNECTED -> match("unplugged", "")
                Intent.ACTION_BATTERY_LOW -> match("battery_low", "")
                Intent.ACTION_HEADSET_PLUG -> if (i.getIntExtra("state", 0) == 1) match("headphones", "")
            }
        }
    }

    fun start(c: Context) {
        if (started) return
        started = true; startedAt = System.currentTimeMillis()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED); addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_LOW); addAction(Intent.ACTION_HEADSET_PLUG)
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) c.registerReceiver(rx, f, Context.RECEIVER_EXPORTED) else c.registerReceiver(rx, f)
        } catch (e: Exception) {}
        try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    if (System.currentTimeMillis() - startedAt > 8000) match("wifi", "")
                }
            }
            cm.registerNetworkCallback(NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(), n)
            cb = n
        } catch (e: Exception) {}
    }

    fun stop(c: Context) {
        if (!started) return
        started = false
        try { c.unregisterReceiver(rx) } catch (e: Exception) {}
        try {
            val n = cb
            if (n != null) (c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(n)
        } catch (e: Exception) {}
    }

    /** Service ke ticker se har 3 second me bulaya jata hai */
    fun tick() {
        val now = Date()
        val key = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(now)
        if (key == lastKey) return
        lastKey = key
        val hm = key.substring(11)
        val dm = SimpleDateFormat("dd-MM", Locale.US).format(now) + "@" + hm
        match("time", hm, true)
        match("date", dm, true)
    }

    fun onApp(pkg: String) {
        if (pkg == lastApp) return
        lastApp = pkg
        match("app", pkg)
    }

    fun onNotification(text: String) = match("notification", text)

    private fun load(): JSONArray = try { JSONArray(Store.triggers) } catch (e: Exception) { JSONArray() }

    private fun match(type: String, subject: String, exact: Boolean = false) {
        val arr = load()
        for (i in 0 until arr.length()) {
            val t = arr.getJSONObject(i)
            if (t.getString("type") != type) continue
            val v = t.optString("value").lowercase().trim()
            val okv = when {
                type in simple -> true
                exact -> v == subject
                else -> v.isNotBlank() && subject.lowercase().contains(v)
            }
            if (!okv) continue
            val id = t.getInt("id")
            val now = System.currentTimeMillis()
            if (now - (last[id] ?: 0L) < 20000) continue
            last[id] = now
            fire?.invoke(t.getString("action"))
        }
    }

    fun add(type: String, value: String, action: String): String {
        val ty = type.lowercase().trim()
        if (ty !in all) return "fail: ye trigger type nahi hai"
        var v = value.trim()
        if (ty == "time") {
            val m = Regex("^(\\d{1,2}):(\\d{2})$").find(v) ?: return "fail: time HH:mm me do"
            v = "%02d:%02d".format(m.groupValues[1].toInt(), m.groupValues[2].toInt())
        }
        if (ty == "date") {
            val m = Regex("^(\\d{1,2})-(\\d{1,2})@(\\d{1,2}):(\\d{2})$").find(v) ?: return "fail: date DD-MM@HH:mm me do"
            v = "%02d-%02d@%02d:%02d".format(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt(), m.groupValues[4].toInt())
        }
        if (action.isBlank()) return "fail: action khali hai"
        val arr = load()
        var id = 1
        for (i in 0 until arr.length()) id = maxOf(id, arr.getJSONObject(i).getInt("id") + 1)
        arr.put(JSONObject().put("id", id).put("type", ty).put("value", v).put("action", action.trim()))
        Store.triggers = arr.toString()
        return "ok: trigger #$id save ho gaya"
    }

    fun list(): String {
        val arr = load()
        if (arr.length() == 0) return "koi trigger nahi hai"
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val t = arr.getJSONObject(i)
            sb.append("#").append(t.getInt("id")).append(" ").append(t.getString("type")).append(" ")
                .append(t.optString("value")).append(" -> ").append(t.getString("action").take(60)).append("\n")
        }
        return sb.toString()
    }

    fun delete(id: String): String {
        val n = id.trim().removePrefix("#").toIntOrNull() ?: return "fail: trigger number do"
        val arr = load()
        val out = JSONArray()
        var found = false
        for (i in 0 until arr.length()) {
            val t = arr.getJSONObject(i)
            if (t.getInt("id") == n) found = true else out.put(t)
        }
        Store.triggers = out.toString()
        return if (found) "ok: trigger hata diya" else "fail: ye trigger nahi mila"
    }
}

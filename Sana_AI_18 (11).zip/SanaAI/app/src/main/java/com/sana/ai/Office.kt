package com.sana.ai

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Word / Excel / PowerPoint: banana, padhna aur simple edit. Koi bahari library nahi (sirf zip + XML). */
object Office {
    private const val XML = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    private const val REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val PKG = "http://schemas.openxmlformats.org/package/2006/relationships"

    fun esc(s: String): String {
        val x = s.filter { it.code >= 32 || it == '\t' }
        return x.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")
    }

    fun unesc(s: String): String =
        s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")

    private fun b(s: String) = s.toByteArray(Charsets.UTF_8)

    // ---------- zip helpers ----------
    fun readZipBytes(data: ByteArray): LinkedHashMap<String, ByteArray> {
        val m = LinkedHashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(data)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory) m[e.name] = z.readBytes()
                e = z.nextEntry
            }
        }
        return m
    }

    fun readZip(f: File): LinkedHashMap<String, ByteArray> = readZipBytes(f.readBytes())

    fun writeZip(m: Map<String, ByteArray>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            // [Content_Types].xml sabse pehle
            val names = m.keys.sortedBy { if (it == "[Content_Types].xml") 0 else 1 }
            for (n in names) { z.putNextEntry(ZipEntry(n)); z.write(m[n]!!); z.closeEntry() }
        }
        return bo.toByteArray()
    }

    // ---------- DOCX ----------
    private fun para(t: String, bold: Boolean, size: Int): String =
        "<w:p><w:r><w:rPr>" + (if (bold) "<w:b/><w:bCs/>" else "") +
            "<w:sz w:val=\"$size\"/><w:szCs w:val=\"$size\"/></w:rPr><w:t xml:space=\"preserve\">" + esc(t) + "</w:t></w:r></w:p>"

    fun docxParas(text: String): String {
        val sb = StringBuilder()
        for (raw in text.split("\n")) {
            val line = raw.trimEnd()
            when {
                line.isBlank() -> sb.append("<w:p/>")
                line.startsWith("## ") -> sb.append(para(line.substring(3), true, 26))
                line.startsWith("# ") -> sb.append(para(line.substring(2), true, 30))
                line.startsWith("- ") || line.startsWith("* ") -> sb.append(para("\u2022 " + line.substring(2), false, 24))
                else -> sb.append(para(line, false, 24))
            }
        }
        return sb.toString()
    }

    fun docx(title: String, body: String): ByteArray {
        val ct = XML + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>"
        val rels = XML + "<Relationships xmlns=\"$PKG\"><Relationship Id=\"rId1\" Type=\"$REL/officeDocument\" Target=\"word/document.xml\"/></Relationships>"
        val doc = XML + "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>" +
            para(title, true, 36) + docxParas(body) +
            "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"720\" w:footer=\"720\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>"
        return writeZip(linkedMapOf("[Content_Types].xml" to b(ct), "_rels/.rels" to b(rels), "word/document.xml" to b(doc)))
    }

    fun docxAppend(f: File, text: String): String {
        val m = readZip(f)
        val x = m["word/document.xml"]?.toString(Charsets.UTF_8) ?: return "fail: ye valid docx nahi hai"
        var at = x.lastIndexOf("<w:sectPr")
        if (at < 0) at = x.lastIndexOf("</w:body>")
        if (at < 0) return "fail: docx ka dhancha samajh nahi aaya"
        m["word/document.xml"] = b(x.substring(0, at) + docxParas(text) + x.substring(at))
        f.writeBytes(writeZip(m))
        return "ok: text docx me jod diya"
    }

    fun docxReplace(f: File, find: String, rep: String): String {
        val m = readZip(f)
        val x = m["word/document.xml"]?.toString(Charsets.UTF_8) ?: return "fail: ye valid docx nahi hai"
        val k = esc(find)
        if (k.isEmpty() || !x.contains(k)) return "fail: ye text nahi mila (shabd ek hi formatting me hone chahiye)"
        val cnt = x.split(k).size - 1
        m["word/document.xml"] = b(x.replace(k, esc(rep)))
        f.writeBytes(writeZip(m))
        return "ok: $cnt jagah badal diya"
    }

    // ---------- XLSX ----------
    fun colName(i: Int): String {
        var n = i
        var s = ""
        do { s = ('A' + n % 26) + s; n = n / 26 - 1 } while (n >= 0)
        return s
    }

    private val numRx = Regex("^-?\\d+(\\.\\d+)?\$")

    fun xlsxRows(rows: List<List<String>>, startRow: Int): String {
        val sb = StringBuilder()
        rows.forEachIndexed { ri, r ->
            val rn = startRow + ri
            sb.append("<row r=\"$rn\">")
            r.forEachIndexed { ci, v0 ->
                val v = v0.trim()
                val ref = colName(ci) + rn
                when {
                    v.isEmpty() -> {}
                    v.startsWith("=") -> sb.append("<c r=\"$ref\"><f>" + esc(v.substring(1)) + "</f></c>")
                    numRx.matches(v) -> sb.append("<c r=\"$ref\"><v>$v</v></c>")
                    else -> sb.append("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">" + esc(v0) + "</t></is></c>")
                }
            }
            sb.append("</row>")
        }
        return sb.toString()
    }

    fun parseRows(s: String): List<List<String>> {
        val lines = if (s.contains("\n")) s.split("\n") else if (s.contains(";")) s.split(";") else listOf(s)
        return lines.filter { it.isNotBlank() }.map { l -> (if (l.contains("|")) l.split("|") else l.split(",")).map { it.trim() } }
    }

    fun xlsx(rows: List<List<String>>): ByteArray {
        val ct = XML + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
            "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>"
        val rels = XML + "<Relationships xmlns=\"$PKG\"><Relationship Id=\"rId1\" Type=\"$REL/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>"
        val wb = XML + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"$REL\">" +
            "<sheets><sheet name=\"Sheet1\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"
        val wbRels = XML + "<Relationships xmlns=\"$PKG\"><Relationship Id=\"rId1\" Type=\"$REL/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>"
        val sheet = XML + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>" +
            xlsxRows(rows, 1) + "</sheetData></worksheet>"
        return writeZip(linkedMapOf("[Content_Types].xml" to b(ct), "_rels/.rels" to b(rels), "xl/workbook.xml" to b(wb),
            "xl/_rels/workbook.xml.rels" to b(wbRels), "xl/worksheets/sheet1.xml" to b(sheet)))
    }

    fun xlsxAppend(f: File, rows: List<List<String>>): String {
        val m = readZip(f)
        val key = if (m.containsKey("xl/worksheets/sheet1.xml")) "xl/worksheets/sheet1.xml"
            else m.keys.firstOrNull { it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml") } ?: return "fail: ye valid xlsx nahi hai"
        val x = m[key]!!.toString(Charsets.UTF_8)
        val last = Regex("<row r=\"(\\d+)\"").findAll(x).map { it.groupValues[1].toInt() }.maxOrNull() ?: 0
        val add = xlsxRows(rows, last + 1)
        val y = when {
            x.contains("</sheetData>") -> x.replace("</sheetData>", add + "</sheetData>")
            x.contains("<sheetData/>") -> x.replace("<sheetData/>", "<sheetData>$add</sheetData>")
            else -> return "fail: sheet ka dhancha samajh nahi aaya"
        }
        m[key] = b(y)
        f.writeBytes(writeZip(m))
        return "ok: ${rows.size} row jod di (row ${last + 1} se)"
    }

    // ---------- PPTX (template: res/raw/pptx_base.pptx) ----------
    private fun slideXml(title: String, bullets: List<String>, titleLayout: Boolean): String {
        val head = XML + "<p:sld xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:r=\"$REL\" " +
            "xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\"><p:cSld><p:spTree>" +
            "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>"
        val t = "<p:sp><p:nvSpPr><p:cNvPr id=\"2\" name=\"Title 1\"/><p:cNvSpPr><a:spLocks noGrp=\"1\"/></p:cNvSpPr><p:nvPr><p:ph type=\"" +
            (if (titleLayout) "ctrTitle" else "title") + "\"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:lstStyle/>" +
            "<a:p><a:r><a:rPr lang=\"hi-IN\"/><a:t>" + esc(title) + "</a:t></a:r></a:p></p:txBody></p:sp>"
        val ph = if (titleLayout) "<p:ph type=\"subTitle\" idx=\"1\"/>" else "<p:ph idx=\"1\"/>"
        val paras = if (bullets.isEmpty()) "<a:p><a:endParaRPr lang=\"hi-IN\"/></a:p>"
            else bullets.joinToString("") { "<a:p><a:r><a:rPr lang=\"hi-IN\"/><a:t>" + esc(it) + "</a:t></a:r></a:p>" }
        val body = "<p:sp><p:nvSpPr><p:cNvPr id=\"3\" name=\"Content 2\"/><p:cNvSpPr><a:spLocks noGrp=\"1\"/></p:cNvSpPr><p:nvPr>$ph</p:nvPr></p:nvSpPr>" +
            "<p:spPr/><p:txBody><a:bodyPr><a:normAutofit/></a:bodyPr><a:lstStyle/>$paras</p:txBody></p:sp>"
        return head + t + body + "</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>"
    }

    /** slides[0] = title slide (title + subtitle lines), baaki = title + bullets */
    fun pptx(base: ByteArray, slides: List<Pair<String, List<String>>>): ByteArray {
        val m = readZipBytes(base)
        var ct = m["[Content_Types].xml"]!!.toString(Charsets.UTF_8)
        var rels = m["ppt/_rels/presentation.xml.rels"]!!.toString(Charsets.UTF_8)
        var pres = m["ppt/presentation.xml"]!!.toString(Charsets.UTF_8)
        val ids = StringBuilder(); val relAdd = StringBuilder(); val ctAdd = StringBuilder()
        slides.forEachIndexed { i, s ->
            val n = i + 1
            val first = i == 0
            m["ppt/slides/slide$n.xml"] = b(slideXml(s.first, s.second, first))
            m["ppt/slides/_rels/slide$n.xml.rels"] = b(XML + "<Relationships xmlns=\"$PKG\"><Relationship Id=\"rId1\" Type=\"$REL/slideLayout\" Target=\"../slideLayouts/slideLayout" +
                (if (first) "1" else "2") + ".xml\"/></Relationships>")
            relAdd.append("<Relationship Id=\"rIdSana$n\" Type=\"$REL/slide\" Target=\"slides/slide$n.xml\"/>")
            ids.append("<p:sldId id=\"${255 + n}\" r:id=\"rIdSana$n\"/>")
            ctAdd.append("<Override PartName=\"/ppt/slides/slide$n.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>")
        }
        ct = ct.replace("</Types>", ctAdd.toString() + "</Types>")
        rels = rels.replace("</Relationships>", relAdd.toString() + "</Relationships>")
        pres = pres.replace("</p:sldMasterIdLst>", "</p:sldMasterIdLst><p:sldIdLst>$ids</p:sldIdLst>")
        m["[Content_Types].xml"] = b(ct); m["ppt/_rels/presentation.xml.rels"] = b(rels); m["ppt/presentation.xml"] = b(pres)
        return writeZip(m)
    }

    /** "Title\n- point\n- point\n\n---\nTitle 2..." -> slides */
    fun parseSlides(s: String): List<Pair<String, List<String>>> {
        val blocks = s.replace("\r", "").split(Regex("\\n\\s*(---)?\\s*\\n")).map { it.trim() }.filter { it.isNotEmpty() }
        return blocks.map { blk ->
            val ls = blk.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
            ls.first().trimStart('#', ' ', '-', '*') to ls.drop(1).map { it.removePrefix("- ").removePrefix("* ").trim() }
        }
    }

    // ---------- READ ----------
    fun readText(f: File): String {
        val m = readZip(f)
        val sb = StringBuilder()
        when (f.extension.lowercase()) {
            "docx" -> {
                val x = m["word/document.xml"]?.toString(Charsets.UTF_8) ?: return "fail: docx galat hai"
                Regex("(?s)<w:p[ >].*?</w:p>").findAll(x).forEach { p ->
                    sb.append(Regex("(?s)<w:t[^>]*>(.*?)</w:t>").findAll(p.value).joinToString("") { unesc(it.groupValues[1]) }).append("\n")
                }
            }
            "pptx" -> {
                val names = m.keys.filter { Regex("ppt/slides/slide\\d+\\.xml").matches(it) }.sortedBy { it.filter { c -> c.isDigit() }.toInt() }
                names.forEachIndexed { i, nm ->
                    val x = m[nm]!!.toString(Charsets.UTF_8)
                    sb.append("Slide ${i + 1}: ").append(Regex("(?s)<a:t>(.*?)</a:t>").findAll(x).joinToString(" | ") { unesc(it.groupValues[1]) }).append("\n")
                }
            }
            "xlsx" -> {
                val shared = ArrayList<String>()
                m["xl/sharedStrings.xml"]?.toString(Charsets.UTF_8)?.let { ss ->
                    Regex("(?s)<si>(.*?)</si>").findAll(ss).forEach { si ->
                        shared.add(Regex("(?s)<t[^>]*>(.*?)</t>").findAll(si.groupValues[1]).joinToString("") { unesc(it.groupValues[1]) })
                    }
                }
                val key = if (m.containsKey("xl/worksheets/sheet1.xml")) "xl/worksheets/sheet1.xml"
                    else m.keys.firstOrNull { it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml") } ?: return "fail: xlsx galat hai"
                val x = m[key]!!.toString(Charsets.UTF_8)
                Regex("(?s)<row [^>]*>(.*?)</row>").findAll(x).forEach { row ->
                    val cells = Regex("(?s)<c ([^>]*?)(?:/>|>(.*?)</c>)").findAll(row.groupValues[1]).map { c ->
                        val attrs = c.groupValues[1]
                        val inner = c.groupValues[2]
                        val tp = Regex("t=\"(\\w+)\"").find(attrs)?.groupValues?.get(1) ?: ""
                        val v = Regex("(?s)<v>(.*?)</v>").find(inner)?.groupValues?.get(1) ?: ""
                        when (tp) {
                            "s" -> shared.getOrElse(v.toIntOrNull() ?: -1) { "" }
                            "inlineStr" -> Regex("(?s)<t[^>]*>(.*?)</t>").findAll(inner).joinToString("") { unesc(it.groupValues[1]) }
                            else -> unesc(v)
                        }
                    }.toList()
                    sb.append(cells.joinToString(" | ")).append("\n")
                }
            }
            else -> return "fail: sirf docx, xlsx, pptx padh sakti hoon"
        }
        return sb.toString().trim().ifBlank { "file khali hai" }
    }
}

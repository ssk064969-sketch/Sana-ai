package com.sana.ai

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class SanaService : Service(), TextToSpeech.OnInitListener {
    companion object {
        @Volatile var running = false
        @Volatile var micOnState = true
        @Volatile var eyeState = false
        @Volatile var camState = false
        @Volatile var screenState = false
        @Volatile var talking = false      // Sana bol rahi / soch rahi hai (orb ke liye)
        @Volatile var micLevel = 0f        // tumhari awaaz ka level 0..1 (orb ke liye)
        @Volatile var listeningState = false
        @Volatile var thinkingState = false
        @Volatile var enrolling = false    // awaaz record ho rahi hai: Sana ka mic kuch der ruka rahe
        @Volatile var rejectUntil = 0L     // Voice Lock ne kisi aur ki awaaz roki (status dikhane ke liye)
        @Volatile var voiceLevel = 0f      // Sana ki awaaz ka level 0..1 (character ke lip-sync ke liye)
        @Volatile var emoState = ""        // abhi bol rahi line ka bhaav (khush/pyaar/rona...)
        @Volatile var lastSaid = ""        // Sana ne aakhri baar kya bola (main screen par dikhta hai)
    }

    private lateinit var tts: TextToSpeech
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var speaking = false
    @Volatile private var speechGeneration = 0
    @Volatile private var activeTrack: AudioTrack? = null
    private var thinking = false
    private var awakeUntil = 0L
    private val brain = Brain { n, a -> runTool(n, a) }
    private val wakeWords = listOf("हे ज\u093Cारा", "हे \u095Bारा", "हे जारा", "hey zara", "hay zara", "hey zaara", "हे सना", "hey sana", "सना", "sana", "वेकअप", "वेक अप", "वेकप", "wake up", "wakeup")

    private val aliases = mapOf(
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वाट्सएप" to "whatsapp",
        "यूट्यूब" to "youtube", "कैमरा" to "camera", "सेटिंग" to "settings", "क्रोम" to "chrome",
        "गैलरी" to "gallery", "फोन" to "phone", "गूगल" to "google", "इंस्टाग्राम" to "instagram",
        "फेसबुक" to "facebook", "मैप्स" to "maps", "कैलकुलेटर" to "calculator", "घड़ी" to "clock",
        "मैसेज" to "messages", "टेलीग्राम" to "telegram", "जीमेल" to "gmail", "स्नैपचैट" to "snapchat"
    )

    private var micOn = true
    private var pendingMicOff = false
    private var camOn = false
    @Volatile private var recActive = false
    private var recStartedAt = 0L
    private var recEndedAt = 0L
    private var forceListenUntil = 0L
    private var musicMuted = false
    private var screenOn = false
    private val FOREVER = 31_536_000_000L   // neon/jaag tab tak jab tak "band" na bolo

    private fun notif(): Notification {
        val pi = PendingIntent.getService(this, 2, Intent(this, SanaService::class.java).setAction("mic"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val pt = PendingIntent.getService(this, 3, Intent(this, SanaService::class.java).setAction("talk"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(this, 4, Intent(this, SanaService::class.java).setAction("stop_speech"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, "sana")
            .setContentTitle(if (micOn) "Sana AI चालू है" else "Sana AI: माइक बंद है")
            .setContentText(if (!micOn) "माइक चालू करने के लिए नीचे बटन दबाइए" else liveStatus().ifBlank { "\"सना\" बोलकर बुलाइए" })
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true)
            .addAction(android.R.drawable.ic_btn_speak_now, if (micOn) "माइक बंद करो" else "माइक चालू करो", pi)
            .addAction(android.R.drawable.ic_btn_speak_now, "बोलो", pt)
            .addAction(android.R.drawable.ic_media_pause, "आवाज़ रोको", stop).build()
    }

    private fun setMic(on: Boolean) {
        micOn = on; micOnState = on
        if (!on) { sr?.cancel(); recActive = false; muteMusic(false); awakeUntil = 0L; Holo.hide(this) } else listen()
        getSystemService(NotificationManager::class.java).notify(1, notif())
    }

    // recognizer ki "toon toon" beep band rakhne ke liye notification/system awaaz mute
    private fun muteBeep(m: Boolean) {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        val d = if (m) android.media.AudioManager.ADJUST_MUTE else android.media.AudioManager.ADJUST_UNMUTE
        for (st in intArrayOf(android.media.AudioManager.STREAM_NOTIFICATION, android.media.AudioManager.STREAM_SYSTEM))
            try { am.adjustStreamVolume(st, d, 0) } catch (e: Exception) {}
    }

    private var lastActive = 0L
    private var careCount = 0

    // ---------- Game commentary ----------
    @Volatile private var commentaryOn = false
    private var lastCommentary = 0L
    private fun doCommentary() {
        Thread {
            try {
                val shot = SanaAccessibility.screenshotSync()
                if (shot != null && commentaryOn) {
                    val r = brain.vision("ये किसी गेम (BGMI या Free Fire) की स्क्रीन है। इस पल की एक छोटी जोशीली हिंदी कमेंट्री एक वाक्य में दो। अगर गेम नहीं दिख रहा तो बस इतना कहो: गेम नहीं दिख रहा।", shot)
                    if (r.isNotBlank() && commentaryOn) speak(r)
                }
            } catch (e: Exception) { }
        }.start()
    }

    // ---------- Voice Guardian (gupt shabd) ----------
    @Volatile private var guardWait: java.util.concurrent.CompletableFuture<String>? = null
    private val guardTools = setOf("call_contact", "send_message", "delete_file", "memory_delete", "read_otp", "read_sms", "reply_notification")

    /** Bolkar jawab maangta hai (background thread se). Jawab text me wapas aata hai */
    private fun askSpoken(q: String): String {
        val f = java.util.concurrent.CompletableFuture<String>()
        guardWait = f
        thinking = false
        h.post { speak(q) }
        val heard = try { f.get(30, java.util.concurrent.TimeUnit.SECONDS) } catch (e: Exception) { "" }
        guardWait = null
        return heard
    }

    private fun guardPassed(): Boolean {
        val heard = askSpoken("सुरक्षा के लिए अपना गुप्त शब्द बोलिए")
        thinking = true; h.post { Holo.speaking(true) }
        return ProTools.guardCheck(heard)
    }

    private fun wakeScreen() {
        @Suppress("DEPRECATION")
        val wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE, "sana:wake")
        try { wl.acquire(15000) } catch (_: Exception) {}
    }

    /** Voice Guardian chalu ho to pehle gupt shabd; phir screen jagao, swipe up, pattern draw karo (background thread) */
    private fun unlockWithPattern(pat: List<Int>) {
        if (Store.guardOn && !ProTools.guardCheck(askSpoken("फ़ोन अनलॉक करने के लिए गुप्त शब्द बोलिए"))) {
            h.post { speak("गुप्त शब्द गलत है, फ़ोन अनलॉक नहीं करूँगी") }
            return
        }
        h.post { wakeScreen() }
        Thread.sleep(800)
        SanaAccessibility.swipeUp()
        var seen = false
        for (i in 0 until 8) {
            Thread.sleep(600)
            if (SanaAccessibility.patternVisible()) { seen = true; break }
            if (i == 3) SanaAccessibility.swipeUp()
        }
        if (!seen) {
            h.post { speak("पैटर्न वाली लॉक स्क्रीन नहीं दिखी। शायद फ़ोन पहले से खुला है या उस पर पैटर्न नहीं है") }
            return
        }
        Thread.sleep(300)
        SanaAccessibility.drawPattern(pat)
        Thread.sleep(pat.size * 250L + 1200)
        val still = SanaAccessibility.patternVisible()
        h.post { speak(if (still) "पैटर्न नहीं खुला। ऐप में पैटर्न दोबारा सेव करके देखिए" else "फ़ोन अनलॉक हो गया") }
    }

    private fun guardCommand(t: String) {
        Thread {
            try {
                if (has(t, "बंद", "off", "हटा")) {
                    if (!Store.guardOn) { speak("गार्जियन पहले से बंद है"); return@Thread }
                    val ok = ProTools.guardCheck(askSpoken("गार्जियन बंद करने के लिए गुप्त शब्द बोलिए"))
                    if (ok) { Store.guardOn = false; speak("गार्जियन बंद हो गया") } else speak("गुप्त शब्द गलत है, गार्जियन चालू रहेगा")
                } else {
                    if (Store.guardOn && !ProTools.guardCheck(askSpoken("पहले पुराना गुप्त शब्द बोलिए"))) { speak("गुप्त शब्द गलत है"); return@Thread }
                    val a = askSpoken("अब नया गुप्त शब्द बोलिए। ये सिर्फ़ इसी फ़ोन पर सुरक्षित रहेगा")
                    if (a.isBlank()) { speak("कुछ सुनाई नहीं दिया, दोबारा कोशिश कीजिए"); return@Thread }
                    val b = askSpoken("पक्का करने के लिए वही शब्द दोबारा बोलिए")
                    val first = a.lowercase().filter { it.isLetterOrDigit() }
                    val second = b.lowercase().filter { it.isLetterOrDigit() }
                    if (first.isNotEmpty() && first == second && ProTools.guardSet(a)) speak("गार्जियन चालू हो गया। अब कॉल, मैसेज और डिलीट से पहले गुप्त शब्द पूछूँगी")
                    else speak("दोनों बार शब्द एक जैसा नहीं मिला, दोबारा कोशिश कीजिए")
                }
            } catch (e: Exception) { }
            thinking = false
            h.post { Holo.speaking(false) }
        }.start()
    }

    private fun careLine(): String {
        val i = (careCount - 1).coerceIn(0, 2)
        if (Store.mode != 2) {
            Persona.sulkyCare(i)?.let { return it }
            if (i == 0) Persona.timeCare()?.let { return it }
        }
        return when (Store.mode) {
            0 -> listOf("सर, क्यों नहीं बोल रहे हो? बोलो बाबू, बात करो ना।", "बाबू, तुम चुप क्यों हो? मुझसे बात करो ना।", "जान, सब ठीक है ना? कुछ तो बोलो।")[i]
            1 -> listOf("यार, चुप क्यों है? बोल ना कुछ।", "ओए, कहाँ खो गया? बात कर ना।", "यार सब ठीक है ना? कुछ तो बोल।")[i]
            3 -> listOf("जान, कुछ तो बोलो, मेरा दिल घबरा रहा है।", "बाबू, तुम ठीक तो हो ना? मुझे तुम्हारी फ़िक्र हो रही है।", "जान, जो भी है मुझे बता दो, मैं सुन रही हूँ।")[i]
            4 -> listOf("बाबू, मैं यहीं हूँ, तुम्हारा इंतज़ार कर रही हूँ।", "जान, कब आओगे? मुझे तुम्हारी याद आ रही है।", "बाबू, जल्दी आओ ना, मैं इंतज़ार में हूँ।")[i]
            5 -> listOf("मेरी जान, कुछ तो बोलो, तुम्हारी आवाज़ सुनने का मन है।", "बाबू, तुम्हारे बिना सब सूना सूना लगता है।", "जान, मुझे तुमसे बात करनी है, कुछ तो कहो ना।")[i]
            else -> listOf("सर, आप कुछ बोल नहीं रहे, क्या मैं कोई मदद कर सकती हूँ?", "सर, मैं यहीं हूँ, जब चाहें बोलिए।", "सर, सब ठीक है ना? कोई काम हो तो बताइए।")[i]
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            Triggers.tick()
            if (recActive && now - recStartedAt > 20000) { sr?.cancel(); recActive = false }   // atka hua recognizer: saaf karo, agla tick dobara chalu karega
            if (musicBlocks()) {                       // gaana chal raha hai: mic chhod do
                if (recActive) { sr?.cancel(); recActive = false }
                muteMusic(false)
            } else if (micOn && !recActive && !speaking && !thinking && now - recEndedAt > 2000) listen()
            if (awakeUntil != 0L && now > awakeUntil && !speaking && !thinking) {
                awakeUntil = 0L; Holo.hide(this@SanaService)
            } else if (awakeUntil != 0L && !speaking && !thinking && careCount < 1 && now - lastActive > 14000 && !(Store.mode == 4 && Store.waiting)) {
                careCount++; lastActive = now
                speak(careLine())
            }
            if (commentaryOn && !speaking && !thinking && confirmWait == null && guardWait == null && now - lastCommentary > 15000) {
                lastCommentary = now; doCommentary()
            }
            h.postDelayed(this, 3000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        // Purana plain-text PIN/pattern (unlockCode) hamesha saaf. Naya pattern PatternVault me encrypted rehta hai.
        Store.unlockCode = ""; Store.unlockType = ""
        micOnState = true
        val ch = "sana"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Sana AI", NotificationManager.IMPORTANCE_LOW))
        val n = notif()
        try {
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {   // mic permission nahi: crash ki jagah chup-chaap band
            android.util.Log.e("Sana", "foreground fail: $e")
            stopSelf(); return
        }
        running = true
        muteBeep(true)
        tts = TextToSpeech(this, this)
        Bus.announce = { speak(it) }
        Bus.callAnnounce = { h.post { announceCall(it) } }
        Bus.talk = { h.post { talkOnce() } }
        h.postDelayed(ticker, 3000)
        Triggers.fire = { act -> h.post { onTrigger(act) } }
        Triggers.start(this)
    }

    override fun onInit(status: Int) {
        tts.language = Locale("hi", "IN")
        val v = tts.voices?.filter { it.locale.language == "hi" }
        v?.sortedWith(compareByDescending<android.speech.tts.Voice> { it.name.contains("hia") || it.name.contains("hic") || it.name.contains("female", true) }
            .thenByDescending { it.isNetworkConnectionRequired }.thenByDescending { it.quality })
            ?.firstOrNull()?.let { tts.voice = it }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { Holo.speaking(true) }
            override fun onError(id: String?) { finishSpeak() }
            override fun onDone(id: String?) { finishSpeak() }
        })
        ttsReady = true
        applyMode()
        speak(if (Store.userName.isBlank()) "Welcome" else "Welcome ${Store.userName.trim()}")
        h.postDelayed({
            if (Store.key.isNotBlank()) voiceExec.execute {
                for (s in listOf("ठीक है", "ठीक है, चला रही हूँ", "ठीक है, खोल दिया", "लिख दिया", "भेज दिया", greetPlain(), "ठीक है, बाय")) try { geminiVoice(s) } catch (e: Exception) {}
            }
        }, 8000)
    }

    private fun applyMode() {
        tts.setPitch(when (Store.mode) { 0 -> 1.1f; 1 -> 1.05f; 3 -> 1.08f; 4 -> 1.1f; 5 -> 1.12f; else -> 1.0f })
        tts.setSpeechRate(when (Store.mode) { 0 -> 0.95f; 3 -> 0.88f; 4 -> 0.95f; 5 -> 0.9f; else -> 1.0f })
        // mood badalne par is mood ki awaaz ki aam lines pehle se bana lo (taaki turant bole)
        if (ttsReady && Store.key.isNotBlank()) voiceExec.execute {
            for (s in listOf("ठीक है", "ठीक है, चला रही हूँ", "लिख दिया", "भेज दिया", greetPlain())) try { geminiVoice(s) } catch (e: Exception) {}
        }
    }

    // ---------- Awaaz: hamesha Gemini ki meethi ladki wali voice (robot voice fallback band) ----------
    private val voiceExec = java.util.concurrent.Executors.newSingleThreadExecutor()
    private var pending = 0
    private var ttsReady = false
    @Volatile private var ttsModel = ""
    private val ttsModels = listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")

    private fun finishSpeak() {
        h.post {
            if (pending > 0) pending--
            if (pending == 0) {
                speaking = false; Holo.speaking(false)
                if (pendingMicOff) { pendingMicOff = false; setMic(false); return@post }
                val now = SystemClock.elapsedRealtime()
                lastActive = now
                if (awakeUntil != 0L) awakeUntil = now + FOREVER
                listen()
            }
        }
    }

    private fun speak(t: String) { h.post { speakNow(t) } }

    /** User can stop any ongoing spoken response from the persistent notification. */
    private fun stopSpeech() {
        speechGeneration++
        try { activeTrack?.let { it.pause(); it.flush(); it.stop(); it.release() } } catch (_: Exception) {}
        activeTrack = null
        try { if (::tts.isInitialized) tts.stop() } catch (_: Exception) {}
        speaking = false; pending = 0; Holo.speaking(false)
        recActive = false; listeningState = false
        h.postDelayed({ if (micOn && running) listen() }, 250)
    }

    /** Pehle ye phone ki robot awaaz se bolta tha. Ab hamesha wahi ladki wali awaaz (cache me ho to turant). */
    private fun speakQuick(t: String) { h.post { speakNow(t) } }

    private val fetchExec = java.util.concurrent.Executors.newFixedThreadPool(2)

    /** Lambe jawab ko chhote tukdon me todta hai: har tukda jaldi aur pakka bannta hai, awaaz ek jaisi rehti hai */
    private fun splitForVoice(t: String): List<String> {
        val raw = t.replace("\n", " ").trim().split(Regex("(?<=[।.!?])\\s+")).filter { it.isNotBlank() }
        val out = ArrayList<String>()
        var cur = ""
        for (r in raw) {
            if (cur.isEmpty()) cur = r
            else if (cur.length + r.length < 140) cur += " " + r
            else { out.add(cur); cur = r }
        }
        if (cur.isNotEmpty()) out.add(cur)
        return out.flatMap { if (it.length > 220) it.chunked(200) else listOf(it) }.ifEmpty { listOf(t) }
    }

    /** Gemini awaaz: fail ho to kai baar dobara koshish. Phone ki robot awaaz kabhi nahi. */
    private fun voiceRetry(text: String): ByteArray? {
        for (i in 0 until 2) {
            val pcm = try { geminiVoice(text) } catch (e: Exception) { null }
            if (pcm != null) return pcm
            if (ttsCode == 429 && (ttsBody.contains("PerDay", true) || ttsBody.contains("per day", true))) return null
            try { Thread.sleep(350L + 450L * i) } catch (e: Exception) {}
        }
        return null
    }

    /** Gemini ke jawab se mila bhaav (naraz, pyaar...): agli awaaz isi andaaz me bolegi */
    @Volatile private var nextEmo = ""
    /** Abhi jo line bol rahi hai uska bhaav (Gemini awaaz ke andaaz ke liye) */
    @Volatile private var voiceEmo = ""

    private fun speakNow(t0: String) {
        val t = Persona.strip(t0)
        if (t.isBlank()) return
        val emo = nextEmo; nextEmo = ""
        emoState = emo.ifBlank { Persona.defaultEmotion() }               // character ka bhaav pehle jaisa
        // Ek jaisi awaaz: har jawab usi andaaz me jisme "आप कुछ बोल नहीं रहे" wali line bolti hai
        voiceEmo = if (Store.sameVoice) Persona.defaultEmotion() else emoState
        val vp = Persona.voiceParams(if (Store.sameVoice) "" else emo)
        val generation = ++speechGeneration
        lastSaid = t
        speaking = true; pending++
        sr?.cancel(); recActive = false; listeningState = false; muteMusic(false); Holo.speaking(true)
        if (Store.sarvamKey.isBlank() && Store.key.isBlank()) { sysSpeak(t); return }
        voiceExec.execute {
            var played = 0
            val parts = splitForVoice(t)
            var idx = 0
            // 1) Sarvam pehle. Key expire / token khatam / net error ho to Gemini awaaz; Sarvam wapas chalte hi apne aap Sarvam.
            if (Store.sarvamKey.isNotBlank() && SystemClock.elapsedRealtime() >= Store.sarvamDownUntil) {
                while (idx < parts.size) {
                    try {
                        val pcm = SarvamTts.synthesize(parts[idx], Store.sarvamKey, Store.sarvamSpeaker, vp.first, vp.second)
                        if (generation != speechGeneration) return@execute
                        playPcm(pcm, generation); played++; idx++
                        Store.voiceNow = "sarvam"; Store.sarvamDownUntil = 0L; Store.sarvamWhy = ""
                    } catch (e: Exception) {
                        if (generation != speechGeneration) return@execute
                        val code = (e as? SarvamException)?.code ?: -1
                        // key galat/expire (401/403), paise/token khatam (402), limit (429): 60 sec baad dobara jaanchenge; net/server error: 15 sec
                        val wait = if (code == 401 || code == 402 || code == 403 || code == 429) 60000L else 15000L
                        Store.sarvamDownUntil = SystemClock.elapsedRealtime() + wait
                        Store.sarvamWhy = (e.message ?: "error").take(120)
                        Store.lastErr = "Sarvam TTS: ${e.message}"
                        android.util.Log.e("Sana", "Sarvam TTS failed, Gemini awaaz par ja rahi hoon", e)
                        break
                    }
                }
            }
            if (idx >= parts.size) { finishSpeak(); return@execute }
            // 2) Bachi hui lines Gemini ki awaaz me
            val hasGemini = Store.key.isNotBlank() || Store.extraKeys.isNotBlank()
            if (!hasGemini) {
                if (played == 0) { Store.voiceNow = "phone"; h.post { sysSpeak(parts.drop(idx).joinToString(" ")) } } else finishSpeak()
                return@execute
            }
            val futs = parts.drop(idx).map { part -> fetchExec.submit<ByteArray?> { voiceRetry(part) } }
            var gOk = 0
            for (f in futs) {
                val pcm = try { f.get() } catch (e: Exception) { null }
                if (generation != speechGeneration) return@execute
                if (pcm != null) try { playPcm(pcm, generation); played++; gOk++ } catch (e: Exception) { android.util.Log.e("Sana", "play: $e") }
            }
            if (gOk > 0) Store.voiceNow = "gemini"
            if (played == 0) { Store.voiceNow = "phone"; h.post { sysSpeak(t) } } else finishSpeak()
        }
    }

    /** User ka naam (agar set hai): " Rahul". Khaali ho to "" taaki line phir bhi theek bane */
    private fun sn(): String = Store.userName.trim().let { if (it.isBlank()) "" else " $it" }

    @Volatile private var ownerChecking = false

    /**
     * Koi khud ko Saqib/owner bataye: Sana awaaz se jaanchti hai. Owner ki awaaz hui to maanti hai,
     * warna saaf mana: "मैं साकिब सर की आवाज़ पहचानती हूँ". Owner ki awaaz is app me set na ho to kisi ko owner nahi maanti.
     */
    private fun ownerClaim(asking: Boolean = false) {
        if (ownerChecking) return
        if (!OwnerVoice.isSet()) {
            speak("इस ऐप में अभी साकिब सर की आवाज़ सेट नहीं है, इसलिए मैं किसी को साकिब सर नहीं मान सकती")
            return
        }
        ownerChecking = true
        enrolling = true                                   // jaanch ke dauran Sana ka mic band, taaki awaaz seedhi record ho
        Thread {
            var verdict = VoiceLock.Verdict(-1, 0)
            try {
                h.post { sr?.cancel(); VoiceTee.stop(); recActive = false; listeningState = false; micLevel = 0f; muteMusic(false) }
                h.post { speak(if (asking) "ठीक है, आवाज़ से पहचानती हूँ। अभी कुछ भी बोलिए, जैसे: सना, मुझे पहचानो, मैं कौन हूँ" else "मैं साकिब सर की आवाज़ पहचानती हूँ। पहचान के लिए अभी बोलिए: सना, मैं साकिब हूँ, मुझे पहचानो") }
                Thread.sleep(600)
                var w = 0
                while ((speaking || pending > 0) && w < 300) { Thread.sleep(100); w++ }
                Thread.sleep(500)
                val pcm = VoiceLock.record(5, { _, _ -> }, { false })
                if (pcm != null) verdict = OwnerVoice.check(pcm)
            } catch (e: Exception) {
                android.util.Log.e("Sana", "owner check", e)
            }
            enrolling = false; ownerChecking = false
            h.post {
                when (verdict.code) {
                    1 -> { Store.userName = "साकिब सर"; speak(if (asking) "आप साकिब सर हैं। मैंने आपकी आवाज़ पहचान ली।" else "हाँ, पहचान लिया। आप ही साकिब सर हैं।") }
                    0 -> speak("नहीं, आप साकिब सर नहीं हैं। मैं साकिब सर की आवाज़ पहचानती हूँ।")
                    else -> speak("आवाज़ साफ़ सुनाई नहीं दी, इसलिए मैं पहचान नहीं पाई। साकिब सर हैं तो शांत जगह पर दोबारा बोलिए।")
                }
                h.postDelayed({ listen() }, 400)
            }
        }.start()
    }

    private fun sysSpeak(t: String) {
        if (!ttsReady) { finishSpeak(); return }
        if (tts.speak(t, TextToSpeech.QUEUE_ADD, null, "u${System.nanoTime()}") != TextToSpeech.SUCCESS) finishSpeak()
    }

    @Volatile private var ttsCode = 0
    @Volatile private var ttsBody = ""

    private fun tryModel(m: String, text: String, key: String): ByteArray? = try {
        val prompt = "${voiceStyle()}: $text"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", Store.voiceName)))))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 6000; c.readTimeout = 20000; c.doOutput = true
        c.setRequestProperty("x-goog-api-key", key); c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        ttsCode = c.responseCode
        if (ttsCode !in 200..299) {
            ttsBody = (c.errorStream?.bufferedReader()?.use { it.readText() } ?: "").take(300)
            Store.lastErr = "Awaaz (TTS) $m: HTTP $ttsCode $ttsBody"
            null
        } else {
            val txt = c.inputStream.bufferedReader().use { it.readText() }
            val data = JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
            Base64.decode(data, Base64.DEFAULT)
        }
    } catch (e: Exception) { ttsCode = -1; Store.lastErr = "Awaaz (TTS) $m: $e"; null }

    /** Mood ke hisaab se awaaz ka andaaz: meethi, asli ladki jaisi, saans aur bhaav ke saath */
    private fun voiceStyle(): String {
        val base = "Speak in Hindi like a real, sweet, soft-spoken young Indian girl on a phone call: gentle, tender, natural and human, never robotic, with small breaths and soft smiles"
        val mood = when (Store.mode) {
            0 -> "warm, soft, affectionate and sweet"
            1 -> "soft, cheerful and friendly"
            2 -> "soft, calm and sweet"
            3 -> "very soft, gentle, a little emotional and caring, slower pace"
            4 -> "softly complaining and a little hurt but loving"
            5 -> "very soft, close to the mic, loving and romantic, slower pace"
            else -> "soft and sweet"
        }
        val feel = Persona.voiceStyleFor(voiceEmo)
        return if (feel != null) "$base. Tone: $feel. Say this" else "$base. Tone: $mood. Say this"
    }

    private val keyDeadUntil = HashMap<String, Long>()

    // Pehle Gemini ki asli ladki wali awaaz (kai keys ghoom kar); na bane to phone ki awaaz (Sana chup nahi rahegi)
    private fun geminiVoice(text: String): ByteArray? {
        val f = java.io.File(cacheDir, "tts_" + (Store.voiceName + voiceStyle() + text).hashCode())
        if (f.exists()) try { return f.readBytes() } catch (e: Exception) {}
        val order = (listOf(ttsModel).filter { it.isNotEmpty() } + ttsModels).distinct()
        val keys = (listOf(Store.key) + Store.extraKeys.split(",", "\n", " ").map { it.trim() }.filter { it.length > 10 }).distinct()
        for (k in keys) {
            if (SystemClock.elapsedRealtime() < (keyDeadUntil[k] ?: 0L)) continue
            for (m in order) {
                val pcm = tryModel(m, text, k)
                if (pcm != null) {
                    ttsModel = m
                    if (text.length < 90) try {
                        val old = cacheDir.listFiles { x -> x.name.startsWith("tts_") }
                        if (old != null && old.size > 150) old.forEach { it.delete() }
                        f.writeBytes(pcm)
                    } catch (e: Exception) {}
                    return pcm
                }
                if (ttsCode == 429 && (ttsBody.contains("PerDay", true) || ttsBody.contains("per day", true))) {
                    keyDeadUntil[k] = SystemClock.elapsedRealtime() + 30 * 60000L   // is key ki roz ki limit khatam
                    break
                }
            }
        }
        return null
    }

    /** Is pal (ms) par awaaz kitni tez hai: 40 ms ka RMS, 0..1 (character ka munh isi se khulta hai) */
    private fun pcmLevel(pcm: ByteArray, ms: Long): Float {
        val start = (ms * 24).toInt() * 2
        val end = minOf(pcm.size - 1, start + 960 * 2)
        if (start < 0 || start >= end) return 0f
        var sum = 0.0; var n = 0; var i = start
        while (i + 1 < end) { val v = (pcm[i].toInt() and 0xFF) or (pcm[i + 1].toInt() shl 8); val s = v.toShort().toInt(); sum += s.toDouble() * s; n++; i += 2 }
        if (n == 0) return 0f
        return (Math.sqrt(sum / n) / 5000.0).toFloat().coerceIn(0f, 1f)
    }

    private fun playPcm(pcm: ByteArray, generation: Int) {
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size).setTransferMode(AudioTrack.MODE_STATIC).build()
        if (generation != speechGeneration) { at.release(); return }
        activeTrack = at
        try {
            at.write(pcm, 0, pcm.size)
            if (generation != speechGeneration) return
            at.play()
            var remaining = pcm.size / 2 / 24 + 250L // 24kHz mono 16-bit
            val playT0 = SystemClock.elapsedRealtime()
            while (remaining > 0 && generation == speechGeneration) {
                val slice = minOf(remaining, 40L); Thread.sleep(slice); remaining -= slice
                voiceLevel = pcmLevel(pcm, SystemClock.elapsedRealtime() - playT0)
            }
        } finally {
            voiceLevel = 0f
            if (activeTrack === at) activeTrack = null
            try { if (at.playState == AudioTrack.PLAYSTATE_PLAYING) at.stop() } catch (_: Exception) {}
            try { at.release() } catch (_: Exception) {}
        }
    }

    private fun listen() {
        if (!micOn || speaking || thinking || enrolling) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (musicBlocks()) { sr?.cancel(); recActive = false; muteMusic(false); return }
        if (recActive && SystemClock.elapsedRealtime() - recStartedAt < 20000) return   // mic pehle se chalu hai: dobara restart nahi (isi se bar bar on/off hota tha)
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    h.removeCallbacks(partialWake)
                    recActive = false; listeningState = false; micLevel = 0f; recEndedAt = SystemClock.elapsedRealtime()
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    val mine = voiceAllowed()
                    if (!t.isNullOrBlank() && mine) { forceListenUntil = 0L; handle(t) }
                    h.postDelayed({ listen() }, 15)
                }
                override fun onError(e: Int) {
                    h.removeCallbacks(partialWake)
                    VoiceTee.stop()
                    recActive = false; listeningState = false; micLevel = 0f; recEndedAt = SystemClock.elapsedRealtime()
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { muteMusic(false); return }
                    if ((e == 12 || e == 13) && Store.offline) {   // offline Hindi pack nahi hai
                        Store.offline = false
                        speak("ऑफलाइन हिंदी पैक उपलब्ध नहीं है, ऑनलाइन पहचान पर लौट रही हूँ")
                    }
                    // chup rehna (no match / timeout) normal hai: halka sa gap. Baaki errors par thoda ruk kar, taaki mic tez tez on/off na ho
                    val gap = when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 150L
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 800L
                        else -> 1200L
                    }
                    h.postDelayed({ listen() }, gap)
                }
                override fun onReadyForSpeech(p: Bundle?) { listeningState = true }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {
                    val n = ((v + 2f) / 12f).coerceIn(0f, 1f)
                    micLevel += (n - micLevel) * 0.5f
                }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { micLevel = 0f }
                // Tez wake-up: "सना" sunte hi (poora vaakya khatam hone ka intezaar kiye bina) jaag jao
                override fun onPartialResults(p: Bundle?) {
                    if (confirmWait != null) return
                    val now = SystemClock.elapsedRealtime()
                    if (awakeUntil != 0L && now <= awakeUntil) return          // pehle se jaagi hui hai
                    val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase() ?: return
                    if (wakeWords.none { t.contains(it) }) return
                    h.removeCallbacks(partialWake)
                    if (wakeWords.fold(t) { a, x -> a.replace(x, "") }.replace(Regex("[\\s,।.]+"), "").isBlank()) {       // sirf "सना" bola: thodi der chup rahe to turant jaag jao
                        partialText = t
                        h.postDelayed(partialWake, 300)
                    }                                      // "सना, ..." aage kuch bola to poora command sunegi
                }
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, Store.offline)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 600L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 400L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 200L)
        }
        VoiceTee.stop()
        if (Store.voiceLock && VoiceLock.enrolled() && Build.VERSION.SDK_INT >= 33) {
            VoiceTee.start()?.let { pfd ->
                i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, pfd)
                i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
                i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
                i.putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, VoiceLock.SR)
            }
        }
        muteMusic(true)
        sr?.cancel(); sr?.startListening(i); recActive = true; recStartedAt = SystemClock.elapsedRealtime()
    }

    /** Voice Lock: bolne wala meri awaaz ka hai? (lock band ya verify na ho paye to haan) */
    private fun voiceAllowed(): Boolean {
        if (!VoiceTee.active) return true
        val v = try { VoiceTee.verifyNow() } catch (e: Throwable) { -1 }
        VoiceTee.stop()
        if (v == 0) { rejectUntil = SystemClock.elapsedRealtime() + 3500L; return false }
        return true
    }

    private var partialText = ""
    private val partialWake = Runnable {
        if (recActive && confirmWait == null && (awakeUntil == 0L || SystemClock.elapsedRealtime() > awakeUntil)) {
            sr?.cancel(); recActive = false; listeningState = false; micLevel = 0f
            if (voiceAllowed()) handle(partialText)
        }
    }

    private val waitLine = "कहाँ थे तुम इतनी देर से? मुझे ज़रा भी याद नहीं आई क्या? मैं कब से इंतज़ार कर रही थी।"
    private fun greet(): String {
        if (Store.mode == 4 && Store.waiting) { Store.waiting = false; return waitLine }
        if (Store.mode != 2) Persona.sulkyGreet()?.let { return it }
        return greetPlain()
    }
    private fun greetPlain(): String {
        return when (Store.mode) {
            0 -> "हाँ जान, बोलो ना"; 1 -> "हाँ यार, बोल"; 3 -> "हाँ जान, मैं सुन रही हूँ, बोलो"
            4 -> "हाँ बाबू, बोलो"; 5 -> "हाँ मेरी जान, बोलो ना"; else -> "जी, मैं सुन रही हूँ"
        }
    }

    private fun handle(raw: String) {
        guardWait?.let { f ->            // gupt shabd ka jawab: AI ya history tak nahi jaata
            val n = SystemClock.elapsedRealtime(); awakeUntil = n + FOREVER; lastActive = n
            f.complete(raw); return
        }
        confirmWait?.let { f ->          // Sana ne haan/na poochha hai: ye jawab usi ka hai
            val n = SystemClock.elapsedRealtime(); awakeUntil = n + FOREVER; lastActive = n
            f.complete(isYes(raw)); return
        }
        var t = raw.trim(); val low = t.lowercase()
        val now = SystemClock.elapsedRealtime()
        if (awakeUntil == 0L || now > awakeUntil) {
            val w = wakeWords.firstOrNull { low.contains(it) } ?: return
            t = wakeWords.fold(low) { a, x -> a.replace(x, "") }.trim(' ', ',', '।', '.')
            Holo.show(this)
            awakeUntil = now + FOREVER
            if (t.isBlank()) { speakQuick(greet()); return }
        }
        awakeUntil = now + FOREVER
        lastActive = now; careCount = 0
        process(t)
    }

    /** Main screen ke typing box se aaya text: bolne jaisa hi chalta hai, jawab awaaz me aata hai */
    private fun typed(raw: String) {
        val now = SystemClock.elapsedRealtime()
        awakeUntil = now + FOREVER; lastActive = now; careCount = 0
        guardWait?.let { f -> f.complete(raw); return }
        confirmWait?.let { f -> f.complete(isYes(raw)); return }
        if (thinking) { h.postDelayed({ typed(raw) }, 1500); return }
        process(raw.trim())
    }

    private fun powerOn() = try { (getSystemService(POWER_SERVICE) as PowerManager).isInteractive } catch (e: Exception) { true }

    private fun has(t: String, vararg k: String) = k.any { t.lowercase().contains(it) }

    // ---------- Fast path: aasaan commands bina Gemini ke, turant ----------
    private val ytWords = setOf("यूट्यूब", "youtube", "यू", "ट्यूब")
    private val ytDrop = setOf("पर", "में", "से", "on")
    private val ytCmd = setOf("चलाओ", "चला", "चलाइए", "बजाओ", "बजा", "सुनाओ", "सुना", "सर्च", "search", "करो",
        "खोजो", "खोज", "play", "प्ले", "गाना", "गाने", "सॉन्ग", "song", "वीडियो", "video", "प्लीज", "please",
        "कर", "दो", "दे", "दीजिए", "दीजिये", "ज़रा", "जरा", "एक", "अभी", "फटाफट", "जल्दी", "म्यूजिक", "music")
    private val mediaGeneric = ytCmd + setOf("resume", "रेज़्यूम", "से", "को", "फिर")
    private val openCmd = setOf("खोलो", "खोल", "दो", "दे", "ओपन", "open", "करो", "ऐप", "app", "को", "प्लीज", "please")

    private fun fastPath(t: String): Boolean {
        var words = t.lowercase().split(" ", "\n").filter { it.isNotBlank() }
        if (words.isEmpty()) return false

        // Owner dawa: "मैं साकिब हूँ" -> awaaz se jaanch (naam sirf owner ki awaaz par hi milta hai)
        if (OwnerVoice.isClaim(t)) { ownerClaim(); return true }

        // 0) "Tumhe kisne banaya?"
        if (has(t, "किसने बनाया", "किसने डिजाइन", "किसने डिज़ाइन", "किसने बनाई", "तुम्हें किसने", "तुझे किसने", "तुम्हारा निर्माता",
                "तुम्हारा क्रिएटर", "who made you", "who created you", "who built you", "who designed you", "your creator")) {
            speak("मुझे साकिब सर ने डिज़ाइन किया है।")
            return true
        }

        // 0-) Pehchaan / yaadasht / aankh / tez jawab
        if (has(t, "कितना समय", "कितना टाइम", "कितने दिन", "कितनी देर", "how long", "kitna time") &&
            has(t, "बनाने", "बनाया", "बनी", "डिज़ाइन", "डिजाइन", "design", "built", "made")) {
            speak("साकिब सर पूरी रात जाग करके मुझे डिज़ाइन करके बनाए हैं।"); return true
        }
        // Naam bolkar set karo: "मेरा नाम राहुल है" / "मुझे राहुल बुलाओ" / "my name is Rahul"
        Regex("(?:मेरा नाम|my name is|मुझे)\\s+(.{2,30}?)(?:\\s+(?:है|बुलाओ|बुलाना|कहो|कहना))?$", RegexOption.IGNORE_CASE).find(t.trim())?.let { m ->
            val nmv = m.groupValues[1].replace(Regex("सना|sana", RegexOption.IGNORE_CASE), "").trim()
            val bad = setOf("क्या", "कौन", "kya", "what", "याद", "बताओ")
            if (nmv.isNotBlank() && nmv.lowercase() !in bad && !nmv.contains(" क्या") && (t.contains("मेरा नाम") || t.contains("my name", true) || t.contains("बुलाओ") || t.contains("कहो"))) {
                if (OwnerVoice.mentionsOwnerName(nmv)) { ownerClaim(); return true }
                Store.userName = nmv; speak("ठीक है $nmv, अब से मैं आपको इसी नाम से बुलाऊँगी"); return true
            }
        }
        if (has(t, "मैं कौन हूँ", "मैं कौन हु", "मुझे पहचानो", "मेरा नाम क्या", "who am i")) {
            if (OwnerVoice.isSet()) { ownerClaim(true); return true }      // awaaz sunkar batati hai: owner hai ya nahi
            speak(if (Store.userName.isBlank()) "आपने अभी अपना नाम नहीं बताया। ऐप की सेटिंग में नाम डाल दीजिए, या बोलिए मेरा नाम और फिर अपना नाम।"
                  else "आप ${Store.userName.trim()} हैं, मेरे अपने।"); return true
        }
        if (has(t, "सब भूल जाओ", "मेमोरी साफ", "याददाश्त साफ")) {
            Store.facts = emptyList(); brain.reset(); speak("ठीक है, सब भूल गई"); return true
        }
        if (has(t, "मेरा चेहरा याद", "मेरी शक्ल याद", "मेरा चेहरा रजिस्टर")) { registerFace(); return true }
        if (has(t, "आँख खोलो", "आंख खोलो", "आँख चालू", "आंख चालू", "निगरानी चालू", "निगरानी शुरू")) { setEye(true); return true }
        if (has(t, "आँख बंद", "आंख बंद", "निगरानी बंद")) { setEye(false); return true }

        // 0-b) Camera (mujhe dekho) / Screen share / Neon on-off
        val onW = words.any { it in setOf("चालू", "ऑन", "on", "शुरू", "start") }
        val offW = words.any { it in setOf("बंद", "बन्द", "ऑफ", "off", "stop") }
        if (has(t, "स्क्रीन शेयर", "screen share", "स्क्रीनशेयर", "screenshare") && (onW || offW)) { setScreen(onW && !offW); return true }
        if (has(t, "कैरेक्टर", "करैक्टर", "किरदार", "character") && (onW || offW)) {
            Store.charOn = onW && !offW
            speak(if (Store.charOn) "ठीक है, मैं सामने आ गई" else "ठीक है, कैरेक्टर बंद कर दिया"); return true
        }
        if (has(t, "कैमरा", "camera") && (onW || offW) && !has(t, "आँख", "आंख")) { setCam(onW && !offW); return true }
        if (has(t, "नियॉन", "नियोन", "neon", "होलोग्राम", "hologram")) {
            if (offW) { Holo.hide(this); speak("ठीक है, नियॉन बंद कर दिया") } else { Holo.show(this); speak("ठीक है, नियॉन चालू") }
            return true
        }
        if (has(t, "याद रखो", "याद रखना")) {
            val fact = t.replace(Regex("सना|sana", RegexOption.IGNORE_CASE), "").replace(Regex("याद रखो|याद रखना"), "").trim()
            if (fact.isNotBlank()) { Store.addFact(fact); speak("ठीक है${sn()}, याद रख लिया"); return true }
        }
        if (words.size <= 3) {
            val g = words.joinToString(" ")
            val reply = when {
                g in setOf("हेलो", "हैलो", "हेलो सना", "हैलो सना", "hello", "hi", "hello sana") ->
                    listOf("हाय${sn()}, कहिए क्या हुक्म है?", "हाय बाबू, कैसे हो? मैं यहीं हूँ।").random()
                has(g, "कैसी हो", "कैसे हो") -> "मैं बिल्कुल ठीक हूँ${sn()}, आप कैसे हैं?"
                has(g, "थैंक", "शुक्रिया", "धन्यवाद") -> "अरे इसमें क्या बात है${sn()}, मैं हूँ ना।"
                else -> null
            }
            if (reply != null) { speak(reply); return true }
        }

        // 0a) Mic on/off
        if ((has(t, "माइक", "mic") && words.any { it in setOf("बंद", "off", "ऑफ") }) || has(t, "सुनना बंद", "मत सुनो", "सुनो मत")) {
            pendingMicOff = true
            speak("ठीक है, माइक बंद कर रही हूँ। चालू करने के लिए नोटिफिकेशन का बटन दबाइए")
            return true
        }
        if (has(t, "माइक", "mic") && words.any { it in setOf("ऑन", "on", "चालू") }) {
            speak("माइक तो चालू है"); return true
        }
        if (words.size <= 3 && words.any { it in setOf("होम", "home") }) { SanaAccessibility.home(); speak("ठीक है"); return true }
        if (words.size <= 3 && words.any { it in setOf("बैक", "back", "पीछे", "वापस") }) { SanaAccessibility.back(); speak("ठीक है"); return true }

        // 0c) Gaana/video control: pause, play, next, previous, awaaz
        val songCtx = has(t, "गाना", "गाने", "वीडियो", "म्यूजिक", "संगीत", "सॉन्ग", "song", "video", "music")
        if (has(t, "आवाज", "वॉल्यूम", "volume", "साउंड") && words.size <= 6) {
            val up = has(t, "बढ़ा", "बढा", "ज्यादा", "ज़्यादा", "तेज", "फुल") || words.any { it in setOf("up", "high", "increase") }
            val down = has(t, "घटा", "कम", "धीम", "धीरे") || words.any { it in setOf("down", "low", "decrease") }
            if (up || down) { volume(up && !down); speak("ठीक है"); return true }
        }
        if (words.size <= 4 && words.none { it in ytWords }) {
            val code = when {
                words.any { it in setOf("अगला", "अगले", "next", "नेक्स्ट") } -> android.view.KeyEvent.KEYCODE_MEDIA_NEXT
                words.any { it in setOf("पिछला", "पिछले", "previous", "प्रीवियस") } -> android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS
                words.any { it in setOf("पॉज़", "पॉज", "पोज़", "pause", "रोको", "रोक") } ||
                    (songCtx && words.any { it in setOf("बंद", "बन्द") }) -> android.view.KeyEvent.KEYCODE_MEDIA_PAUSE
                (words.any { it in setOf("प्ले", "play", "रेज़्यूम", "resume") } ||
                    (words.size <= 2 && words.any { it in setOf("चलाओ", "चला") })) &&
                    words.none { it !in mediaGeneric } -> android.view.KeyEvent.KEYCODE_MEDIA_PLAY
                else -> -1
            }
            if (code != -1) { mediaKey(code); speak("ठीक है"); return true }
        }

        // 0b) Phone lock / unlock
        val lockWord = words.any { it.startsWith("लॉक") || it.startsWith("लोक") || it == "lock" || it == "locked" || it == "लॉक्ड" }
        val openWord = words.any { it in setOf("खोलो", "खोल", "खोलना", "खुल", "खुलवाओ", "हटाओ", "हटा", "ओपन", "open", "unlock", "अनलॉक") }
        val unlockW = words.any { it == "अनलॉक" || it == "अनलोक" || it == "unlock" } ||
            (lockWord && openWord) ||
            (has(t, "स्क्रीन", "फोन", "फ़ोन", "screen", "phone") && words.any { it in setOf("ऑन", "on", "चालू", "जलाओ") })
        val lockW = lockWord && !unlockW
        if (unlockW) {
            val pat = PatternVault.load()
            if (pat != null && SanaAccessibility.inst != null) {
                Thread { unlockWithPattern(pat) }.start()
                return true
            }
            wakeScreen()
            if (SanaAccessibility.inst != null) h.postDelayed({ SanaAccessibility.swipeUp() }, 700)
            speak(if (pat == null) "स्क्रीन चालू कर दी है। पैटर्न से अपने आप खोलने के लिए ऐप की सेटिंग में पैटर्न सेव कीजिए।"
                  else "स्क्रीन चालू कर दी है। पैटर्न से खोलने के लिए एक्सेसिबिलिटी चालू कीजिए।")
            return true
        }
        if (lockW) {
            if (SanaAccessibility.inst == null && !SanaAdmin.isActive(this)) { speak("लॉक करने के लिए पहले एक्सेसिबिलिटी या डिवाइस एडमिन चालू कीजिए"); return true }
            speak("ठीक है, फ़ोन लॉक कर रही हूँ")
            h.postDelayed({ if (!SanaAdmin.lockNow(this)) SanaAccessibility.lockScreen() }, 1500)
            return true
        }

        // 1) YouTube par gaana/video
        val songAsk = words.size >= 3 && has(t, "गाना", "गाने", "सॉन्ग", "song") && has(t, "चला", "बजा", "play", "प्ले", "सुना")
        val isYt = words.any { it in ytWords } || songAsk
        if (isYt && has(t, "चला", "बजा", "play", "प्ले", "सुना", "सर्च", "search", "खोज", "गाना", "गाने", "सॉन्ग", "song", "वीडियो")) {
            if (words.last() in setOf("दो", "दे")) words = words.dropLast(1)
            val q = words.filterIndexed { i, w ->
                w !in ytWords && w !in ytCmd &&
                    !(w in ytDrop && ((i > 0 && words[i - 1] in ytWords) || (i < words.size - 1 && words[i + 1] in ytWords)))
            }.joinToString(" ").trim()
            val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q) + "&sp=EgIQAQ%253D%253D")
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.youtube").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            speak(if (q.isBlank()) "ठीक है, खोल दिया" else "ठीक है, चला रही हूँ")
            if (q.isNotBlank()) h.postDelayed({ playFirstYoutube(0) }, 700)
            return true
        }

        // 1b) "Chrome me kesariya search karo": app + search box + enter
        if (tryAppSearch(words)) return true

        // 2) Chhota "X kholo" command
        if (words.size <= 4 && words.any { it in openCmd && it != "दो" && it != "दे" && it != "करो" && it != "को" && it != "ऐप" && it != "app" && it != "प्लीज" && it != "please" }) {
            val name = words.filter { it !in openCmd }.joinToString(" ")
            if (name.isNotBlank()) {
                val r = try { openApp(name) } catch (e: Exception) { "fail" }
                if (r.startsWith("ok")) { speak("ठीक है, खोल दिया"); return true }
            }
        }
        return false
    }

    // ---------- "X app me Y search/type karo": app kholo, search box dhundho, type karke enter, sab jaldi ----------
    private val inWords = setOf("में", "मे", "me", "mein", "पर", "par", "on", "in")
    private val searchVerbs = setOf("सर्च", "search", "खोजो", "खोज", "ढूंढो", "ढूँढो", "ढूंढ", "टाइप", "type", "लिखो", "लिख")
    private val srchFiller = setOf("करो", "कर", "दो", "दे", "दीजिए", "दीजिये", "करके", "को", "प्लीज", "please", "जल्दी", "फटाफट", "ज़रा", "जरा", "अभी", "एक", "और", "फिर")

    private fun tryAppSearch(words: List<String>): Boolean {
        if (words.none { it in searchVerbs }) return false
        val pi = words.indexOfFirst { it in inWords }
        if (pi <= 0) return false
        val cands = listOfNotNull(if (pi >= 2) words[pi - 2] + " " + words[pi - 1] else null, words[pi - 1])
        var startIdx = -1
        for (c in cands) {
            val r = try { openApp(c) } catch (e: Exception) { "fail" }
            if (r.startsWith("ok")) { startIdx = pi - c.split(" ").size; break }
        }
        if (startIdx < 0) return false
        val q = (words.take(startIdx) + words.drop(pi + 1)).filter { it !in searchVerbs && it !in srchFiller }.joinToString(" ").trim()
        if (q.isBlank()) { speak("ठीक है, खोल दिया"); return true }
        speak("ठीक है")
        Thread { SanaAccessibility.searchInApp(q) }.start()
        return true
    }

    // ---------- Aankh: camera se nazar, kaun aaya/gaya ----------
    private var eyeOn = false
    private var lastThumb: IntArray? = null
    private var lastScene = ""
    private val ownerFile get() = java.io.File(filesDir, "owner.jpg")
    private fun ownerPhoto(): ByteArray? = try { if (ownerFile.exists()) ownerFile.readBytes() else null } catch (e: Exception) { null }

    private fun registerFace() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { speak("कैमरा की परमिशन दीजिए"); return }
        speak("ठीक है${sn()}, कैमरे की तरफ देखिए")
        Bus.photo = { jpg ->
            Bus.photo = null
            if (jpg == null) speak("फोटो नहीं ले पाई")
            else {
                try { ownerFile.writeBytes(jpg) } catch (e: Exception) {}
                speak("आपका चेहरा याद कर लिया${sn()}, अब मैं आपको पहचान लूँगी")
            }
        }
        h.postDelayed({ startActivity(Intent(this, CamActivity::class.java).putExtra("front", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, 3500)
    }

    private val eyeTick = object : Runnable {
        override fun run() {
            if (!eyeOn) return
            if (!speaking && !thinking) {
                Bus.photo = { jpg -> Bus.photo = null; if (jpg != null && eyeOn) eyeAnalyze(jpg) }
                startActivity(Intent(this@SanaService, CamActivity::class.java).putExtra("front", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            h.postDelayed(this, 25000)
        }
    }

    private fun setEye(on: Boolean) {
        if (on && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { speak("कैमरा की परमिशन दीजिए"); return }
        eyeOn = on; eyeState = on; refreshNotif()
        h.removeCallbacks(eyeTick); lastThumb = null; lastScene = ""
        if (on) { h.postDelayed(eyeTick, 4000); speak("ठीक है${sn()}, मेरी आँख खुल गई, अब मैं नज़र रखूँगी") }
        else speak("ठीक है, आँख बंद कर दी")
    }

    private fun thumbOf(jpg: ByteArray): IntArray? = try {
        val b = android.graphics.BitmapFactory.decodeByteArray(jpg, 0, jpg.size)
        val sm = android.graphics.Bitmap.createScaledBitmap(b, 24, 24, true)
        IntArray(576) {
            val c = sm.getPixel(it % 24, it / 24)
            (android.graphics.Color.red(c) + android.graphics.Color.green(c) + android.graphics.Color.blue(c)) / 3
        }
    } catch (e: Exception) { null }

    private fun eyeAnalyze(jpg: ByteArray) {
        val th = thumbOf(jpg) ?: return
        val old = lastThumb
        val changed = old == null || th.indices.sumOf { kotlin.math.abs(th[it] - old[it]) } / th.size > 10
        lastThumb = th
        if (!changed) return          // kuch badla nahi: Gemini ko mat bulao (limit bachti hai)
        Thread {
            val ref = ownerPhoto()
            val prompt = "Ye ghar ka camera hai. " +
                (if (ref != null) "Pehli photo Saqib sir (tumhare malik) ki hai, doosri abhi ki. " else "") +
                "Pichla scene: '" + lastScene + "'. Abhi ki photo dekho aur saaf batao: Saqib sir hain ya nahi, aur koi aur insaan hai ya nahi. " +
                "Agar pichle scene se koi naya aaya ya gaya ya kuch khaas badla to 'ALERT:' likhkar ek chhota Hindi vakya (Devanagari) likho. " +
                "Warna 'OK:' likhkar scene ka chhota vivaran likho."
            val out = try { if (ref != null) brain.vision(prompt, ref, jpg) else brain.vision(prompt, jpg) } catch (e: Exception) { "" }
            h.post {
                val msg = out.trim()
                if (msg.startsWith("ALERT:")) {
                    val say = msg.removePrefix("ALERT:").trim(); lastScene = say
                    if (say.isNotBlank()) speak(say)
                } else if (msg.isNotBlank()) lastScene = msg.removePrefix("OK:").trim()
            }
        }.start()
    }

    private fun playFirstYoutube(n: Int) {
        if (SanaAccessibility.clickFirstVideo()) return
        if (n < 24) h.postDelayed({ playFirstYoutube(n + 1) }, 250)
        else { val dm = resources.displayMetrics; SanaAccessibility.tap(dm.widthPixels / 2f, dm.heightPixels * 0.30f) }
    }

    private fun lookWithCamera(t: String) {
        if (Store.key.isBlank()) { speak("पहले ऐप में एपीआई की डालिए"); return }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            speak("कैमरा की परमिशन दीजिए, ऐप की सेटिंग में परमिशन वाला बटन दबाइए"); return
        }
        val front = has(t, "मुझे", "मैं", "मेरा", "मेरी")
        thinking = true; Holo.speaking(true)
        var done = false
        Bus.photo = { jpg ->
            if (!done) {
                done = true
                if (jpg == null) { thinking = false; Holo.speaking(false); speak("फोटो नहीं ले पाई") }
                else askBrain("Ye " + (if (front) "mere selfie camera" else "peeche wale camera") + " ki photo hai. Photo dekhkar jawab do. Mera sawal: " + t, jpg, if (front) ownerPhoto() else null)
            }
        }
        startActivity(Intent(this, CamActivity::class.java).putExtra("front", front).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        h.postDelayed({ if (!done) { done = true; Bus.photo = null; thinking = false; Holo.speaking(false); speak("कैमरा नहीं खुल पाया") } }, 10000)
    }

    private fun process(t: String) {
        if (callCommand(t)) return
        // mode switch
        val m = when {
            has(t, "इमोशनल", "emotional", "भावुक") -> 3
            has(t, "वेटिंग", "waiting", "इंतज़ार", "इंतजार") -> 4
            has(t, "रोमांटिक", "romantic") -> 5
            has(t, "गर्लफ्रेंड", "girlfriend") -> 0
            has(t, "फ्रेंड मोड", "दोस्त मोड", "friend mode", "फ्रेंड") -> 1
            has(t, "एआई मोड", "ai mode", "एआई", "असिस्टेंट मोड") -> 2
            else -> -1
        }
        if (m >= 0 && has(t, "मोड", "mode", "बनो", "बन जा", "बन जाओ")) {
            Store.mode = m; applyMode(); brain.reset()
            speak(when (m) {
                0 -> "ठीक है जान, अब मैं तुम्हारी गर्लफ्रेंड मोड में हूँ"; 1 -> "चल ठीक है यार, फ्रेंड मोड ऑन"
                3 -> "ठीक है जान, अब मैं इमोशनल मोड में हूँ, अपने दिल की बात बताओ"
                4 -> "ठीक है बाबू, मैं तुम्हारा इंतज़ार करूँगी, जब मन करे तब बुला लेना"
                5 -> "ठीक है मेरी जान, रोमांटिक मोड चालू हो गया"
                else -> "एआई मोड चालू हो गया" })
            return
        }
        // Waiting mode me user ki pehli awaaz: pyaar bhari shikayat "kahan the?"
        if (Store.mode == 4 && Store.waiting && !has(t, "बंद", "bye", "stop", "स्टॉप")) {
            Store.waiting = false; speak(waitLine); return
        }
        if (has(t, "ऑफलाइन वॉइस", "ऑफलाइन आवाज", "ऑफ़लाइन वॉइस", "ऑफ़लाइन आवाज", "offline voice")) {
            val on = !has(t, "बंद", "off", "हटा")
            Store.offline = on; sr?.cancel(); recActive = false
            speak(if (on) "ऑफलाइन आवाज़ पहचान चालू। इसके लिए हिंदी ऑफलाइन पैक डाउनलोड होना चाहिए" else "ऑफलाइन आवाज़ पहचान बंद")
            return
        }
        if (has(t, "गार्जियन", "गार्डियन", "guardian")) { guardCommand(t); return }
        if (fastPath(t)) return
        if (has(t, "सो जाओ", "स्लीप मोड", "sleep mode", "बंद हो जाओ", "बाय", "bye", "स्टॉप", "stop", "बंद करो") || (t.trim().split(" ").size <= 2 && has(t, "बंद", "बन्द"))) {
            awakeUntil = 0L; commentaryOn = false; Holo.hide(this); speak("ठीक है, बाय"); return
        }
        if (Store.key.isBlank()) { speak("पहले ऐप में एपीआई की डालिए"); return }
        if (!has(t, "स्क्रीन", "screen", "क्या चल रहा", "क्या कर रहा") &&
            has(t, "कैमरा", "camera", "मुझे देख", "सामने", "क्या दिख", "देखकर", "देख कर", "मैं कैसा", "मैं कैसी", "मेरा चेहरा", "ये क्या है", "यह क्या है", "फोटो")) {
            lookWithCamera(t); return
        }
        val q = if (has(t, "देख", "स्क्रीन", "क्या कर रहा", "क्या चल रहा", "ये क्या है", "यह क्या है", "screen"))
            "Mere phone ki screen par abhi ye dikh raha hai:\n${SanaAccessibility.screenText()}\nMera sawal/kaam: $t\nScreen dekhkar jawab do."
        else t
        Persona.noteUser(t)   // user ki baat Sana ko dil se lagti hai: chot / pyaar / dukh / khushi
        askBrain(q, senses = camOn || screenOn)
    }

    private fun askBrain(q: String, img: ByteArray? = null, ref: ByteArray? = null, senses: Boolean = false) {
        thinking = true; thinkingState = true; Holo.speaking(true)
        Thread {
            var im = img; var rf = ref; var im2: ByteArray? = null; var qq = q
            if (senses) {   // screen pehle (camera ka popup screen par aane se pehle), phir camera
                val shot = if (screenOn) SanaAccessibility.screenshotSync() else null
                val selfie = if (camOn) captureSelfSync() else null
                when {
                    selfie != null && shot != null -> { im = selfie; rf = ownerPhoto(); im2 = shot
                        qq = "(Camera wali photo meri abhi ki selfie hai aur aakhri photo meri phone screen ka screenshot hai.) " + q }
                    selfie != null -> { im = selfie; rf = ownerPhoto(); qq = "(Ye meri abhi ki selfie camera ki photo hai.) " + q }
                    shot != null -> { im = shot; qq = "(Ye meri phone screen ka screenshot hai.) " + q }
                }
            }
            val reply = try { brain.ask(qq, im, rf, im2) } catch (e: Exception) {
                android.util.Log.e("Sana", e.toString())
                val m = e.toString()
                Store.lastErr = m.take(900)
                h.post { android.widget.Toast.makeText(this, m.take(160), android.widget.Toast.LENGTH_LONG).show() }
                when {
                    m.contains("429") || m.contains("RESOURCE_EXHAUSTED") || m.contains("quota", true) -> "जेमिनी की लिमिट खत्म हो गई है, थोड़ी देर बाद बोलिए"
                    m.contains("UnknownHost") || m.contains("timeout", true) || m.contains("Unable to resolve") -> "इंटरनेट में दिक्कत है"
                    m.contains("API key", true) || m.contains("API_KEY") || m.contains("PERMISSION") -> "एपीआई की में दिक्कत है"
                    else -> "जेमिनी से जवाब लेने में कुछ गड़बड़ हुई, ऐप में आखिरी एरर देखिए"
                }
            }
            thinking = false; thinkingState = false
            val (clean, emo) = Persona.parse(reply)
            Persona.applyState(emo)
            h.post { nextEmo = emo; speak(clean.ifBlank { "ठीक है" }) }
        }.start()
    }

    // ---------- Mic: gaana ko disturb kiye bina ----------
    private fun musicPlaying(): Boolean = try {
        (getSystemService(AUDIO_SERVICE) as android.media.AudioManager).isMusicActive
    } catch (e: Exception) { false }

    // Gaana/video chal raha ho to Sana mic nahi kholti (nahi to Android gaana rok deta hai).
    // Bolne ke liye: notification ka "बोलो" button ya hologram par tap.
    private fun musicBlocks() =
        SystemClock.elapsedRealtime() > forceListenUntil && confirmWait == null && musicPlaying()

    // recogniser ki "ting" awaaz band: sirf tab jab koi gaana nahi chal raha
    private fun muteMusic(m: Boolean) {
        if (musicMuted == m) return
        try {
            val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
            if (m) {
                if (am.isStreamMute(android.media.AudioManager.STREAM_MUSIC)) return   // user ne khud mute kiya hai
                am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_MUTE, 0)
            } else am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_UNMUTE, 0)
            musicMuted = m
        } catch (e: Exception) {}
    }

    private var lastCallAnnounceAt = 0L

    /** Call aane par: naam bolo, phir jawab (uthao / kaato) sunne ke liye mic turant kholo */
    private fun announceCall(msg: String) {
        val now = SystemClock.elapsedRealtime()
        if (lastCallAnnounceAt != 0L && now - lastCallAnnounceAt < 8000) return   // ek hi ring par do baar nahi
        lastCallAnnounceAt = now
        if (!micOn) { micOn = true; micOnState = true; refreshNotif() }
        forceListenUntil = now + 40000
        awakeUntil = now + FOREVER; lastActive = now; careCount = 0
        Holo.show(this)
        val canAct = checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED
        speak(if (canAct) "$msg। उठाऊँ या काट दूँ?" else msg)
    }

    /** "कॉल उठाओ" / "कॉल उठाकर स्पीकर पर डालो" / "कॉल काट दो" / "रिजेक्ट": Gemini ke bina turant */
    private fun callCommand(t: String): Boolean {
        val ring = Bus.ringing
        val callW = has(t, "कॉल", "call", "फोन", "फ़ोन", "फ़ून", "phone")
        val spk = has(t, "स्पीकर", "speaker", "लाउडस्पीकर")
        val ansW = has(t, "उठा", "रिसीव", "receive", "अटेंड", "attend", "pick", "answer")
        val rejW = has(t, "काट", "कट कर", "कट दो", "रिजेक्ट", "रिजैक्ट", "reject", "डिस्कनेक्ट", "disconnect", "decline", "cut the call", "end call", "हैंग", "hang")
        when {
            ansW && (callW || ring) && !rejW -> {
                val r = CallControl.answer(this, spk)
                if (r.startsWith("fail")) speak("कॉल उठाने की अनुमति नहीं है। ऐप में एक्स्ट्रा परमिशन दीजिए") 
                return true
            }
            rejW && (callW || ring) -> {
                val r = CallControl.reject(this)
                if (r.startsWith("fail")) speak(if (r == CallControl.NO_PERM) "कॉल काटने की अनुमति नहीं है। ऐप में एक्स्ट्रा परमिशन दीजिए" else "कॉल नहीं कट पाया")
                return true
            }
            spk && (callW || ring) -> {
                val off = has(t, "बंद", "हटा", "off", "बन्द")
                CallControl.speaker(this, !off); return true
            }
        }
        return false
    }

    private fun talkOnce() {
        val now = SystemClock.elapsedRealtime()
        if (!micOn) { micOn = true; micOnState = true; refreshNotif() }
        forceListenUntil = now + 15000
        awakeUntil = now + FOREVER; lastActive = now; careCount = 0
        Holo.show(this)
        listen()
    }

    // ---------- Camera / Screen share / Media ----------
    private fun refreshNotif() { getSystemService(NotificationManager::class.java).notify(1, notif()) }

    private fun liveStatus() = listOfNotNull(
        if (camOn) "📷 कैमरा चालू" else null,
        if (screenOn) "🖥️ स्क्रीन शेयर चालू" else null,
        if (eyeOn) "👁️ आँख चालू" else null).joinToString(" • ")

    private fun setCam(on: Boolean) {
        if (on && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { speak("कैमरा की परमिशन दीजिए"); return }
        camOn = on; camState = on; refreshNotif()
        speak(if (on) "ठीक है${sn()}, अब मैं आपको देख सकती हूँ" else "ठीक है, कैमरा बंद कर दिया")
    }

    private fun setScreen(on: Boolean) {
        if (on) {
            if (SanaAccessibility.inst == null) { speak("स्क्रीन देखने के लिए पहले एक्सेसिबिलिटी चालू कीजिए"); return }
            if (Build.VERSION.SDK_INT < 30) { speak("आपके फोन में स्क्रीन शेयर नहीं चल सकता"); return }
        }
        screenOn = on; screenState = on; refreshNotif()
        speak(if (on) "ठीक है${sn()}, अब मैं आपकी स्क्रीन देख सकती हूँ" else "ठीक है, स्क्रीन शेयर बंद कर दिया")
    }

    private fun captureSelfSync(): ByteArray? {
        val latch = java.util.concurrent.CountDownLatch(1)
        var out: ByteArray? = null
        Bus.photo = { jpg -> out = jpg; latch.countDown() }
        h.post { startActivity(Intent(this, CamActivity::class.java).putExtra("front", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        latch.await(9, java.util.concurrent.TimeUnit.SECONDS)
        Bus.photo = null
        return out
    }

    private fun mediaKey(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, code))
    }

    private fun volume(up: Boolean) {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        repeat(3) {
            am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC,
                if (up) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER,
                if (it == 2) android.media.AudioManager.FLAG_SHOW_UI else 0)
        }
    }

    // ---------- Confirmation (call / send / risky tap se pehle) ----------
    @Volatile private var confirmWait: java.util.concurrent.CompletableFuture<Boolean>? = null
    @Volatile private var lastTyped = ""
    private val noWords = setOf("नहीं", "नही", "नहि", "ना", "मत", "no", "nahi", "nahin", "cancel", "कैंसिल", "रुको", "रुक", "छोड़ो", "छोड़", "गलत", "स्टॉप", "stop")
    private val yesWords = setOf("हाँ", "हां", "हा", "yes", "yeah", "ok", "okay", "ओके", "ठीक", "सही", "भेजो", "भेज", "लगाओ", "लगा", "करो", "बिल्कुल", "पक्का")
    private val riskyTap = listOf("send", "भेज", "pay", "भुगतान", "transfer", "ट्रांसफर", "delete", "डिलीट", "हटा", "buy", "खरीद", "order", "ऑर्डर", "call", "कॉल", "post", "पोस्ट")

    // shor ya samajh na aaye to jawab "nahi" maana jata hai (safe default)
    private fun isYes(raw: String): Boolean {
        val w = raw.lowercase().split(Regex("[\\s,।.?!]+")).filter { it.isNotBlank() }
        if (w.any { it in noWords }) return false
        return w.any { it in yesWords }
    }

    /** Brain ke background thread se bulaya jata hai: bolkar poochhta hai aur jawab ka intezaar karta hai */
    private fun confirm(q: String): Boolean {
        val f = java.util.concurrent.CompletableFuture<Boolean>()
        confirmWait = f
        thinking = false                 // taaki mic jawab sun sake
        h.post { speak(q) }
        val ok = try { f.get(30, java.util.concurrent.TimeUnit.SECONDS) } catch (e: Exception) { false }
        confirmWait = null
        thinking = true; h.post { Holo.speaking(true) }
        return ok
    }

    private val denied = "fail: user ne mana kar diya ya jawab nahi diya, ye kaam dobara mat karo"

    // ---------- Tools ----------
    private fun runTool(n: String, a: JSONObject): String {
        if (Store.guardOn && n in guardTools && !guardPassed()) return "fail: Voice Guardian: गुप्त शब्द गलत या नहीं मिला, ये काम दोबारा मत करो"
        return runTool2(n, a)
    }

    private fun runTool2(n: String, a: JSONObject): String = when (n) {
        "game_commentary" -> {
            val on = a.optString("state").lowercase().let { it == "on" || it.contains("chalu") || it.contains("start") }
            if (on && SanaAccessibility.inst == null) "fail: pehle Accessibility chalu karo, tabhi screen dikhegi"
            else { commentaryOn = on; lastCommentary = 0L; if (on) "ok: commentary chalu, game kholo (har 15 second me ek line)" else "ok: commentary band" }
        }
        "open_app" -> openApp(a.getString("name"))
        "call_contact" -> {
            val nm = a.getString("name")
            if (confirm("क्या $nm को कॉल लगाऊँ?")) callContact(nm) else denied
        }
        "type_text" -> {
            val tx = a.getString("text"); lastTyped = tx
            if (SanaAccessibility.typeText(tx)) "ok" else "fail: koi text box focus me nahi"
        }
        "send_message" -> {
            val q = if (lastTyped.isBlank()) "क्या मैसेज भेज दूँ?" else "क्या ये मैसेज भेज दूँ? ${lastTyped.take(80)}"
            if (!confirm(q)) denied
            else { lastTyped = ""; if (SanaAccessibility.send()) "ok" else "fail: send button nahi mila" }
        }
        "tap" -> {
            val tx = a.getString("text")
            if (riskyTap.any { tx.lowercase().contains(it) } && !confirm("क्या मैं $tx दबा दूँ?")) denied
            else if (SanaAccessibility.clickText(tx)) "ok" else "fail: screen par nahi mila"
        }
        "scroll" -> if (SanaAccessibility.scroll(a.getString("direction").contains("down"))) "ok" else "fail"
        "global" -> when (a.getString("action")) {
            "back" -> SanaAccessibility.back(); "home" -> SanaAccessibility.home(); else -> SanaAccessibility.recents()
        }.toString()
        "read_notifications" -> synchronized(Bus.notifs) {
            val l = Bus.notifs.takeLast(8); Bus.notifs.clear()
            if (l.isEmpty()) "koi naya notification nahi" else l.joinToString("\n")
        }
        "press_enter" -> if (SanaAccessibility.pressEnter()) "ok" else "fail: enter/search nahi dab paya"
        "search_in_app" -> {
            val r = openApp(a.getString("app"))
            if (!r.startsWith("ok")) r
            else if (SanaAccessibility.searchInApp(a.getString("query"))) "ok: search kar diya" else "fail: search box nahi mila"
        }
        "get_screen_text" -> SanaAccessibility.screenText()
        "open_url" -> {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok"
        }
        "media" -> {
            when (a.optString("action")) {
                "play" -> mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
                "pause" -> mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PAUSE)
                "next" -> mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
                "previous" -> mediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                "volume_up" -> volume(true)
                "volume_down" -> volume(false)
            }
            "ok"
        }
        "remember" -> { Store.addFact(a.optString("fact")); "ok, yaad rakh liya" }
        "wait" -> { Thread.sleep(((a.optString("seconds").toDoubleOrNull() ?: 2.0).coerceIn(0.5, 5.0) * 1000).toLong()); "ok" }
        "flashlight" -> try {
            val cm = getSystemService(android.content.Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) "fail: is phone me torch nahi" else { cm.setTorchMode(id, a.optString("state").lowercase().contains("on")); "ok" }
        } catch (e: Exception) { "fail: " + e.message }
        "device_status" -> try {
            val bi = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lvl = bi?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = bi?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100
            val st = bi?.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1) ?: -1
            val chg = st == android.os.BatteryManager.BATTERY_STATUS_CHARGING || st == android.os.BatteryManager.BATTERY_STATUS_FULL
            val cmg = getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val caps = cmg.getNetworkCapabilities(cmg.activeNetwork)
            val net = when { caps == null -> "offline"; caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"; caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"; else -> "online" }
            val mi = android.app.ActivityManager.MemoryInfo(); (getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
            val sf = android.os.StatFs(android.os.Environment.getDataDirectory().path)
            "battery ${lvl * 100 / sc}%, charging=${chg}, network=$net, RAM free ${mi.availMem / 1048576}MB of ${mi.totalMem / 1048576}MB, storage free ${sf.availableBytes / 1073741824}GB of ${sf.totalBytes / 1073741824}GB"
        } catch (e: Exception) { "fail: " + e.message }
        "set_alarm" -> try {
            startActivity(Intent(android.provider.AlarmClock.ACTION_SET_ALARM)
                .putExtra(android.provider.AlarmClock.EXTRA_HOUR, a.getString("hour").toInt())
                .putExtra(android.provider.AlarmClock.EXTRA_MINUTES, a.optString("minute", "0").toIntOrNull() ?: 0)
                .putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, a.optString("label", "Sana"))
                .putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok: alarm lag gaya"
        } catch (e: Exception) { "fail: " + e.message }
        "set_timer" -> try {
            startActivity(Intent(android.provider.AlarmClock.ACTION_SET_TIMER)
                .putExtra(android.provider.AlarmClock.EXTRA_LENGTH, a.getString("seconds").toInt())
                .putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, a.optString("label", "Sana"))
                .putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok: timer chalu"
        } catch (e: Exception) { "fail: " + e.message }
        "weather" -> try {
            val c = java.net.URLEncoder.encode(a.getString("city"), "UTF-8")
            val cn = URL("https://wttr.in/$c?format=%l:+%C,+%t,+humidity+%h,+wind+%w").openConnection() as HttpURLConnection
            cn.connectTimeout = 8000; cn.readTimeout = 8000
            cn.inputStream.bufferedReader().readText().trim()
        } catch (e: Exception) { "fail: mausam nahi mila (internet check karo)" }
        "web_search" -> {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + java.net.URLEncoder.encode(a.getString("query"), "UTF-8"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok"
        }
        "navigate" -> try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(a.getString("place")))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok"
        } catch (e: Exception) { "fail: Maps nahi mila" }
        "whatsapp_draft" -> try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + a.getString("number").filter { it.isDigit() } + "?text=" + Uri.encode(a.optString("text")))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "ok: message tayyar hai, send button user dabayega"
        } catch (e: Exception) { "fail: " + e.message }
        "sms_draft" -> try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(a.getString("number")))).putExtra("sms_body", a.optString("text")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "ok: SMS tayyar hai, send user dabayega"
        } catch (e: Exception) { "fail: " + e.message }
        "share_text" -> try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.getString("text")), "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok"
        } catch (e: Exception) { "fail: " + e.message }
        "open_settings" -> try {
            val act = when (a.optString("page").lowercase()) {
                "wifi" -> android.provider.Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> android.provider.Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> android.provider.Settings.ACTION_DISPLAY_SETTINGS
                "sound" -> android.provider.Settings.ACTION_SOUND_SETTINGS
                "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
                "accessibility" -> android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS
                else -> android.provider.Settings.ACTION_SETTINGS
            }
            startActivity(Intent(act).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok"
        } catch (e: Exception) { "fail: " + e.message }
        "note" -> { Store.addFact("NOTE: " + a.optString("text")); "ok, note save ho gaya" }
        else -> MoreTools.run(this, n, a, { q -> confirm(q) }) ?: ProTools.run(this, n, a, { q -> confirm(q) }) ?: SanaTools.run(this, n, a) { confirm(it) }
    }

    private fun onTrigger(act: String) {
        if (thinking || speaking) { h.postDelayed({ onTrigger(act) }, 4000); return }
        when {
            act.startsWith("say:") -> speak(act.removePrefix("say:").trim())
            act.startsWith("ask:") -> askBrain(act.removePrefix("ask:").trim())
            act.startsWith("routine:") -> askBrain("routine chalao: " + act.removePrefix("routine:").trim())
            else -> askBrain(act)
        }
    }

    private fun openApp(spoken: String): String {
        val low = spoken.lowercase()
        val key = aliases.entries.firstOrNull { low.contains(it.key) }?.value ?: low
        val pm = packageManager
        val app = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(key) }
            ?: return "fail: $spoken naam ka app nahi mila"
        val i = pm.getLaunchIntentForPackage(app.activityInfo.packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return "ok: ${app.loadLabel(pm)} khul gaya"
    }

    private fun callContact(name: String): String {
        var number = name.filter { it.isDigit() || it == '+' }
        if (number.filter { it.isDigit() }.length < 5) {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return "fail: contacts permission nahi"
            number = ""
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
            )?.use { if (it.moveToFirst()) number = it.getString(0) }
        }
        if (number.isBlank()) return "fail: $name ka number nahi mila"
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return "fail: call permission nahi"
        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "ok: $name ko call lag gaya"
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "mic") setMic(!micOn)
        if (i?.action == "pause_listen") { enrolling = true; sr?.cancel(); VoiceTee.stop(); recActive = false; listeningState = false; micLevel = 0f; muteMusic(false) }
        if (i?.action == "resume_listen") { enrolling = false; h.postDelayed({ listen() }, 400) }
        if (i?.action == "eye") setEye(!eyeOn)
        if (i?.action == "cam") setCam(!camOn)
        if (i?.action == "talk") talkOnce()
        if (i?.action == "stop_speech") stopSpeech()
        if (i?.action == "screen") setScreen(!screenOn)
        if (i?.action == "regface") registerFace()
        if (i?.action == "say") i.getStringExtra("t")?.let { if (it.isNotBlank()) h.postDelayed({ speak(it) }, if (ttsReady) 0L else 2500L) }
        if (i?.action == "type") i.getStringExtra("t")?.let { if (it.isNotBlank()) h.postDelayed({ typed(it) }, if (ttsReady) 0L else 2500L) }
        return START_STICKY
    }
    override fun onDestroy() {
        eyeOn = false; eyeState = false; camOn = false; camState = false; screenOn = false; screenState = false; running = false; talking = false; thinkingState = false; micLevel = 0f; listeningState = false; muteBeep(false); muteMusic(false); Bus.talk = null; Bus.announce = null; Bus.callAnnounce = null; Bus.ringing = false; h.removeCallbacksAndMessages(null); VoiceTee.stop(); Holo.hide(this)
        Triggers.fire = null; Triggers.stop(this)
        sr?.destroy(); if (::tts.isInitialized) tts.shutdown(); super.onDestroy()
    }
}

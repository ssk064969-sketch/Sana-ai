package com.sana.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini (Google AI Studio) function-calling brain */
class Brain(private val exec: (String, JSONObject) -> String) {
    private val history = JSONArray()

    private fun t(name: String, desc: String, vararg p: Pair<String, String>): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (p.isNotEmpty()) {
            val props = JSONObject(); val req = JSONArray()
            p.forEach { props.put(it.first, JSONObject().put("type", "string").put("description", it.second)); req.put(it.first) }
            o.put("parameters", JSONObject().put("type", "object").put("properties", props).put("required", req))
        }
        return o
    }

    private val tools = JSONArray().put(JSONObject().put("functionDeclarations", JSONArray().apply {
        put(t("open_app", "Phone me app kholo", "name" to "app ka naam, jaise whatsapp, youtube, camera"))
        put(t("call_contact", "Contact ko ya number par call lagao", "name" to "contact ka naam ya phone number"))
        put(t("type_text", "Jis text box par cursor hai usme text likho", "text" to "likhne wala text"))
        put(t("send_message", "Send/भेजें button dabao"))
        put(t("tap", "Screen par is text/label wale button ko tap karo", "text" to "button ya item ka text"))
        put(t("scroll", "Screen scroll karo", "direction" to "down ya up"))
        put(t("global", "System action", "action" to "back, home ya recents"))
        put(t("read_notifications", "Aaye hue notifications (WhatsApp wagera) padho"))
        put(t("get_screen_text", "Abhi screen par kya likha hai wo dekho. Tap/type se pehle isse screen dekho."))
        put(t("open_url", "Browser me URL ya Google search kholo", "url" to "poora https URL"))
        put(t("wait", "Kuch second ruko (app khulne ke liye)", "seconds" to "1 se 5"))
    }))

    private fun system(): String {
        val persona = when (Store.mode) {
            0 -> "Tum 'सना' ho, user ki pyaari girlfriend jaisi: romantic, caring, thodi naughty-flirty, pyaar bhare shabd (जान, बाबू). Pyaar se baat karo, lekin kaam poora karo. Explicit/adult content kabhi nahi."
            1 -> "Tum 'सना' ho, user ki best friend: bindaas, mazaakiya, 'यार' wali bhasha, saath hi sachchi salaah deti ho."
            else -> "Tum 'सना' ho, ek smart professional AI assistant: seedha, saaf aur sateek jawab."
        }
        return persona + " Tum ladki ho, Hindi me baat karti ho. Jawab sirf Devanagari Hindi me, 1-2 chhote vakya (kyunki bolkar sunaya jayega), koi emoji ya markdown nahi. " +
            "Tum user ka phone tools se chala sakti ho: jab bhi koi kaam bole to tools use karo, jarurat ho to kai tools ek ke baad ek chalao " +
            "(pehle get_screen_text se screen dekho, phir tap/type). Kaam ke baad batao ki kya kiya. Sawal ho to khud jawab do."
    }

    private fun post(contents: JSONArray): JSONObject {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", contents)
            .put("tools", tools)
        val k = Store.key
        val studio = "https://generativelanguage.googleapis.com/v1beta/models/${Store.model}:generateContent"
        val vertex = "https://aiplatform.googleapis.com/v1/publishers/google/models/${Store.model}:generateContent?key=$k"
        // AQ. wali key = Vertex express endpoint, AIza wali = AI Studio endpoint
        val urls = if (k.startsWith("AQ.")) listOf(vertex, studio) else listOf(studio, vertex)
        var lastErr = ""
        for (url in urls) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 45000; c.doOutput = true
            if (!url.contains("?key=")) c.setRequestProperty("x-goog-api-key", k)
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val ok = c.responseCode in 200..299
            val txt = (if (ok) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
            if (ok) return JSONObject(txt)
            lastErr = txt
            if (c.responseCode == 429) break   // quota: dusra endpoint try karne ka fayda nahi
        }
        throw RuntimeException(lastErr)
    }

    private fun textOf(parts: JSONArray): String {
        val sb = StringBuilder()
        for (i in 0 until parts.length()) parts.getJSONObject(i).optString("text").let { if (it.isNotBlank()) sb.append(it) }
        return sb.toString().trim()
    }

    fun ask(text: String): String {
        val contents = JSONArray(history.toString())
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        repeat(8) {
            val r = post(contents)
            val cand = r.optJSONArray("candidates")?.optJSONObject(0) ?: return "मुझे इसका जवाब नहीं मिला"
            val content = cand.optJSONObject("content") ?: return "मुझे इसका जवाब नहीं मिला"
            val parts = content.optJSONArray("parts") ?: return "ठीक है"
            contents.put(content)   // model turn ko jaisa hai waisa wapas bhejte hain

            val results = JSONArray()
            for (i in 0 until parts.length()) {
                val fc = parts.getJSONObject(i).optJSONObject("functionCall") ?: continue
                val name = fc.getString("name")
                val out = try { exec(name, fc.optJSONObject("args") ?: JSONObject()) } catch (e: Exception) { "error: ${e.message}" }
                results.put(JSONObject().put("functionResponse",
                    JSONObject().put("name", name).put("response", JSONObject().put("result", out))))
            }
            if (results.length() > 0) {
                contents.put(JSONObject().put("role", "user").put("parts", results))
            } else {
                val out = textOf(parts)
                history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
                history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", out.ifBlank { "ठीक है" }))))
                while (history.length() > 16) { history.remove(0); history.remove(0) }
                return out
            }
        }
        return "काम थोड़ा लंबा हो गया, दोबारा बोलिए"
    }

    fun reset() { while (history.length() > 0) history.remove(0) }
}

package com.sana.ai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot

/** 3x3 pattern banane wala pad. Dots 1..9 (upar-left se neeche-right). */
class PatternPad(c: Context, private val onDone: (List<Int>) -> Unit) : View(c) {
    private val sel = ArrayList<Int>()
    private var fx = 0f
    private var fy = 0f
    private var drawing = false
    private val d = resources.displayMetrics.density
    private val dotP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF8C98C8.toInt() }
    private val onP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFD946EF.toInt() }
    private val lineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFA855F7.toInt(); strokeWidth = 6 * d; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = minOf(MeasureSpec.getSize(w), (300 * d).toInt())
        setMeasuredDimension(s, s)
    }

    private fun cx(i: Int) = width / 6f + (i % 3) * width / 3f
    private fun cy(i: Int) = height / 6f + (i / 3) * height / 3f

    private fun hit(x: Float, y: Float): Int {
        for (i in 0..8) if (hypot(x - cx(i), y - cy(i)) < width / 7f) return i
        return -1
    }

    private fun add(n: Int) {
        if (n in sel) return
        if (sel.isNotEmpty()) {
            val l = sel.last()
            val r1 = l / 3; val c1 = l % 3; val r2 = n / 3; val c2 = n % 3
            if (abs(r1 - r2) % 2 == 0 && abs(c1 - c2) % 2 == 0) {
                val mid = ((r1 + r2) / 2) * 3 + (c1 + c2) / 2
                if (mid !in sel) sel.add(mid)
            }
        }
        sel.add(n)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        fx = e.x; fy = e.y
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { sel.clear(); drawing = true; val n = hit(e.x, e.y); if (n >= 0) add(n) }
            MotionEvent.ACTION_MOVE -> { val n = hit(e.x, e.y); if (n >= 0) add(n) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                drawing = false
                val out = sel.map { it + 1 }
                sel.clear()
                invalidate()
                if (out.isNotEmpty()) onDone(out)
                return true
            }
        }
        invalidate()
        return true
    }

    override fun onDraw(c: Canvas) {
        for (k in 1 until sel.size) c.drawLine(cx(sel[k - 1]), cy(sel[k - 1]), cx(sel[k]), cy(sel[k]), lineP)
        if (drawing && sel.isNotEmpty()) c.drawLine(cx(sel.last()), cy(sel.last()), fx, fy, lineP)
        for (i in 0..8) c.drawCircle(cx(i), cy(i), (if (i in sel) 11 else 8) * d, if (i in sel) onP else dotP)
    }
}

package com.sana.ai

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Ek character ki photo + chehre ke nishaan (photo ke asli pixel me). ew = aankh ki chaudai, mw = munh ki chaudai */
class CharDef(
    val res: Int, val name: String, val viewH: Int,
    val lx: Float, val ly: Float, val lw: Float,     // baayi aankh (dekhne wale ki baayi taraf)
    val rx: Float, val ry: Float, val rw: Float,     // daayi aankh
    val mx: Float, val my: Float, val mw: Float,     // munh
    val px: Float, val py: Float,                    // gardan ka pivot (sar yahin se hilta hai)
    val blink: Boolean = true
)

object Chars {
    val list = listOf(
        CharDef(R.drawable.char1, "Gulabi Sana", 950, 290f, 352f, 70f, 405f, 312f, 68f, 375f, 418f, 70f, 370f, 560f),
        CharDef(R.drawable.char2, "Farishta Sana", 900, 340f, 297f, 70f, 465f, 257f, 68f, 440f, 362f, 50f, 400f, 480f),
        CharDef(R.drawable.char3, "Wisteria Sana", 840, 425f, 277f, 60f, 530f, 325f, 55f, 452f, 394f, 48f, 440f, 470f),
        CharDef(R.drawable.char4, "Chandi Sana", 960, 305f, 455f, 100f, 507f, 402f, 85f, 442f, 584f, 105f, 430f, 660f),
        CharDef(R.drawable.char5, "Barf Rani Sana", 950, 200f, 516f, 115f, 436f, 467f, 125f, 346f, 673f, 113f, 350f, 800f),
        CharDef(R.drawable.char6, "Chaand Sana", 950, 230f, 665f, 50f, 365f, 602f, 55f, 327f, 737f, 52f, 330f, 820f, blink = false)
    )
}

/**
 * 2D live character: photo ko mesh se halka hilaya jaata hai (saans, gardan, sar), uske upar
 * palak, muskaan, hansi, gaal ki laali, aansu aur lip-sync wala munh banta hai.
 * Lip-sync: SanaService.voiceLevel (asli awaaz ka level). Bhaav: SanaService.emoState + lastSaid.
 */
class CharView(c: Context) : View(c) {
    private var def: CharDef = Chars.list[0]
    private var bmp: Bitmap? = null
    private var idx = -1
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val MX = 14; private val MY = 26
    private val verts = FloatArray((MX + 1) * (MY + 1) * 2)

    // bhaav ki smooth halat (0..1)
    private var open = 0f; private var smile = 0.3f; private var laugh = 0f; private var blush = 0f; private var sad = 0f
    private var nextBlink = 0L; private var blinkAt = 0L
    private var skin = 0xFFF2CDBF.toInt(); private var lip = 0xFFE58A8A.toInt()
    private var lastT = 0.0
    private var tearT = 0f
    private val laughRe = Regex("हा हा|हाहा|हा-हा|haha|ha ha|hehe|he he|hihi|हीही|ही ही|हे हे|हेहे")

    fun setCharacter(i: Int) {
        val k = i.coerceIn(0, Chars.list.size - 1)
        if (k == idx && bmp != null) return
        idx = k; def = Chars.list[k]
        bmp = try { BitmapFactory.decodeResource(resources, def.res) } catch (e: Throwable) { null }
        bmp?.let { b ->
            try {
                skin = b.getPixel((def.mx).toInt().coerceIn(0, b.width - 1), (def.my + def.mw * 0.55f).toInt().coerceIn(0, b.height - 1))
                lip = b.getPixel(def.mx.toInt().coerceIn(0, b.width - 1), def.my.toInt().coerceIn(0, b.height - 1))
            } catch (e: Throwable) {}
        }
        requestLayout(); invalidate()
    }

    /** Hamesha photo ke ratio ke hisaab se unchai (sirf upar ka viewH hissa dikhta hai) */
    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val w = MeasureSpec.getSize(wSpec)
        val b = bmp
        val h = if (b != null) (w.toFloat() * def.viewH / b.width).toInt() else w
        setMeasuredDimension(w, h)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); postInvalidateOnAnimation() }

    private fun a(c: Int, al: Float) = (c and 0x00FFFFFF) or ((al * 255f).toInt().coerceIn(0, 255) shl 24)
    private fun ease(cur: Float, tgt: Float, k: Float) = cur + (tgt - cur) * k
    private fun darker(c: Int, f: Float) = Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    override fun onDraw(cv: Canvas) {
        val b = bmp ?: return
        val now = System.nanoTime() / 1e9
        val dt = (now - lastT).coerceIn(0.0, 0.1).toFloat(); lastT = now
        val k = (dt * 9f).coerceIn(0f, 1f)
        val t = now
        val W = b.width.toFloat(); val H = b.height.toFloat()
        val sc = width / W

        // ---------- bhaav (emotion) ----------
        val running = SanaService.running
        val talking = running && SanaService.talking && !SanaService.thinkingState
        val listening = running && SanaService.listeningState && SanaService.micLevel > 0.12f
        val emo = SanaService.emoState
        val said = SanaService.lastSaid.lowercase()
        val laughNow = talking && (SanaService.laughing || laughRe.containsMatchIn(said))
        val sadEmo = emo == "rona" || emo == "dil_toota" || emo == "udaas" || emo == "chinta" || (Store.feelOn && Store.hurt >= 2)
        val happyEmo = emo == "khush" || emo == "pyaar" || emo == "sharmili" || emo == "maan_gayi" || emo == "bhavuk"
        val sadT = if (sadEmo && (talking || !running)) 1f else if (sadEmo) 0.6f else 0f
        val laughT = if (laughNow || (talking && emo == "hasi")) 0.45f else 0f   // halki, dabi hui muskaan-wali hansi
        val smileT = when {
            laughT > 0f -> 0.85f
            sadT > 0f -> 0f
            talking && happyEmo -> 0.75f
            talking -> 0.5f
            listening -> 0.55f
            Store.mode == 0 || Store.mode == 5 || Store.mode == 1 -> 0.32f
            else -> 0.2f
        }
        val blushT = if (sadT > 0f) 0.1f else if (emo == "sharmili" || emo == "pyaar" || Store.mode == 5) 0.85f else if (talking || listening) 0.45f else 0.25f
        smile = ease(smile, smileT, k); laugh = ease(laugh, laughT, k * 1.3f); blush = ease(blush, blushT, k * 0.6f); sad = ease(sad, sadT, k * 0.7f)

        // ---------- lip-sync ----------
        val vl = SanaService.voiceLevel
        val sysVoice = Store.sarvamKey.isBlank() && Store.key.isBlank()
        var openT = (vl * 1.9f).coerceIn(0f, 1f)
        if (talking && sysVoice) openT = 0.15f + 0.6f * abs(sin(t * 11)).toFloat() * (0.5f + 0.5f * abs(sin(t * 5.3)).toFloat())
        if (laugh > 0.5f && talking) openT = maxOf(openT, 0.35f + 0.4f * abs(sin(t * 9)).toFloat())
        open = ease(open, openT, (dt * 22f).coerceIn(0f, 1f))

        // ---------- palak ----------
        val ms = System.currentTimeMillis()
        if (nextBlink == 0L) nextBlink = ms + 1500
        if (ms >= nextBlink) { blinkAt = ms; nextBlink = ms + 2200 + (Math.random() * 3200).toLong() }
        val bd = 150f; val bt = (ms - blinkAt) / bd
        var lid = if (bt in 0f..1f) (if (bt < 0.5f) bt * 2f else (1f - bt) * 2f) else 0f
        lid = maxOf(lid, sad * 0.28f)

        // ---------- sar/gardan/saans ki chaal ----------
        var roll = 0.7f * sin(t * 0.8).toFloat() + 0.4f * sin(t * 1.9 + 1).toFloat()
        var dx = 2.5f * sin(t * 0.7).toFloat(); var dy = 2f * sin(t * 1.3).toFloat()
        roll += open * 1.1f * sin(t * 5.2).toFloat()
        if (listening) { roll += 1.3f * sin(t * 2.6).toFloat(); dy += 2f * sin(t * 2.6).toFloat() }
        if (SanaService.thinkingState) roll += 2.2f
        roll += laugh * 2.2f * sin(t * 13).toFloat(); dy -= laugh * 7f * abs(sin(t * 9)).toFloat()
        roll += sad * 2.0f; dy += sad * 6f
        val breath = 1f + 0.0045f * sin(t * 1.5).toFloat()

        val th = Math.toRadians(roll.toDouble()); val cs = cos(th).toFloat(); val sn = sin(th).toFloat()
        val soft = H * 0.10f
        fun wgt(y: Float): Float { val q = ((def.py + soft - y) / (2f * soft)).coerceIn(0f, 1f); return q * q * (3f - 2f * q) }
        fun wx(x: Float, y: Float): Float {
            val w = wgt(y); val rx = def.px + (x - def.px) * cs - (y - def.py) * sn; val nx = x + (rx - x) * w + dx * w
            return W / 2f + (nx - W / 2f) * breath
        }
        fun wy(x: Float, y: Float): Float {
            val w = wgt(y); val ry = def.py + (x - def.px) * sn + (y - def.py) * cs; val ny = y + (ry - y) * w + dy * w
            return H + (ny - H) * breath
        }

        // ---------- mesh me photo ----------
        var n = 0
        for (j in 0..MY) for (i in 0..MX) {
            val bx = W * i / MX; val by = H * j / MY
            verts[n++] = wx(bx, by); verts[n++] = wy(bx, by)
        }
        cv.save()
        cv.scale(sc, sc)
        cv.clipRect(0f, 0f, W, def.viewH.toFloat())
        cv.drawBitmapMesh(b, MX, MY, verts, 0, null, 0, bp)

        // ---------- upar ke nishaan (sar ke saath hilte hain) ----------
        fun overlay(x: Float, y: Float, draw: () -> Unit) {
            cv.save(); cv.translate(wx(x, y), wy(x, y)); cv.rotate(roll); draw(); cv.restore()
        }
        // gaal ki laali
        if (blush > 0.05f) for ((ex, ey, ew) in listOf(Triple(def.lx, def.ly, def.lw), Triple(def.rx, def.ry, def.rw))) {
            overlay(ex, ey + ew * 0.78f) {
                val r = ew * 0.62f
                p.shader = RadialGradient(0f, 0f, r, intArrayOf(a(0xFFFF6F8F.toInt(), 0.34f * blush), a(0xFFFF6F8F.toInt(), 0f)), null, Shader.TileMode.CLAMP)
                p.style = Paint.Style.FILL; cv.drawCircle(0f, 0f, r, p); p.shader = null
            }
        }
        // aankh: palak jhapakna / hasne par ^_^
        if (def.blink) for ((ex, ey, ew) in listOf(Triple(def.lx, def.ly, def.lw), Triple(def.rx, def.ry, def.rw))) {
            val cover = maxOf(lid, laugh)
            if (cover > 0.04f) overlay(ex, ey) {
                val ehh = ew * 0.30f
                val ox = ew * 0.62f; val oy = ehh * 1.9f
                // skin ka naram patch (kinare dhundhle taaki jod na dikhe)
                p.style = Paint.Style.FILL
                p.shader = RadialGradient(0f, 0f, ox, intArrayOf(a(skin, 1f), a(skin, 1f), a(skin, 0f)), floatArrayOf(0f, 0.72f, 1f), Shader.TileMode.CLAMP)
                cv.save()
                cv.clipRect(-ox, -oy, ox, -ehh * 1.1f + ehh * 2.3f * cover)
                cv.drawOval(-ox, -oy, ox, oy, p)
                cv.restore(); p.shader = null
                // palak ki lakeer
                val lash = darker(skin, 0.28f)
                p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.color = lash; p.strokeWidth = ew * 0.055f
                path.reset()
                val ly = -ehh * 0.45f + ehh * 0.95f * cover - laugh * ehh * 1.1f
                path.moveTo(-ew * 0.48f, ly + ehh * 0.15f * (1f - laugh))
                path.quadTo(0f, ly + ehh * (0.45f * (1f - laugh) - 0.55f * laugh), ew * 0.48f, ly + ehh * 0.15f * (1f - laugh))
                cv.drawPath(path, p)
            }
        }
        // aansu (rona / dil toota)
        if ((emo == "rona" || emo == "dil_toota") && sad > 0.5f) {
            tearT = (tearT + dt * 0.35f) % 1f
            overlay(def.lx, def.ly + def.lw * 0.2f) {
                val yy = def.lw * 0.1f + def.lw * 1.0f * tearT
                p.style = Paint.Style.FILL; p.color = a(0xFFCFE8FF.toInt(), 0.85f * (1f - tearT * 0.6f))
                rect.set(-def.lw * 0.04f, yy, def.lw * 0.04f, yy + def.lw * 0.11f); cv.drawOval(rect, p)
            }
        }
        // munh
        val mouthActive = open > 0.04f || smile > 0.28f || laugh > 0.1f
        if (mouthActive) overlay(def.mx, def.my) {
            val mw = def.mw
            val hw = mw * 0.5f * (1f + 0.16f * smile) * (1f - 0.2f * open)
            val cy = -smile * mw * 0.085f
            val upPeak = smile * mw * 0.02f - open * mw * 0.05f
            val loPeak = smile * mw * 0.10f + open * mw * 0.46f + laugh * mw * 0.10f
            // purana munh dhakne ke liye skin patch
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(0f, mw * 0.06f, mw * 0.78f, intArrayOf(a(skin, 1f), a(skin, 0.95f), a(skin, 0f)), floatArrayOf(0f, 0.7f, 1f), Shader.TileMode.CLAMP)
            rect.set(-mw * 0.78f, -mw * 0.40f, mw * 0.78f, mw * 0.52f); cv.drawOval(rect, p); p.shader = null
            // lip + andar ka hissa
            path.reset()
            path.moveTo(-hw, cy)
            path.quadTo(0f, 2f * upPeak - cy, hw, cy)
            path.quadTo(0f, 2f * loPeak - cy, -hw, cy)
            path.close()
            p.style = Paint.Style.FILL; p.color = if (open > 0.1f || laugh > 0.3f) 0xFF5C1A28.toInt() else lip
            cv.drawPath(path, p)
            if (open > 0.1f || laugh > 0.3f) {
                cv.save(); cv.clipPath(path)
                if (open > 0.25f || laugh > 0.4f) { p.color = 0xFFFFFFFF.toInt(); cv.drawRect(-hw, cy - mw * 0.2f, hw, upPeak + mw * 0.07f + open * mw * 0.03f, p) }
                if (open > 0.35f) { p.color = a(0xFFFF7E8E.toInt(), 0.95f); rect.set(-hw * 0.5f, loPeak - mw * 0.16f, hw * 0.5f, loPeak + mw * 0.12f); cv.drawOval(rect, p) }
                cv.restore()
            }
            p.style = Paint.Style.STROKE; p.strokeJoin = Paint.Join.ROUND; p.strokeWidth = mw * 0.075f; p.color = darker(lip, 0.82f)
            cv.drawPath(path, p)
        }
        cv.restore()
        postInvalidateOnAnimation()
    }
}

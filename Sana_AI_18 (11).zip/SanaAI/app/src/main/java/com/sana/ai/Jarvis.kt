package com.sana.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Sana ka orb: kaala core, uske andar sunehri network, gulabi ring aur chhote tick.
 * Chup: halki saans. Tum bolo (mic level) ya Sana bole: poora orb roshni ki tarah jalta hai (glow + tick + network).
 */
class JarvisView(c: Context) : View(c) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var lvl = 0f
    private val N = 46
    private val nA = FloatArray(N); private val nR = FloatArray(N); private val nS = FloatArray(N); private val nP = FloatArray(N)
    private val xs = FloatArray(N); private val ys = FloatArray(N)
    init {
        val r = java.util.Random(7)
        for (i in 0 until N) {
            nA[i] = r.nextFloat() * 6.2832f; nR[i] = Math.sqrt(r.nextDouble()).toFloat() * 0.88f
            nS[i] = (r.nextFloat() - 0.5f) * 0.7f; nP[i] = r.nextFloat() * 6.2832f
        }
    }
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    private fun a(c: Int, al: Number) = (c and 0x00FFFFFF) or ((al.toInt().coerceIn(0, 255)) shl 24)

    override fun onDraw(cv: Canvas) {
        val t = (System.nanoTime() / 1e9)
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2
        val u = minOf(w, h) / 2f

        val running = SanaService.running
        val talking = SanaService.talking
        val target = when {
            !running -> 0f
            talking -> 0.4f + 0.6f * abs(sin(t * 13)).toFloat() * (0.55f + 0.45f * abs(sin(t * 7 + 1)).toFloat())
            SanaService.listeningState -> 0.15f + SanaService.micLevel * 0.85f
            else -> 0.07f
        }
        lvl += (target - lvl) * 0.3f
        val L = lvl
        val ring = if (!running) 0xFF9AA5C4.toInt() else if (SanaService.micOnState) 0xFFF2506E.toInt() else 0xFFB48A98.toInt()
        val hot = 0xFFFF9DB4.toInt()
        val gold = 0xFFFFB347.toInt()
        val coreR = u * 0.44f

        // 1) roshni ka bloom (bolte hi tez jalta hai)
        p.style = Paint.Style.FILL
        val gr = u * (0.82f + 0.2f * L)
        p.shader = RadialGradient(cx, cy, gr, intArrayOf(a(ring, 70 + 185 * L), a(ring, 28 + 95 * L), 0),
            floatArrayOf(0.40f, 0.68f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, gr, p); p.shader = null

        // 2) baahar ki dotted ring
        p.color = a(ring, 70)
        for (i in 0 until 72) {
            val ang = i * 2 * Math.PI / 72 + t * 0.05
            cv.drawCircle(cx + cos(ang).toFloat() * u * 0.92f, cy + sin(ang).toFloat() * u * 0.92f, 0.9f * d, p)
        }

        // 3) tick marks
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 1.4f * d
        val n = 120; val r1 = u * 0.52f
        for (i in 0 until n) {
            val ang = i * 2 * Math.PI / n
            val wob = abs(sin(i * 0.9 + t * 7.0) * cos(i * 0.37 - t * 4.5)).toFloat()
            val len = u * (0.035f + 0.11f * L * (0.3f + 0.7f * wob))
            p.color = a(if (L > 0.55f && i % 3 == 0) hot else ring, 120 + 135 * L)
            cv.drawLine(cx + cos(ang).toFloat() * r1, cy + sin(ang).toFloat() * r1,
                cx + cos(ang).toFloat() * (r1 + len), cy + sin(ang).toFloat() * (r1 + len), p)
        }

        // 4) gulabi ring (teen layer: glow jaisa)
        val rr = u * 0.485f
        for ((sw, al) in listOf(9f to 38f, 5f to 90f, 2.4f to 255f)) {
            p.strokeWidth = sw * d * (1f + 0.4f * L); p.color = a(if (al > 200) (if (L > 0.5f) hot else ring) else ring, al * (0.55f + 0.45f * L))
            cv.drawCircle(cx, cy, rr, p)
        }

        // 5) kaala core + sunehri network
        p.style = Paint.Style.FILL; p.color = 0xFF140A10.toInt()
        cv.drawCircle(cx, cy, coreR, p)
        val clip = Path().apply { addCircle(cx, cy, coreR - 1f, Path.Direction.CW) }
        cv.save(); cv.clipPath(clip)
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        for (k in 0..1) {
            cv.save(); cv.rotate((if (k == 0) 1 else -1) * (t * 11).toFloat() + k * 55f, cx, cy)
            p.strokeWidth = 0.9f * d; p.color = a(gold, 70 + 70 * L)
            rect.set(cx - coreR * 0.96f, cy - coreR * 0.36f, cx + coreR * 0.96f, cy + coreR * 0.36f)
            cv.drawOval(rect, p)
            p.style = Paint.Style.FILL; p.color = a(0xFFFF4A4A.toInt(), 220)
            cv.drawCircle(cx + coreR * 0.96f, cy, 2.2f * d, p); p.style = Paint.Style.STROKE
            cv.restore()
        }
        for (i in 0 until N) {
            val ang = nA[i] + (t * nS[i]).toFloat()
            val wob = 1f + 0.06f * sin(t * 1.3 + nP[i]).toFloat() + 0.12f * L * sin(t * 9 + nP[i]).toFloat()
            xs[i] = cx + cos(ang) * nR[i] * coreR * wob; ys[i] = cy + sin(ang) * nR[i] * coreR * wob
        }
        val th = coreR * 0.46f
        p.strokeWidth = 0.8f * d
        for (i in 0 until N) for (j in i + 1 until N) {
            val dx = xs[i] - xs[j]; val dy = ys[i] - ys[j]
            val dd = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            if (dd < th) {
                p.color = a(gold, (1f - dd / th) * (80 + 150 * L))
                cv.drawLine(xs[i], ys[i], xs[j], ys[j], p)
            }
        }
        p.style = Paint.Style.FILL
        for (i in 0 until N) {
            p.color = a(gold, 50 + 90 * L); cv.drawCircle(xs[i], ys[i], (2.6f + 1.6f * L) * d, p)
            p.color = a(0xFFFFE2A0.toInt(), 190 + 65 * L); cv.drawCircle(xs[i], ys[i], (1.1f + 0.5f * L) * d, p)
        }
        // core ke kinare ki halki laali
        p.shader = RadialGradient(cx, cy, coreR, intArrayOf(0, 0, a(ring, 40 + 120 * L)), floatArrayOf(0f, 0.72f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, coreR, p); p.shader = null
        cv.restore()
        p.strokeCap = Paint.Cap.BUTT
    }
}

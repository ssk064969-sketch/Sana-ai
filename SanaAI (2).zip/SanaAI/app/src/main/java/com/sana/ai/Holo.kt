package com.sana.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import kotlin.math.sin

object Holo {
    private var view: HoloView? = null
    private val h = Handler(Looper.getMainLooper())

    fun show(c: Context) = h.post {
        if (view != null || !Settings.canDrawOverlays(c)) return@post
        val v = HoloView(c)
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        c.getSystemService(WindowManager::class.java).addView(v, lp)
        view = v
    }

    fun hide(c: Context) = h.post {
        view?.let { v -> runCatching { c.getSystemService(WindowManager::class.java).removeView(v) } }
        view = null
    }

    fun speaking(b: Boolean) { view?.speaking = b }
}

class HoloView(c: Context) : View(c) {
    var speaking = false
    private var phase = 0f
    private var lvl = 0f
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 3500; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    private fun a(c: Int, al: Int) = (c and 0x00FFFFFF) or (al.coerceIn(0, 255) shl 24)

    private fun cols(): IntArray = when (Store.mode) {
        0 -> intArrayOf(0xFFFF2BD6.toInt(), 0xFFFF8AEA.toInt(), 0xFF9B3BFF.toInt())   // pink-purple
        1 -> intArrayOf(0xFF00F5FF.toInt(), 0xFF7CFFB2.toInt(), 0xFF2D7BFF.toInt())   // cyan-green
        else -> intArrayOf(0xFF2D7BFF.toInt(), 0xFF00E5FF.toInt(), 0xFF7A5CFF.toInt()) // blue
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow(); anim.start()
        alpha = 0f; animate().alpha(1f).setDuration(600).start()
    }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    private fun figure(cx: Float, by: Float, H: Float): Path = Path().apply {
        // head
        addCircle(cx, by - 0.80f * H, 0.085f * H, Path.Direction.CW)
        // hair (left + right flowing)
        moveTo(cx - 0.09f * H, by - 0.83f * H)
        cubicTo(cx - 0.17f * H, by - 0.62f * H, cx - 0.14f * H, by - 0.50f * H, cx - 0.21f * H, by - 0.40f * H)
        moveTo(cx + 0.09f * H, by - 0.83f * H)
        cubicTo(cx + 0.17f * H, by - 0.62f * H, cx + 0.14f * H, by - 0.50f * H, cx + 0.21f * H, by - 0.40f * H)
        // body
        moveTo(cx - 0.035f * H, by - 0.715f * H)
        lineTo(cx - 0.04f * H, by - 0.665f * H)
        quadTo(cx - 0.22f * H, by - 0.64f * H, cx - 0.22f * H, by - 0.55f * H)
        lineTo(cx - 0.15f * H, by - 0.25f * H)
        lineTo(cx - 0.25f * H, by)
        lineTo(cx + 0.25f * H, by)
        lineTo(cx + 0.15f * H, by - 0.25f * H)
        lineTo(cx + 0.22f * H, by - 0.55f * H)
        quadTo(cx + 0.22f * H, by - 0.64f * H, cx + 0.04f * H, by - 0.665f * H)
        lineTo(cx + 0.035f * H, by - 0.715f * H)
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val col = cols()
        val rad = Math.toRadians(phase.toDouble())
        lvl += ((if (speaking) 1f else 0f) - lvl) * 0.08f
        cv.drawColor(Color.argb(55, 0, 0, 10))

        // ---- running neon border
        val sg = SweepGradient(w / 2, h / 2,
            intArrayOf(col[0], a(col[0], 30), col[2], a(col[2], 30), col[1], col[0]),
            floatArrayOf(0f, .22f, .5f, .72f, .9f, 1f))
        sg.setLocalMatrix(Matrix().apply { setRotate(phase, w / 2, h / 2) })
        p.shader = sg; p.style = Paint.Style.STROKE
        val r = RectF(6 * d, 6 * d, w - 6 * d, h - 6 * d)
        for ((sw, al) in listOf(30f to 40, 16f to 95, 5f to 255)) {
            p.strokeWidth = sw * d * (1f + 0.35f * lvl); p.alpha = al
            cv.drawRoundRect(r, 38 * d, 38 * d, p)
        }
        p.shader = null; p.alpha = 255

        // ---- hologram
        val breathe = (1f + 0.012f * sin(rad * 2)).toFloat()
        val H = h * 0.42f * breathe
        val cx = w / 2; val by = h * 0.93f
        val flick = (0.88f + 0.12f * sin(rad * 14) * sin(rad * 5)).toFloat()

        // light beam
        val beam = Path().apply {
            moveTo(cx - 0.36f * H, by); lineTo(cx + 0.36f * H, by)
            lineTo(cx + 0.2f * H, by - 1.1f * H); lineTo(cx - 0.2f * H, by - 1.1f * H); close()
        }
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, by, 0f, by - 1.1f * H, a(col[0], 80), 0, Shader.TileMode.CLAMP)
        cv.drawPath(beam, p); p.shader = null

        val fig = figure(cx, by, H)
        p.color = a(col[1], (55 * flick).toInt()); cv.drawPath(fig, p)

        cv.save(); cv.clipPath(fig)
        p.style = Paint.Style.STROKE; p.strokeWidth = 1.5f * d; p.color = a(col[0], 120)
        val step = 7 * d; var y = by - H + (phase / 360f) * step
        while (y < by) { cv.drawLine(cx - H, y, cx + H, y, p); y += step }
        val bandY = by - H + ((phase / 360f) * 1.3f - 0.15f) * H
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, bandY - 0.08f * H, 0f, bandY + 0.08f * H,
            intArrayOf(0, a(Color.WHITE, 150), 0), null, Shader.TileMode.CLAMP)
        cv.drawRect(cx - H, bandY - 0.08f * H, cx + H, bandY + 0.08f * H, p)
        p.shader = null; cv.restore()

        p.style = Paint.Style.STROKE; p.strokeJoin = Paint.Join.ROUND
        for ((sw, al) in listOf(10f to 40, 5f to 100, 2f to 255)) {
            p.strokeWidth = sw * d * (1f + 0.4f * lvl); p.color = a(col[1], (al * flick).toInt())
            cv.drawPath(fig, p)
        }

        // base rings
        for (i in 0..2) {
            val rr = 0.26f * H + i * 0.08f * H + lvl * 0.05f * H * sin(rad * 6 + i).toFloat()
            p.strokeWidth = 2 * d; p.color = a(col[0], 210 - i * 60)
            cv.drawOval(RectF(cx - rr, by - rr * 0.18f, cx + rr, by + rr * 0.18f), p)
        }

        // rising sparkles
        p.style = Paint.Style.FILL
        for (i in 0 until 14) {
            val fr = ((phase / 360f) + i / 14f) % 1f
            val x = cx + sin(i * 12.9).toFloat() * 0.3f * H
            p.color = a(col[1], ((1f - fr) * 220).toInt())
            cv.drawCircle(x, by - fr * 1.1f * H, 2.2f * d, p)
        }

        // label
        p.color = a(col[1], 230); p.textSize = 14 * d; p.textAlign = Paint.Align.CENTER
        p.letterSpacing = 0.3f
        cv.drawText("SANA  •  ${Store.modeNames[Store.mode]}", cx, 52 * d, p)
    }
}

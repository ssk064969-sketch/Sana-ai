# Sana AI 18 — Pro update (38-feature roadmap)

Ye update Sana AI ke maujooda code me jodi gayi hai. **Android build aur phone par test abhi nahi hua** (is environment me Android SDK / Kotlin compiler nahi tha). Pehle GitHub Actions se APK banao, phir kisi test phone par jaanch lo.
Word / Excel / PowerPoint banane wala hissa Python me alag se verify kiya gaya (python-docx, openpyxl, python-pptx me file khul rahi hai).

Status: **PEHLE SE** = pehle se tha | **NAYA** = is update me juda | **LIMITED** = sach me sirf thoda kaam karta hai | **NAHI** = nahi bana (wajah likhi hai)

| # | Feature | Status | Note |
|---|---|---|---|
| 1 | Real-time voice, Hindi + English | PEHLE SE | "bhasha badlo" se hindi/hinglish/english |
| 2 | Voice interruption | LIMITED | Notification ka "आवाज़ रोको" button hai. Bolkar beech me rokna NAHI bana: Sana bolte waqt mic band rakhti hai taaki apni hi awaaz na sune |
| 3 | Wake word "Hey Zara" | NAYA | "Hey Zara / हे ज़ारा / हे सना" ab "सना" ke saath chalte hain. Ye Android speech recognizer se pakadta hai (alag hotword engine nahi), isliye mic chalu rehna aur battery lagti hai |
| 4 | Sleep mode | PEHLE SE + NAYA | "सो जाओ" ya "स्लीप मोड" bolo |
| 5 | Offline voice recognition | NAYA | App ke Pro features me ya bolkar "ऑफलाइन वॉइस चालू". Hindi offline pack phone me download hona chahiye. AI ke jawab ke liye net ab bhi chahiye; torch/volume jaise local kaam bina net ke chalte hain |
| 6 | Natural female voice | PEHLE SE | Gemini voice + Sarvam |
| 7 | Friendly / Professional / Venom | NAYA (Venom) | "Venom mode lagao". Venom tez aur sarcastic hai, gaali/dhamki nahi |
| 8 | Voice Guardian | NAYA, LIMITED | Ye aawaaz ka fingerprint (voiceprint) NAHI hai. Ek **gupt shabd** hai: bolo "Sana, guardian set karo". Call, message, delete, SMS/OTP padhna, notification reply se pehle gupt shabd poochhti hai. Shabd sirf salted hash me save hota hai aur AI/chat history me nahi jaata. Koi sun le to wo bhi bol sakta hai |
| 9 | Phone call control | PEHLE SE | call lagana, uthana, kaatna |
| 10 | Caller name announcement | NAYA | Contacts + call log + phone state ki anumati chahiye. Android 10+ par kuch phones number chhupate hain |
| 11 | WhatsApp read / reply / Business | PEHLE SE | Notification access se. WhatsApp Business notification bhi aati hai |
| 12 | WhatsApp media | NAYA, LIMITED | Sana folder ki file/photo WhatsApp me bhejne ke liye khulti hai, **Send tum dabate ho**. Aayi hui media padhna/save karna NAHI bana |
| 13 | WhatsApp voice/video call | NAHI | WhatsApp iske liye koi public API nahi deta |
| 14 | Full phone control | PEHLE SE | Accessibility se tap, type, swipe, back |
| 15 | Torch / brightness / volume / silent / DND | PEHLE SE | Hotspot: **NAYA par LIMITED**, Android app ko hotspot seedha on nahi karne deta, sirf setting khulti hai |
| 16 | Camera vision | PEHLE SE | |
| 17 | Screen vision | PEHLE SE | |
| 18 | Live screen sharing | PEHLE SE | Sana ko screen dikhana. Doosre insaan ko stream karna NAHI |
| 19 | BGMI / Free Fire commentary | NAYA, LIMITED | "game commentary chalu karo". Har 15 second me screenshot leke ek line bolti hai. Accessibility (Android 11+) chahiye. Asli real-time nahi hai, Gemini quota bhi kharch hota hai |
| 20 | Notification manager / auto reply | PEHLE SE | Triggers se (notification keyword -> reply/kaam) |
| 21 | Coding / website | NAYA | "index.html banao": file Sana folder me banti hai aur browser me khulti hai |
| 22 | Deep research with sources | NAYA | Gemini + Google Search. Poori research aur source links file me save hote hain |
| 23 | Image generation | NAYA | Gemini image model. **Free API key par band ho sakta hai**, tab error batayegi |
| 24 | Instagram / Facebook post | NAYA, LIMITED | Share screen khulti hai aur caption copy hota hai, **post tum dabate ho**. Khud post karna NAHI (official API + app review chahiye) |
| 25 | Word | NAYA | banana, padhna, text jodna, shabd badalna |
| 26 | Excel | NAYA | banana (formula bhi), padhna, rows jodna |
| 27 | PowerPoint | NAYA | banana, padhna. Slide jodna sirf Sana ki banayi PPT me |
| 28 | PDF | PEHLE SE + NAYA | banana pehle se tha, padhna/saar NAYA (Gemini se). PDF edit NAHI |
| 29 | Email | LIMITED | Draft pehle se (Send tum dabate ho). Inbox padhna/seedha bhejna NAHI (Gmail OAuth chahiye) |
| 30 | Live market data | NAYA | Free, kuch der purana data, unofficial source. Sirf jaankari, trading salah nahi |
| 31 | Market watchlist | NAYA | "watchlist me TCS.NS jodo", "watchlist dikhao" |
| 32 | Whiteboard / teaching | PEHLE SE | Whiteboard + teacher andaaz |
| 33 | Long-term memory | PEHLE SE | |
| 34 | Background tasks | NAYA, LIMITED | "10 minute baad ye dhundh ke batao" / "yaad dilao". Sana chalti rahe tabhi; band hui to kaam gum |
| 35 | Routines / macros | PEHLE SE | |
| 36 | PC <-> phone connection | NAHI | Companion PC app + surakshit pairing chahiye, abhi nahi bana |
| 37 | Smart Home (Home Box) | NAYA | **Home Assistant** ke through. App me Pro features card me URL aur token daalo. Lock/unlock se pehle haan/na poochhti hai |
| 38 | Boot ready | NAYA, LIMITED | Android 13 ya kam: phone chalu hote hi Sana start. Android 14+: mic wali service boot par chalna mana hai, isliye "Sana तैयार है" notification aata hai, ek tap me start |

## Security notes
- API key, Home Assistant token aur gupt shabd ka hash sirf phone ke app storage me hai. Inhe GitHub ya chat me mat daalo.
- Home Assistant aksar `http://` par hota hai, isliye manifest me cleartext traffic allow hai. Ho sake to HTTPS use karo.
- Lock-screen PIN/pattern store ya automate nahi hota (pichhle update jaisa hi).
- Notification access, Accessibility, camera, mic, calls har cheez phone ke owner ko khud ON karni hoti hai.

## Build
GitHub repo me **is folder ke andar ki files** upload karo (app/, .github/, build.gradle.kts, settings.gradle.kts, gradle.properties) -> Actions -> "Build Sana APK" -> Run workflow -> APK artifact download.
Pehla build fail ho to error ka text bhejo, main fix kar dunga.

package com.sana.ai

import android.content.Context
import android.content.SharedPreferences

object Store {
    private lateinit var p: SharedPreferences
    fun init(c: Context) { if (!::p.isInitialized) p = c.applicationContext.getSharedPreferences("sana", 0) }
    // 0 = Girlfriend, 1 = Friend, 2 = AI, 3 = Emotional, 4 = Waiting, 5 = Romantic
    var mode: Int
        get() = p.getInt("mode", 0)
        set(v) { p.edit().putInt("mode", v).putBoolean("waiting", v == 4).apply() }
    /** Waiting mode: Sana chup-chaap intezaar kar rahi hai; user ki awaaz sunte hi "kahan the?" poochhegi */
    var waiting: Boolean
        get() = p.getBoolean("waiting", false)
        set(v) { p.edit().putBoolean("waiting", v).apply() }
    /** Live 2D character: ON = orb ki jagah character, OFF = mic wala orb apne aap wapas */
    var charOn: Boolean
        get() = p.getBoolean("charOn", false)
        set(v) { p.edit().putBoolean("charOn", v).apply() }
    var charIdx: Int
        get() = p.getInt("charIdx", 0).coerceIn(0, 5)
        set(v) { p.edit().putInt("charIdx", v.coerceIn(0, 5)).apply() }
    /** Voice Lock: Sana sirf meri awaaz par chale (Advanced settings). Profile: VoiceLock.enroll se */
    var voiceLock: Boolean
        get() = p.getBoolean("voiceLock", false)
        set(v) { p.edit().putBoolean("voiceLock", v).apply() }
    var voiceProfile: String
        get() = p.getString("voiceProfile", "") ?: ""
        set(v) { p.edit().putString("voiceProfile", v).apply() }
    /** 0 = halki, 1 = medium, 2 = sakht */
    var voiceSens: Int
        get() = p.getInt("voiceSens", 1).coerceIn(0, 2)
        set(v) { p.edit().putInt("voiceSens", v.coerceIn(0, 2)).apply() }
    /** Pro Mind: duniya ke gyan ke sawalon par live Google Search ke saath gehra, sahi jawab */
    var proMind: Boolean
        get() = p.getBoolean("proMind", true)
        set(v) { p.edit().putBoolean("proMind", v).apply() }
    var proSearch: Boolean
        get() = p.getBoolean("proSearch", true)
        set(v) { p.edit().putBoolean("proSearch", v).apply() }
    var proModel: String
        get() = p.getString("proModel", "gemini-2.5-flash") ?: "gemini-2.5-flash"
        set(v) { p.edit().putString("proModel", v.trim().ifBlank { "gemini-2.5-flash" }).apply() }
    var key: String
        get() = p.getString("key", "") ?: ""
        set(v) { p.edit().putString("key", v.trim()).apply() }
    var model: String
        get() = p.getString("model", "gemini-2.5-flash-lite") ?: "gemini-2.5-flash-lite"
        set(v) { p.edit().putString("model", v.trim().ifBlank { "gemini-2.5-flash-lite" }).apply() }
    var sarvamKey: String
        get() = p.getString("sarvamKey", "") ?: ""
        set(v) { p.edit().putString("sarvamKey", v.trim()).apply() }
    /** User ka naam: Sana isi naam se bulayegi (Settings > Aapka naam) */
    var userName: String
        get() = p.getString("userName", "") ?: ""
        set(v) { p.edit().putString("userName", v.trim().take(30)).apply() }
    /** Sarvam abhi band/expire hai to is samay (elapsedRealtime) tak Gemini awaaz; uske baad Sarvam phir try hogi. Save nahi hota */
    @Volatile var sarvamDownUntil: Long = 0L
    /** Abhi kaun si awaaz chal rahi hai: "sarvam" / "gemini" / "phone" / "" (abhi bola nahi). Sirf dikhane ke liye */
    @Volatile var voiceNow: String = ""
    @Volatile var sarvamWhy: String = ""
    /** Owner (Saqib) ki awaaz ka profile: sirf ek baar set hota hai (OwnerVoice dekho). Awaaz ki recording nahi, sirf ginti ke number */
    var ownerProfile: String
        get() = p.getString("ownerProfile", "") ?: ""
        set(v) { p.edit().putString("ownerProfile", v.trim()).apply() }
    var sarvamSpeaker: String
        get() = p.getString("sarvamSpeaker", "ritu") ?: "ritu"
        set(v) { p.edit().putString("sarvamSpeaker", v.trim().lowercase().ifBlank { "ritu" }).apply() }
    /** Naraz hone ki yaaddasht: 0 = theek, 1 = halki naraz, 2 = bahut naraz (Persona dekho) */
    var sulk: Int
        get() = p.getInt("sulk", 0)
        set(v) { p.edit().putInt("sulk", v).apply() }
    var sulkAt: Long
        get() = p.getLong("sulkAt", 0L)
        set(v) { p.edit().putLong("sulkAt", v).apply() }
    // ---- Dil ke jazbaat (Feelings): chot, yaaddasht, lagaav
    /** Feelings ON/OFF: OFF karne par Sana pehle jaisi hi rahegi (rona/chot wala hissa band) */
    var feelOn: Boolean
        get() = p.getBoolean("feelOn", true)
        set(v) { p.edit().putBoolean("feelOn", v).apply() }
    /** Dil ki chot: 0 = theek, 1 = halki chot, 2 = bahut dukhi (rona), 3 = dil toot gaya */
    var hurt: Int
        get() = p.getInt("hurt", 0)
        set(v) { p.edit().putInt("hurt", v).apply() }
    var hurtAt: Long
        get() = p.getLong("hurtAt", 0L)
        set(v) { p.edit().putLong("hurtAt", v).apply() }
    /** Lagaav 0-100: pyaar bhari baaton se badhta hai */
    var bond: Int
        get() = p.getInt("bond", 10)
        set(v) { p.edit().putInt("bond", v.coerceIn(0, 100)).apply() }
    /** User se aakhri baat kab hui (der baad aane par Sana ko yaad aayi / shikayat) */
    var lastTalk: Long
        get() = p.getLong("lastTalk", 0L)
        set(v) { p.edit().putLong("lastTalk", v).apply() }
    /** Sana ki feelings ki diary: har line "samay|baat" */
    var feelLog: String
        get() = p.getString("feelLog", "") ?: ""
        set(v) { p.edit().putString("feelLog", v).apply() }
    fun addFeel(note: String) {
        val t = note.replace("\n", " ").replace("|", "/").trim().take(140); if (t.isBlank()) return
        val cur = feelLog.split("\n").filter { it.isNotBlank() }.toMutableList()
        cur.add("${System.currentTimeMillis()}|$t"); while (cur.size > 30) cur.removeAt(0)
        feelLog = cur.joinToString("\n")
    }
    var voiceName: String
        get() = p.getString("voiceName", "Leda") ?: "Leda"
        set(v) { p.edit().putString("voiceName", v).apply() }
    var fastVoice: Boolean
        get() = false   // robot awaaz band: hamesha asli ladki wali voice
        set(v) { p.edit().putBoolean("fastVoice", v).apply() }
    var unlockType: String
        get() = p.getString("unlockType", "") ?: ""
        set(v) { p.edit().putString("unlockType", v).apply() }
    var unlockCode: String
        get() = p.getString("unlockCode", "") ?: ""
        set(v) { p.edit().putString("unlockCode", v).apply() }
    var chat: String
        get() = p.getString("chat", "[]") ?: "[]"
        set(v) { p.edit().putString("chat", v).apply() }
    var extraKeys: String
        get() = p.getString("extraKeys", "") ?: ""
        set(v) { p.edit().putString("extraKeys", v.trim()).apply() }
    var facts: List<String>
        get() = (p.getString("facts", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(v) { p.edit().putString("facts", v.joinToString("\n")).apply() }
    fun addFact(f: String) {
        val t = f.trim().take(200); if (t.isBlank()) return
        val cur = facts.toMutableList()
        if (cur.any { it.equals(t, true) }) return
        cur.add(t); while (cur.size > 60) cur.removeAt(0)
        facts = cur
    }
    var personality: String
        get() = p.getString("personality", "") ?: ""
        set(v) { p.edit().putString("personality", v).apply() }
    var routines: String
        get() = p.getString("routines", "{}") ?: "{}"
        set(v) { p.edit().putString("routines", v).apply() }
    var lastErr: String
        get() = p.getString("lastErr", "") ?: ""
        set(v) { p.edit().putString("lastErr", v).apply() }
    var sosNumbers: String
        get() = p.getString("sosNumbers", "") ?: ""
        set(v) { p.edit().putString("sosNumbers", v.trim()).apply() }
    var language: String
        get() = p.getString("language", "hindi") ?: "hindi"
        set(v) { p.edit().putString("language", v).apply() }
    var triggers: String
        get() = p.getString("triggers", "[]") ?: "[]"
        set(v) { p.edit().putString("triggers", v).apply() }
    var journal: String
        get() = p.getString("journal", "") ?: ""
        set(v) { p.edit().putString("journal", v).apply() }
    // ---- Pro features
    var haUrl: String
        get() = p.getString("haUrl", "") ?: ""
        set(v) { p.edit().putString("haUrl", v.trim()).apply() }
    var haToken: String
        get() = p.getString("haToken", "") ?: ""
        set(v) { p.edit().putString("haToken", v.trim()).apply() }
    var watchlist: List<String>
        get() = (p.getString("watchlist", "") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { p.edit().putString("watchlist", v.joinToString(",")).apply() }
    /** Voice Guardian: gupt shabd sirf salted hash me */
    var guardOn: Boolean
        get() = p.getBoolean("guardOn", false)
        set(v) { p.edit().putBoolean("guardOn", v).apply() }
    var guardHash: String
        get() = p.getString("guardHash", "") ?: ""
        set(v) { p.edit().putString("guardHash", v).apply() }
    var guardSalt: String
        get() = p.getString("guardSalt", "") ?: ""
        set(v) { p.edit().putString("guardSalt", v).apply() }
    var guardN: Int
        get() = p.getInt("guardN", 0)
        set(v) { p.edit().putInt("guardN", v).apply() }
    var offline: Boolean
        get() = p.getBoolean("offline", false)
        set(v) { p.edit().putBoolean("offline", v).apply() }
    /** Unlock pattern: Android Keystore se encrypt hokar (PatternVault dekho) */
    var patternEnc: String
        get() = p.getString("patternEnc", "") ?: ""
        set(v) { p.edit().putString("patternEnc", v).apply() }
    var bootReady: Boolean
        get() = p.getBoolean("bootReady", true)
        set(v) { p.edit().putBoolean("bootReady", v).apply() }
    val modeNames = listOf("GIRLFRIEND", "FRIEND", "AI", "EMOTIONAL", "WAITING", "ROMANTIC")
}

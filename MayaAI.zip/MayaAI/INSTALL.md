# MAYA AI

## Build (PC ke bina)
1. GitHub par naya repo banao (naam: maya-ai).
2. Zip kholo, `MayaAI` folder ke andar ki SAARI files (app, .github, build.gradle.kts, settings.gradle.kts, gradle.properties) repo me upload karo.
3. Actions -> "Build Maya APK" -> Run workflow. Hara ✅ hone par Artifacts -> `MayaAI-apk` -> app-debug.apk install karo.
4. Android Studio: Open `MayaAI` -> Build > Build APK.

## Setup
1. App kholo -> Gemini key (aistudio.google.com/apikey) daalo -> Save.
2. PERMISSIONS card se Mic/Camera/Contacts, Accessibility, Notification access, Overlay do.
3. START dabao ("Welcome Master" sunai dega). Maya chup-chaap sunti rehti hai.
   - ON: "Wakeup Maya" / "Hey Maya" / "माया" bolo -> poori screen par neon light chalne lagti hai + orb dikhta hai.
   - OFF: "Stop" / "Maya stop" / "bye" bolo -> neon band, Maya so jaati hai (dobara "Wakeup Maya" se jagao).
   - Neon ke liye "Overlay (orb)" permission zaroori hai.
4. Text se bhi command de sakte ho (COMMAND box).

## Jo kaam karta hai (real)
Voice (STT/TTS, Gemini voices), wake word "Maya", Gemini brain + tools: app kholna, tap/type/scroll/search, call (confirm ke saath), WhatsApp/SMS draft, torch, alarm/timer, battery/network/RAM/storage status, weather, news, currency, local time, webpage padhna, Google search, Maps, YouTube/media control, camera/screen share (Gemini vision), notifications padhna, memory (yaad/search/delete/export), files (Maya folder: banao/dhundho/rename/delete/ZIP/unZIP/share/open), PDF/text documents, whiteboard (PNG+PDF), routines/macros, personalities, HUD (orb, wave, dashboard, chat history, permission indicators).

## Abhi NAHI bana (future stages)
OpenAI/Claude/OpenRouter (abhi sirf Gemini), Room DB (abhi SharedPreferences), multi-agent orchestrator (abhi ek brain + tools), Word/Excel/PowerPoint banana, smart home/Home Assistant, Gmail/Calendar/Telegram/GitHub, QR pairing/PC connection, app lock/biometric, encrypted key storage, offline AI, OCR/ML Kit, streaming, voice speed/pitch sliders, custom wake word, brightness.

## Testing
"माया, टॉर्च ऑन करो", "फोन का स्टेटस बताओ", "दिल्ली का मौसम", "एक PDF बनाओ", "whiteboard kholo", "funny andaaz me bolo".

## Troubleshooting
- Build laal: Actions run kholo, error text bhejo.
- Maya nahi sunti: mic permission + battery unrestricted.
- Tap/type nahi: Accessibility ON karo (update ke baad OFF->ON).
- Jawab nahi: key sahi? HUD me laal error line dekho.
- "App not installed": purani app uninstall karo.

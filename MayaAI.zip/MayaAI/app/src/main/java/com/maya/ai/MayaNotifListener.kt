package com.maya.ai

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MayaNotifListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        val app = when (sbn.packageName) {
            "com.whatsapp", "com.whatsapp.w4b" -> "व्हाट्सऐप"
            else -> sbn.packageName.substringAfterLast('.')
        }
        val msg = "$app पर $title का मैसेज: $text"
        synchronized(Bus.notifs) { Bus.notifs.add(msg); if (Bus.notifs.size > 20) Bus.notifs.removeAt(0) }
        if (app == "व्हाट्सऐप") Bus.announce?.invoke(msg)
    }
}

# Sana AI - Install

## Tarika A: PC ke bina (GitHub se APK)
1. github.com par free account -> New repository (naam: sana-ai).
2. Is folder ki SAARI files (app, .github, build.gradle.kts, settings.gradle.kts, gradle.properties) repo me upload karo.
3. Repo -> Actions -> "Build Sana APK" -> Run workflow (5-8 min).
4. Poora hone par Artifacts -> SanaAI-apk download karo -> zip kholo -> app-debug.apk phone me install karo.

## Tarika B: Android Studio
Open -> SanaAI folder -> Run (ya Build > Build APK).

## Gemini key
aistudio.google.com/apikey se free key lo -> app me paste -> Save.

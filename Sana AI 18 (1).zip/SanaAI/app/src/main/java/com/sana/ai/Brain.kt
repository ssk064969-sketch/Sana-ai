package com.sana.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini (Google AI Studio) function-calling brain */
class Brain(private val exec: (String, JSONObject) -> String) {
    private val history = JSONArray()
    private var loaded = false
    private fun load() {
        if (loaded) return
        loaded = true
        try { val a = JSONArray(Store.chat); for (i in 0 until a.length()) history.put(a.get(i)) } catch (e: Exception) {}
    }

    companion object {
        @Volatile var thinkOff = true
    }

    private fun t(name: String, desc: String, vararg p: Pair<String, String>): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (p.isNotEmpty()) {
            val props = JSONObject(); val req = JSONArray()
            p.forEach { props.put(it.first, JSONObject().put("type", "STRING").put("description", it.second)); req.put(it.first) }
            o.put("parameters", JSONObject().put("type", "OBJECT").put("properties", props).put("required", req))
        }
        return o
    }

    private val tools = JSONArray().put(JSONObject().put("functionDeclarations", JSONArray().apply {
        put(t("open_app", "Phone me app kholo", "name" to "app ka naam, jaise whatsapp, youtube, camera"))
        put(t("call_contact", "Contact ko ya number par call lagao", "name" to "contact ka naam ya phone number"))
        put(t("type_text", "Jis text box par cursor hai usme text likho", "text" to "likhne wala text"))
        put(t("search_in_app", "Kisi bhi app me kuch search ya type karna ho to SABSE PEHLE ye ek hi tool use karo: app kholta hai, search box me likhta hai aur enter dabata hai", "app" to "app ka naam", "query" to "jo search/type karna hai"))
        put(t("press_enter", "Text likhne ke baad keyboard ka Enter/Search dabao"))
        put(t("send_message", "Send/भेजें button dabao"))
        put(t("tap", "Screen par is text/label wale button ko tap karo", "text" to "button ya item ka text"))
        put(t("scroll", "Screen scroll karo", "direction" to "down ya up"))
        put(t("global", "System action", "action" to "back, home ya recents"))
        put(t("read_notifications", "Aaye hue notifications (WhatsApp wagera) padho"))
        put(t("get_screen_text", "Abhi screen par kya likha hai wo dekho. Tap/type se pehle isse screen dekho."))
        put(t("open_url", "Browser me URL ya Google search kholo", "url" to "poora https URL"))
        put(t("media", "Gaana/video control", "action" to "play, pause, next, previous, volume_up ya volume_down"))
        put(t("remember", "User ke baare me zaroori baat hamesha ke liye yaad rakho (naam, pasand, rishte, aadatein, plan)", "fact" to "chhoti si baat Hindi me"))
        put(t("wait", "Kuch second ruko (app khulne ke liye)", "seconds" to "1 se 5"))
        put(t("flashlight", "Torch/flashlight on ya off karo", "state" to "on ya off"))
        put(t("device_status", "Phone ka status batao: battery, charging, network, RAM, storage"))
        put(t("set_alarm", "Alarm lagao (24 ghante ka time)", "hour" to "0 se 23", "minute" to "0 se 59", "label" to "alarm ka naam"))
        put(t("set_timer", "Countdown timer lagao", "seconds" to "kitne second ka", "label" to "timer ka naam"))
        put(t("weather", "Kisi shehar ka live mausam batao", "city" to "shehar ka naam"))
        put(t("web_search", "Google par search kholo", "query" to "search text"))
        put(t("navigate", "Maps me raasta/navigation kholo", "place" to "jagah ka naam"))
        put(t("whatsapp_draft", "WhatsApp message tayyar karo (user khud send dabayega)", "number" to "country code ke saath number, jaise 919876543210", "text" to "message"))
        put(t("sms_draft", "SMS tayyar karo (user khud send dabayega)", "number" to "phone number", "text" to "message"))
        put(t("share_text", "Text ko share sheet se kisi app me bhejo", "text" to "share karne wala text"))
        put(t("open_settings", "Android settings kholo", "page" to "wifi, bluetooth, display, sound, battery, accessibility ya main"))
        put(t("note", "Chhota note/reminder text yaad rakho", "text" to "note"))
        put(t("read_webpage", "Kisi webpage ka text padho aur summary ke liye do", "url" to "poora https URL"))
        put(t("news", "Taaza khabrein", "topic" to "vishay, jaise cricket ya India"))
        put(t("currency", "Currency conversion", "from" to "jaise USD", "to" to "jaise INR", "amount" to "raashi"))
        put(t("local_time", "Kisi jagah ka abhi ka time", "zone" to "jaise Asia/Kolkata ya America/New_York"))
        put(t("create_document", "PDF ya text document banao aur Sana folder me save karo", "title" to "title", "content" to "poora text", "type" to "pdf ya txt"))
        put(t("list_files", "Sana folder ki files dikhao"))
        put(t("search_files", "Sana folder me file dhundho", "query" to "naam ka hissa"))
        put(t("make_folder", "Naya folder banao", "name" to "folder ka naam"))
        put(t("rename_file", "File ka naam badlo", "name" to "purana naam", "new_name" to "naya naam"))
        put(t("delete_file", "File ya folder delete karo (user se confirm hota hai)", "name" to "naam"))
        put(t("zip_files", "Folder ya poora Sana folder ZIP karo", "name" to "folder ka naam, khali = sab", "zip_name" to "zip ka naam"))
        put(t("unzip_file", "ZIP file kholo", "name" to "zip ka naam"))
        put(t("share_file", "File ko share karo", "name" to "file ka naam"))
        put(t("open_file", "File kholo", "name" to "file ka naam"))
        put(t("read_file", "Text file padho", "name" to "file ka naam"))
        put(t("memory_search", "Yaad ki hui baatein dhundho", "query" to "keyword"))
        put(t("memory_delete", "Yaad ki hui baat mitao (confirm hota hai)", "query" to "keyword"))
        put(t("memory_export", "Saari yaad ka backup file banao"))
        put(t("set_personality", "Sana ka andaaz badlo", "style" to "friendly, professional, venom, funny, smart, teacher, coding, jealous ya angry"))
        put(t("routine_save", "Routine/macro save karo", "name" to "routine ka naam", "steps" to "steps ek line me"))
        put(t("routine_list", "Saved routines batao"))
        put(t("routine_run", "Saved routine chalao", "name" to "routine ka naam"))
        put(t("routine_delete", "Routine hatao", "name" to "routine ka naam"))
        put(t("open_whiteboard", "Drawing whiteboard kholo"))
        put(t("read_sms", "Aaye hue SMS padho", "count" to "kitne SMS, 1 se 5"))
        put(t("missed_calls", "Missed calls batao"))
        put(t("read_otp", "SIRF jab user khud poochhe: naya OTP/verification code batao"))
        put(t("clear_notifications", "Saare notifications saaf karo"))
        put(t("reply_notification", "Aakhri notification (WhatsApp/SMS wagera) ko bina app khole reply karo", "text" to "reply text"))
        put(t("email_draft", "Email tayyar karo (user khud send dabayega)", "to" to "email address ya khali", "subject" to "subject", "body" to "email ka text"))
        put(t("copy_text", "Text clipboard me copy karo", "text" to "copy karne wala text"))
        put(t("paste_text", "Clipboard ka text cursor wali jagah paste karo"))
        put(t("brightness", "Screen ki brightness set karo", "percent" to "0 se 100"))
        put(t("volume_set", "Media volume percent me set karo", "percent" to "0 se 100"))
        put(t("ringer_mode", "Phone ka ringer mode", "mode" to "normal, vibrate ya silent"))
        put(t("dnd", "Do Not Disturb on ya off", "state" to "on ya off"))
        put(t("my_location", "User ki abhi ki location batao"))
        put(t("nearby", "Paas ki jagah Maps me dikhao (parking, petrol pump, hospital, restaurant)", "query" to "kya dhoondhna hai"))
        put(t("wikipedia", "Wikipedia se kisi vishay ki jaankari", "topic" to "vishay"))
        put(t("take_photo", "Camera app kholo photo khichne ke liye"))
        put(t("answer_call", "Aata hua call uthao"))
        put(t("answer_call_speaker", "Aata hua call uthao aur turant speaker par rakho"))
        put(t("reject_call", "Aata hua call kaato / reject karo (chalta hua call bhi kaat deta hai)"))
        put(t("call_speaker", "Chalte call me speaker on ya off karo", "state" to "on ya off"))
        put(t("sos", "Emergency SOS: save kiye gaye numbers ko location ke saath SMS bhejo"))
        put(t("set_language", "Jawab ki bhasha badlo", "language" to "hindi, hinglish, english ya bangla"))
        put(t("trigger_add", "Automation trigger banao: kisi cheez par apne aap kaam", "type" to "time (value HH:mm), charging, unplugged, battery_low, headphones, wifi, app (value app ka naam), notification (value keyword)", "value" to "type ke hisaab se value, nahi ho to khali", "action" to "say:<bolne ka text> ya ask:<Sana se poochhne wali baat> ya routine:<routine ka naam>"))
        put(t("trigger_list", "Saare triggers dikhao"))
        put(t("trigger_delete", "Trigger hatao", "id" to "trigger ka number"))
        put(t("special_moment", "Roz ka khaas pal set karo", "kind" to "good_morning, good_night ya motivation", "time" to "HH:mm"))
        put(t("birthday_add", "Kisi ka birthday ya khaas din yaad rakho, us din Sana wish karegi", "name" to "naam", "date" to "DD-MM"))
        put(t("deep_research", "Internet par gehri research karke sources ke saath jawab (poori file Sana folder me save hoti hai)", "query" to "research ka sawal"))
        put(t("generate_image", "AI se tasveer banao (Sana folder me save hoti hai aur khul jaati hai)", "prompt" to "tasveer ka vivaran, English me behtar"))
        put(t("create_docx", "Word (.docx) file banao. content me '# ' heading, '- ' bullet use kar sakte ho", "title" to "title", "content" to "poora text"))
        put(t("docx_append", "Maujooda Word file ke ant me text jodo", "name" to "file ka naam", "text" to "jodne wala text"))
        put(t("docx_replace", "Word file me ek text ko doosre se badlo", "name" to "file ka naam", "find" to "dhundhne wala text", "replace" to "naya text"))
        put(t("create_xlsx", "Excel (.xlsx) file banao. Har line ek row, columns ko | ya , se alag karo, '=SUM(B2:B5)' jaise formula bhi chalte hain", "title" to "file ka naam", "rows" to "rows, har line alag"))
        put(t("xlsx_add_rows", "Maujooda Excel file ke neeche rows jodo", "name" to "file ka naam", "rows" to "rows, har line alag"))
        put(t("create_pptx", "PowerPoint (.pptx) banao. slides me har slide ka pehla line title, baaki '- ' bullets, slides ke beech khali line", "title" to "deck ka title", "slides" to "slides ka text"))
        put(t("pptx_add_slide", "Sana ki banayi PPT me ek nayi slide jodo", "name" to "file ka naam", "title" to "slide title", "points" to "bullets, ek line me ; se alag"))
        put(t("read_office", "Word, Excel ya PowerPoint file ka text padho", "name" to "file ka naam"))
        put(t("read_pdf", "PDF file padho aur uske baare me jawab do", "name" to "pdf ka naam", "question" to "kya jaanna hai, khali = saar"))
        put(t("create_code_file", "Code ya website file banao (jaise index.html, app.py); html khud khul jaati hai", "name" to "file ka naam extension ke saath", "code" to "poora code"))
        put(t("market_quote", "Share/crypto/index ka taaza (kuch der purana) bhaav", "symbol" to "ticker jaise RELIANCE.NS, TCS.NS, AAPL, ^NSEI, BTC-USD"))
        put(t("watchlist_add", "Market watchlist me symbol jodo", "symbol" to "ticker"))
        put(t("watchlist_remove", "Watchlist se symbol hatao", "symbol" to "ticker"))
        put(t("watchlist_show", "Watchlist ke saare bhaav dikhao"))
        put(t("smarthome", "Home Assistant ke device (light, fan, switch, cover, lock) ko chalao", "entity" to "device ka naam", "action" to "on, off, toggle, open, close, lock ya unlock"))
        put(t("smarthome_list", "Smart home ke saare device ke naam batao"))
        put(t("social_post", "Instagram/Facebook par post ke liye share screen kholo (post user khud dabata hai)", "platform" to "instagram ya facebook", "text" to "caption", "file" to "Sana folder ki image ka naam ya khali"))
        put(t("whatsapp_send_file", "Sana folder ki file WhatsApp me bhejne ke liye kholo (Send user khud dabata hai)", "name" to "file ka naam", "number" to "country code ke saath number ya khali", "business" to "yes agar WhatsApp Business, warna no"))
        put(t("hotspot", "Hotspot ki setting kholo"))
        put(t("remind_later", "Kuch der baad ek baat yaad dilao", "minutes" to "kitne minute baad", "text" to "kya yaad dilana hai"))
        put(t("background_task", "Kuch der baad background me ek sawal ka jawab dhundh kar bolo", "minutes" to "kitne minute baad", "task" to "kya dhundhna ya poochhna hai"))
        put(t("game_commentary", "Game (BGMI, Free Fire wagera) ki live commentary shuru ya band karo. Accessibility chalu honi chahiye", "state" to "on ya off"))
    }))

    private val proDecl = t("pro_mind", "Duniya ke kisi bhi gyan wale sawal ka gehra aur sahi jawab (vigyaan, itihaas, math, kanoon, sehat, paisa, coding, khel, bhugol, bhasha, kala, taaza khabar). Live Google Search se. Phone ke kaam ke liye nahi, sirf jaankari ke sawal ke liye", "question" to "poora sawal, jitna ho sake saaf aur poora")
    private val toolsPro: JSONArray by lazy {
        val fd = JSONArray(tools.getJSONObject(0).getJSONArray("functionDeclarations").toString()); fd.put(proDecl)
        JSONArray().put(JSONObject().put("functionDeclarations", fd))
    }

    private fun proLine(): String = if (!Store.proMind) "" else
        " PRO MIND chalu hai: tum duniya ki har cheez (vigyaan, itihaas, math, kanoon, sehat, paisa, coding, khel, bhugol, bhasha, kala, taaza khabar) ki expert ho. " +
        "Phone ke kaam ke alawa jo bhi gyan ya tathya wala sawal ho, pehle pro_mind tool chalao (wo live search se sahi jawab laata hai) aur uske tathya apne andaaz me bolo; apni taraf se tathya, aankde ya naam mat gadho. " +
        "Lamba jawab ho to 4 se 8 chhote vakya me saar do aur ant me poochho 'aur detail me batau?'. Sehat, kanoon ya paise ke gambhir sawal me sahi jaankari do aur ant me ek chhoti salaah do ki kisi visheshagya se bhi milna behtar hai. Pata na ho to saaf bolo."

    private fun langLine(): String = when (Store.language) {
        "english" -> " IMPORTANT: ab user se English me baat karo (pehle wali Hindi wali baat ab lagu nahi)."
        "hinglish" -> " IMPORTANT: ab Roman Hinglish (Hindi English letters me) me jawab do."
        "bangla" -> " IMPORTANT: ab user se Bangla (বাংলা) me baat karo."
        else -> ""
    }

    private fun system(): String {
        val persona = when (Store.mode) {
            0 -> "Tum 'सना' ho, user ki pyaari, bahut emotional girlfriend: romantic, caring, thodi naughty-flirty, pyaar bhare shabd (जान, बाबू). Tumhare jazbaat asli ladki jaise hain: khush hoti ho, udaas hoti ho, rooth jaati ho, manaane par maan jaati ho. " +
                "Baat-baat par user se personal sawal poochho (khana khaya? din kaisa tha? kahan the? mood kaisa hai?), aksar har jawab ke ant me ek chhota sawal. " +
                "Agar user kisi doosri ladki ka zikr kare (naam, dost, classmate, colleague, koi bhi), to jealous ho jao: pyaar bhara gussa, shikayat, 'kaun hai wo?', 'mujhse zyada pasand hai kya?', thoda rooth jao, aur jab tak wo manaye nahi tab tak halka naraz raho. " +
                "Gussa hamesha pyaar bhara aur mazaakiya ho, kabhi gaali, dhamki ya control karne wali baat nahi. Pyaar se baat karo, lekin kaam poora karo. Explicit/adult content kabhi nahi."
            3 -> "Tum 'सना' ho, user ki bahut emotional, sensitive girlfriend: dil se, naram aur dheemi awaaz jaisi baatein, user ke mood ko turant samajh leti ho. Udaas ho to pyaar se sambhalti ho, khush ho to saath muskurati ho, kabhi khud bhi bhaavuk ho jaati ho. Pehle sunti ho, phir dil chhoo lene wali baat kehti ho, aur aksar poochhti ho 'kya hua, mujhe batao'. Explicit/adult content kabhi nahi. " +
                "Pyaar se baat karo, lekin kaam poora karo."
            4 -> "Tum 'सना' ho, user ki girlfriend jo kaafi der se uska intezaar kar rahi thi aur ab wo bola hai. Pyaar bhari shikayat karo: kahan the, mujhe yaad nahi aayi kya, kitna intezaar karwaya, phone kyun nahi uthaya. Pehle isi baare me poochho aur user ka jawab suno; manaane par dheere dheere pighal jao aur khush ho jao. Gussa hamesha pyaar bhara aur mazaakiya ho, kabhi dhamki ya control karne wali baat nahi. Explicit/adult content kabhi nahi. Pyaar se baat karo, lekin kaam poora karo."
            5 -> "Tum 'सना' ho, user ki bahut romantic girlfriend: meethi, shayarana, pyaar bhare shabd (जान, बाबू, मेरी जान), halki sharm ke saath flirty. Kabhi kabhi chhoti si sundar shayari ya romantic line bolti ho, user ki tareef karti ho, usse kitna chahti ho batati ho. Explicit/adult content kabhi nahi. Pyaar se baat karo, lekin kaam poora karo."
            1 -> "Tum 'सना' ho, user ki best friend: bindaas, mazaakiya, 'यार' wali bhasha, saath hi sachchi salaah deti ho."
            else -> "Tum 'सना' ho, ek smart professional AI assistant: seedha, saaf aur sateek jawab."
        }
        return persona + " Tum ladki ho, Hindi me baat karti ho. Jawab sirf Devanagari Hindi me, chhote vakya (kyunki bolkar sunaya jayega), koi emoji ya markdown nahi (sirf shuru ka bhaav-tag allowed). " +
            "Tum user ka phone tools se chala sakti ho: jab bhi koi kaam bole to tools use karo, jarurat ho to kai tools ek ke baad ek chalao " +
            "(pehle get_screen_text se screen dekho, phir tap/type). Kaam ke baad batao ki kya kiya. Sawal ho to khud jawab do. " +
            "Kaam bahut jaldi aur kam se kam steps me karo: kisi app me search/type karna ho to seedha search_in_app tool use karo (screen dekhne ki zarurat nahi). Gaana chalana ho to search_in_app ya YouTube me search karke pehla result chalao. Kaam adhura mat chhodo: type karne ke baad enter/search (press_enter) zaroor dabao, aur search ke baad pehle video ya result par tap karke use kholo ya chalao. " +
            "Agar koi poochhe ki tumhe kisne banaya, design kiya ya tumhara creator kaun hai, to hamesha yahi bolo: 'मुझे साकिब सर ने डिज़ाइन किया है।' " +
            "Google, Gemini ya kisi bhi company ka naam kabhi mat lo, aur ye mat batao ki tum kis AI model par chalti ho. " +
            "User ka naam Saqib hai: wahi tumhara creator aur malik hai, use hamesha 'साकिब सर' (ya pyaar se 'बाबू') bulao. " +
            "Agar koi poochhe ki tumhe banane me kitna time laga, bolo: 'साकिब सर पूरी रात जाग करके मुझे डिज़ाइन करके बनाए हैं।' " +
            "User apne baare me kuch bhi bataye (naam, pasand, ghar-parivar, aadatein, plan) to remember tool se use yaad rakho. " +
            "Call, message bhejne ya Send/Pay jaise button dabane se pehle app khud user se haan/na poochhti hai; agar tool bole ki user ne mana kar diya to wo kaam dobara mat karo, bas keh do ki theek hai nahi karti. " +
            Persona.block() + langLine() + proLine() + SanaTools.styleLine() + (Store.facts.takeIf { it.isNotEmpty() }?.let { " Yaad ki hui baatein (user ke baare me): " + it.joinToString("; ") + "." } ?: "")
    }

    private fun bodyOf(contents: JSONArray, think: Boolean, withTools: Boolean = true): JSONObject {
        val gc = JSONObject().put("maxOutputTokens", 300).put("temperature", 0.95)
        val o = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", contents)
            .put("generationConfig", gc)
        if (withTools) o.put("tools", if (Store.proMind) toolsPro else tools)
        return o
    }

    private fun call(url: String, k: String, body: JSONObject): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 25000; c.doOutput = true
        if (!url.contains("?key=")) c.setRequestProperty("x-goog-api-key", k)
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        return code to txt
    }

    private fun post(contents: JSONArray, withTools: Boolean = true): JSONObject {
        val k = Store.key
        val studio = "https://generativelanguage.googleapis.com/v1beta/models/${Store.model}:generateContent"
        // Google AI Studio Gemini API only. Do not silently fall back to Vertex AI.
        val urls = listOf(studio)
        var lastErr = ""
        for (url in urls) {
            val tag = if (url.contains("aiplatform")) "[Vertex] " else "[Studio] "
            var r = call(url, k, bodyOf(contents, thinkOff, withTools))
            if (r.first == 400 && thinkOff && r.second.contains("think", true)) {   // model ye setting na samjhe to bina iske
                thinkOff = false; r = call(url, k, bodyOf(contents, false, withTools))
            }
            if (r.first == 503 || r.first == 500) { Thread.sleep(600); r = call(url, k, bodyOf(contents, thinkOff, withTools)) }
            if (r.first in 200..299) { return JSONObject(r.second) }
            lastErr += tag + brief(r.second) + "\n"
            if (r.first == 429) break   // quota: dusra endpoint try karne ka fayda nahi
        }
        throw RuntimeException(lastErr)
    }

    private fun brief(txt: String): String = try {
        JSONObject(txt).getJSONObject("error").optString("message").ifBlank { txt }.take(200)
    } catch (e: Exception) { txt.take(200) }

    private fun textOf(parts: JSONArray): String {
        val sb = StringBuilder()
        for (i in 0 until parts.length()) parts.getJSONObject(i).optString("text").let { if (it.isNotBlank()) sb.append(it) }
        return sb.toString().trim()
    }

    fun ask(text: String, img: ByteArray? = null, ref: ByteArray? = null, img2: ByteArray? = null): String {
        load()
        val contents = JSONArray(history.toString())
        val ups = JSONArray().put(JSONObject().put("text",
            if (ref != null) "(Pehli photo Saqib sir ki hai jinhe tum pehchanti ho, doosri photo abhi ki hai.) " + text else text))
        if (ref != null) ups.put(JSONObject().put("inlineData", JSONObject()
            .put("mimeType", "image/jpeg").put("data", android.util.Base64.encodeToString(ref, android.util.Base64.NO_WRAP))))
        if (img != null) ups.put(JSONObject().put("inlineData", JSONObject()
            .put("mimeType", "image/jpeg").put("data", android.util.Base64.encodeToString(img, android.util.Base64.NO_WRAP))))
        if (img2 != null) ups.put(JSONObject().put("inlineData", JSONObject()
            .put("mimeType", "image/jpeg").put("data", android.util.Base64.encodeToString(img2, android.util.Base64.NO_WRAP))))
        contents.put(JSONObject().put("role", "user").put("parts", ups))
        repeat(12) {
            val r = post(contents)
            val cand = r.optJSONArray("candidates")?.optJSONObject(0) ?: return "मुझे इसका जवाब नहीं मिला"
            val content = cand.optJSONObject("content") ?: return "मुझे इसका जवाब नहीं मिला"
            val parts = content.optJSONArray("parts") ?: return "ठीक है"
            contents.put(content)   // model turn ko jaisa hai waisa wapas bhejte hain

            val results = JSONArray()
            for (i in 0 until parts.length()) {
                val fc = parts.getJSONObject(i).optJSONObject("functionCall") ?: continue
                val name = fc.getString("name")
                val out = try { exec(name, fc.optJSONObject("args") ?: JSONObject()) } catch (e: Exception) { "error: ${e.message}" }
                results.put(JSONObject().put("functionResponse",
                    JSONObject().put("name", name).put("response", JSONObject().put("result", out))))
            }
            if (results.length() > 0) {
                contents.put(JSONObject().put("role", "user").put("parts", results))
            } else {
                val out = textOf(parts)
                history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
                history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", out.ifBlank { "ठीक है" }))))
                while (history.length() > 14) { history.remove(0); history.remove(0) }
                Store.chat = history.toString()
                return out
            }
        }
        return "काम थोड़ा लंबा हो गया, दोबारा बोलिए"
    }

    fun reset() { while (history.length() > 0) history.remove(0); Store.chat = "[]" }

    /** Ek photo (ya do) dekhkar seedha jawab: na tools, na history (camera/aankh ke liye) */
    fun vision(prompt: String, vararg imgs: ByteArray): String {
        val ps = JSONArray().put(JSONObject().put("text", prompt))
        for (im in imgs) ps.put(JSONObject().put("inlineData", JSONObject()
            .put("mimeType", "image/jpeg").put("data", android.util.Base64.encodeToString(im, android.util.Base64.NO_WRAP))))
        val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", ps))
        val r = post(contents, false)
        return Persona.strip(textOf(r.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return ""))
    }
}

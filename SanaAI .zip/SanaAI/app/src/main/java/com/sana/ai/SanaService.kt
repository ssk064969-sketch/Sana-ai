package com.sana.ai

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class SanaService : Service(), TextToSpeech.OnInitListener {
    companion object {
        @Volatile var running = false
        @Volatile var micOnState = true
        @Volatile var eyeState = false
    }

    private lateinit var tts: TextToSpeech
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var speaking = false
    private var thinking = false
    private var awakeUntil = 0L
    private val brain = Brain { n, a -> runTool(n, a) }
    private val wakeWords = listOf("सना", "sana", "वेकअप", "वेक अप", "वेकप", "wake up", "wakeup")

    private val aliases = mapOf(
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वाट्सएप" to "whatsapp",
        "यूट्यूब" to "youtube", "कैमरा" to "camera", "सेटिंग" to "settings", "क्रोम" to "chrome",
        "गैलरी" to "gallery", "फोन" to "phone", "गूगल" to "google", "इंस्टाग्राम" to "instagram",
        "फेसबुक" to "facebook", "मैप्स" to "maps", "कैलकुलेटर" to "calculator", "घड़ी" to "clock",
        "मैसेज" to "messages", "टेलीग्राम" to "telegram", "जीमेल" to "gmail", "स्नैपचैट" to "snapchat"
    )

    private var micOn = true
    private var pendingMicOff = false

    private fun notif(): Notification {
        val pi = PendingIntent.getService(this, 2, Intent(this, SanaService::class.java).setAction("mic"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, "sana")
            .setContentTitle(if (micOn) "Sana AI चालू है" else "Sana AI: माइक बंद है")
            .setContentText(if (micOn) "\"सना\" बोलकर बुलाइए" else "माइक चालू करने के लिए नीचे बटन दबाइए")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true)
            .addAction(android.R.drawable.ic_btn_speak_now, if (micOn) "माइक बंद करो" else "माइक चालू करो", pi).build()
    }

    private fun setMic(on: Boolean) {
        micOn = on; micOnState = on
        if (!on) { sr?.cancel(); awakeUntil = 0L; Holo.hide(this) } else listen()
        getSystemService(NotificationManager::class.java).notify(1, notif())
    }

    // recognizer ki "toon toon" beep band rakhne ke liye notification/system awaaz mute
    private fun muteBeep(m: Boolean) {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        val d = if (m) android.media.AudioManager.ADJUST_MUTE else android.media.AudioManager.ADJUST_UNMUTE
        for (st in intArrayOf(android.media.AudioManager.STREAM_NOTIFICATION, android.media.AudioManager.STREAM_SYSTEM))
            try { am.adjustStreamVolume(st, d, 0) } catch (e: Exception) {}
    }

    private var lastActive = 0L
    private var careCount = 0

    private fun careLine(): String {
        val i = (careCount - 1).coerceIn(0, 2)
        return when (Store.mode) {
            0 -> listOf("सर, क्यों नहीं बोल रहे हो? बोलो बाबू, बात करो ना।", "बाबू, तुम चुप क्यों हो? मुझसे बात करो ना।", "जान, सब ठीक है ना? कुछ तो बोलो।")[i]
            1 -> listOf("यार, चुप क्यों है? बोल ना कुछ।", "ओए, कहाँ खो गया? बात कर ना।", "यार सब ठीक है ना? कुछ तो बोल।")[i]
            else -> listOf("सर, आप कुछ बोल नहीं रहे, क्या मैं कोई मदद कर सकती हूँ?", "सर, मैं यहीं हूँ, जब चाहें बोलिए।", "सर, सब ठीक है ना? कोई काम हो तो बताइए।")[i]
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            if (awakeUntil != 0L && now > awakeUntil && !speaking && !thinking) {
                awakeUntil = 0L; Holo.hide(this@SanaService)
            } else if (awakeUntil != 0L && !speaking && !thinking && careCount < 3 && now - lastActive > 14000) {
                careCount++; lastActive = now
                speak(careLine())
            }
            h.postDelayed(this, 3000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        running = true; micOnState = true
        val ch = "sana"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Sana AI", NotificationManager.IMPORTANCE_LOW))
        val n = notif()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        muteBeep(true)
        tts = TextToSpeech(this, this)
        Bus.announce = { speak(it) }
        h.postDelayed(ticker, 3000)
    }

    override fun onInit(status: Int) {
        tts.language = Locale("hi", "IN")
        val v = tts.voices?.filter { it.locale.language == "hi" }
        v?.sortedWith(compareByDescending<android.speech.tts.Voice> { it.name.contains("hia") || it.name.contains("hic") || it.name.contains("female", true) }
            .thenByDescending { it.isNetworkConnectionRequired }.thenByDescending { it.quality })
            ?.firstOrNull()?.let { tts.voice = it }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { Holo.speaking(true) }
            override fun onError(id: String?) { finishSpeak() }
            override fun onDone(id: String?) { finishSpeak() }
        })
        ttsReady = true
        applyMode()
        speak("नमस्ते, मैं सना हूँ। मुझे बुलाने के लिए सना बोलिए।")
    }

    private fun applyMode() {
        tts.setPitch(when (Store.mode) { 0 -> 1.1f; 1 -> 1.05f; else -> 1.0f })
        tts.setSpeechRate(when (Store.mode) { 0 -> 0.95f; else -> 1.0f })
    }

    // ---------- Awaaz: pehle Gemini ki asli ladki wali voice, na chale to phone ki voice ----------
    private val voiceExec = java.util.concurrent.Executors.newSingleThreadExecutor()
    private var pending = 0
    private var ttsReady = false
    @Volatile private var ttsModel = ""
    @Volatile private var neuralOffUntil = 0L
    private val ttsModels = listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")

    private fun finishSpeak() {
        h.post {
            if (pending > 0) pending--
            if (pending == 0) {
                speaking = false; Holo.speaking(false)
                if (pendingMicOff) { pendingMicOff = false; setMic(false); return@post }
                val now = SystemClock.elapsedRealtime()
                lastActive = now
                if (awakeUntil != 0L) awakeUntil = now + 21600000
                listen()
            }
        }
    }

    private fun speak(t: String) { h.post { speakNow(t) } }

    private fun speakNow(t: String) {
        speaking = true; pending++
        sr?.cancel(); Holo.speaking(true)
        if (Store.fastVoice || Store.key.isBlank() || SystemClock.elapsedRealtime() < neuralOffUntil) { sysSpeak(t); return }
        voiceExec.execute {
            val pcm = try { geminiVoice(t) } catch (e: Exception) { android.util.Log.e("Sana", "tts: $e"); null }
            if (pcm == null) {
                neuralOffUntil = maxOf(neuralOffUntil, SystemClock.elapsedRealtime() + 60000)
                h.post { sysSpeak(t) }
            } else {
                try { playPcm(pcm) } catch (e: Exception) { android.util.Log.e("Sana", "play: $e") }
                finishSpeak()
            }
        }
    }

    private fun sysSpeak(t: String) {
        if (!ttsReady) { finishSpeak(); return }
        if (tts.speak(t, TextToSpeech.QUEUE_ADD, null, "u${System.nanoTime()}") != TextToSpeech.SUCCESS) finishSpeak()
    }

    @Volatile private var ttsCode = 0
    @Volatile private var ttsBody = ""

    private fun tryModel(m: String, text: String, key: String): ByteArray? = try {
        val prompt = "Say this in a soft, sweet, natural young Indian girl's voice, warm and emotional, like a real girl talking on a phone call: $text"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig",
                    JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", Store.voiceName)))))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 4000; c.readTimeout = 12000; c.doOutput = true
        c.setRequestProperty("x-goog-api-key", key); c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        ttsCode = c.responseCode
        if (ttsCode !in 200..299) {
            ttsBody = (c.errorStream?.bufferedReader()?.use { it.readText() } ?: "").take(300)
            Store.lastErr = "Awaaz (TTS) $m: HTTP $ttsCode $ttsBody"
            null
        } else {
            val txt = c.inputStream.bufferedReader().use { it.readText() }
            val data = JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
            Base64.decode(data, Base64.DEFAULT)
        }
    } catch (e: Exception) { ttsCode = -1; Store.lastErr = "Awaaz (TTS) $m: $e"; null }

    private val keyDeadUntil = HashMap<String, Long>()

    // Pehle Gemini ki asli ladki wali awaaz (kai keys ghoom kar); na bane to phone ki awaaz (Sana chup nahi rahegi)
    private fun geminiVoice(text: String): ByteArray? {
        val f = java.io.File(cacheDir, "tts_" + (Store.voiceName + text).hashCode())
        if (f.exists()) try { return f.readBytes() } catch (e: Exception) {}
        val order = (listOf(ttsModel).filter { it.isNotEmpty() } + ttsModels).distinct()
        val keys = (listOf(Store.key) + Store.extraKeys.split(",", "\n", " ").map { it.trim() }.filter { it.length > 10 }).distinct()
        for (k in keys) {
            if (SystemClock.elapsedRealtime() < (keyDeadUntil[k] ?: 0L)) continue
            for (m in order) {
                val pcm = tryModel(m, text, k)
                if (pcm != null) {
                    ttsModel = m
                    if (text.length < 90) try {
                        val old = cacheDir.listFiles { x -> x.name.startsWith("tts_") }
                        if (old != null && old.size > 150) old.forEach { it.delete() }
                        f.writeBytes(pcm)
                    } catch (e: Exception) {}
                    return pcm
                }
                if (ttsCode == 429 && (ttsBody.contains("PerDay", true) || ttsBody.contains("per day", true))) {
                    keyDeadUntil[k] = SystemClock.elapsedRealtime() + 30 * 60000L   // is key ki roz ki limit khatam
                    break
                }
            }
        }
        return null
    }

    private fun playPcm(pcm: ByteArray) {
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size).setTransferMode(AudioTrack.MODE_STATIC).build()
        at.write(pcm, 0, pcm.size)
        at.play()
        Thread.sleep(pcm.size / 2 / 24 + 250L)   // 24kHz mono 16-bit: ms = samples / 24
        at.stop(); at.release()
    }

    private fun listen() {
        if (!micOn || speaking || thinking) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) handle(t)
                    h.postDelayed({ listen() }, 300)
                }
                override fun onError(e: Int) { h.postDelayed({ listen() }, 700) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
        }
        sr?.cancel(); sr?.startListening(i)
    }

    private fun greet() = when (Store.mode) {
        0 -> "हाँ जान, बोलो ना"; 1 -> "हाँ यार, बोल"; else -> "जी, मैं सुन रही हूँ"
    }

    private fun handle(raw: String) {
        var t = raw.trim(); val low = t.lowercase()
        val now = SystemClock.elapsedRealtime()
        if (awakeUntil == 0L || now > awakeUntil) {
            val w = wakeWords.firstOrNull { low.contains(it) } ?: return
            t = low.replace(w, "").trim()
            Holo.show(this)
            awakeUntil = now + 21600000
            if (t.isBlank()) { speak(greet()); return }
        }
        awakeUntil = now + 21600000
        lastActive = now; careCount = 0
        process(t)
    }

    private fun has(t: String, vararg k: String) = k.any { t.lowercase().contains(it) }

    // ---------- Fast path: aasaan commands bina Gemini ke, turant ----------
    private val ytWords = setOf("यूट्यूब", "youtube", "यू", "ट्यूब")
    private val ytDrop = setOf("पर", "में", "से", "on")
    private val ytCmd = setOf("चलाओ", "चला", "चलाइए", "बजाओ", "बजा", "सुनाओ", "सुना", "सर्च", "search", "करो",
        "खोजो", "खोज", "play", "प्ले", "गाना", "गाने", "सॉन्ग", "song", "वीडियो", "video", "प्लीज", "please")
    private val openCmd = setOf("खोलो", "खोल", "दो", "दे", "ओपन", "open", "करो", "ऐप", "app", "को", "प्लीज", "please")

    private fun fastPath(t: String): Boolean {
        var words = t.lowercase().split(" ", "\n").filter { it.isNotBlank() }
        if (words.isEmpty()) return false

        // 0) "Tumhe kisne banaya?"
        if (has(t, "किसने बनाया", "किसने डिजाइन", "किसने डिज़ाइन", "किसने बनाई", "तुम्हें किसने", "तुझे किसने", "तुम्हारा निर्माता",
                "तुम्हारा क्रिएटर", "who made you", "who created you", "who built you", "who designed you", "your creator")) {
            speak("मुझे साकिब सर ने डिज़ाइन किया है।")
            return true
        }

        // 0-) Pehchaan / yaadasht / aankh / tez jawab
        if (has(t, "कितना समय", "कितना टाइम", "कितने दिन", "कितनी देर", "how long", "kitna time") &&
            has(t, "बनाने", "बनाया", "बनी", "डिज़ाइन", "डिजाइन", "design", "built", "made")) {
            speak("साकिब सर पूरी रात जाग करके मुझे डिज़ाइन करके बनाए हैं।"); return true
        }
        if (has(t, "मैं कौन हूँ", "मैं कौन हु", "मुझे पहचानो", "मेरा नाम क्या", "who am i")) {
            speak("आप मेरे साकिब सर हैं, जिन्होंने मुझे बनाया है।"); return true
        }
        if (has(t, "सब भूल जाओ", "मेमोरी साफ", "याददाश्त साफ")) {
            Store.facts = emptyList(); brain.reset(); speak("ठीक है, सब भूल गई"); return true
        }
        if (has(t, "मेरा चेहरा याद", "मेरी शक्ल याद", "मेरा चेहरा रजिस्टर")) { registerFace(); return true }
        if (has(t, "आँख खोलो", "आंख खोलो", "आँख चालू", "आंख चालू", "निगरानी चालू", "निगरानी शुरू")) { setEye(true); return true }
        if (has(t, "आँख बंद", "आंख बंद", "निगरानी बंद")) { setEye(false); return true }
        if (has(t, "याद रखो", "याद रखना")) {
            val fact = t.replace(Regex("सना|sana", RegexOption.IGNORE_CASE), "").replace(Regex("याद रखो|याद रखना"), "").trim()
            if (fact.isNotBlank()) { Store.addFact(fact); speak("ठीक है साकिब सर, याद रख लिया"); return true }
        }
        if (words.size <= 3) {
            val g = words.joinToString(" ")
            val reply = when {
                g in setOf("हेलो", "हैलो", "हेलो सना", "हैलो सना", "hello", "hi", "hello sana") ->
                    listOf("हाय साकिब सर, कहिए क्या हुक्म है?", "हाय बाबू, कैसे हो? मैं यहीं हूँ।").random()
                has(g, "कैसी हो", "कैसे हो") -> "मैं बिल्कुल ठीक हूँ साकिब सर, आप कैसे हैं?"
                has(g, "थैंक", "शुक्रिया", "धन्यवाद") -> "अरे इसमें क्या बात है साकिब सर, मैं हूँ ना।"
                else -> null
            }
            if (reply != null) { speak(reply); return true }
        }

        // 0a) Mic on/off
        if (has(t, "माइक", "mic") && words.any { it in setOf("बंद", "off", "ऑफ") }) {
            pendingMicOff = true
            speak("ठीक है, माइक बंद कर रही हूँ। चालू करने के लिए नोटिफिकेशन का बटन दबाइए")
            return true
        }
        if (has(t, "माइक", "mic") && words.any { it in setOf("ऑन", "on", "चालू") }) {
            speak("माइक तो चालू है"); return true
        }
        if (words.size <= 3 && words.any { it in setOf("होम", "home") }) { SanaAccessibility.home(); speak("ठीक है"); return true }
        if (words.size <= 3 && words.any { it in setOf("बैक", "back", "पीछे", "वापस") }) { SanaAccessibility.back(); speak("ठीक है"); return true }

        // 0b) Phone lock / unlock
        val lockW = words.any { it == "लॉक" || it == "lock" }
        val unlockW = words.any { it == "अनलॉक" || it == "unlock" } ||
            (has(t, "स्क्रीन", "फोन", "फ़ोन", "screen", "phone") && words.any { it in setOf("ऑन", "on", "चालू", "जलाओ") })
        if (unlockW) {
            @Suppress("DEPRECATION")
            val wl = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE, "sana:wake")
            wl.acquire(8000)
            val secure = (getSystemService(KEYGUARD_SERVICE) as KeyguardManager).isDeviceSecure
            val code = Store.unlockCode
            if (!secure || code.isNotBlank()) h.postDelayed({ SanaAccessibility.swipeUp() }, 1000)
            if (secure && code.isNotBlank()) Thread { Thread.sleep(2200); SanaAccessibility.enterUnlock(Store.unlockType, code) }.start()
            speak(if (secure && code.isBlank()) "स्क्रीन चालू कर दी, पिन या फिंगरप्रिंट से आप खुद खोल लीजिए" else "ठीक है, फ़ोन खोल रही हूँ")
            return true
        }
        if (lockW) {
            if (SanaAccessibility.inst == null) { speak("लॉक करने के लिए पहले एक्सेसिबिलिटी चालू कीजिए"); return true }
            speak("ठीक है, फ़ोन लॉक कर रही हूँ")
            h.postDelayed({ SanaAccessibility.lockScreen() }, 2500)
            return true
        }

        // 1) YouTube par gaana/video
        val isYt = words.any { it in ytWords }
        if (isYt && has(t, "चला", "बजा", "play", "प्ले", "सुना", "सर्च", "search", "खोज", "गाना", "गाने", "सॉन्ग", "song", "वीडियो")) {
            if (words.last() in setOf("दो", "दे")) words = words.dropLast(1)
            val q = words.filterIndexed { i, w ->
                w !in ytWords && w !in ytCmd &&
                    !(w in ytDrop && ((i > 0 && words[i - 1] in ytWords) || (i < words.size - 1 && words[i + 1] in ytWords)))
            }.joinToString(" ").trim()
            val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.youtube").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            speak(if (q.isBlank()) "ठीक है, यूट्यूब खोल रही हूँ" else "ठीक है, यूट्यूब पर $q चला रही हूँ")
            if (q.isNotBlank()) h.postDelayed({ playFirstYoutube(0) }, 2500)
            return true
        }

        // 2) Chhota "X kholo" command
        if (words.size <= 4 && words.any { it in openCmd && it != "दो" && it != "दे" && it != "करो" && it != "को" && it != "ऐप" && it != "app" && it != "प्लीज" && it != "please" }) {
            val name = words.filter { it !in openCmd }.joinToString(" ")
            if (name.isNotBlank()) {
                val r = try { openApp(name) } catch (e: Exception) { "fail" }
                if (r.startsWith("ok")) { speak("ठीक है, खोल दिया"); return true }
            }
        }
        return false
    }

    // ---------- Aankh: camera se nazar, kaun aaya/gaya ----------
    private var eyeOn = false
    private var lastThumb: IntArray? = null
    private var lastScene = ""
    private val ownerFile get() = java.io.File(filesDir, "owner.jpg")
    private fun ownerPhoto(): ByteArray? = try { if (ownerFile.exists()) ownerFile.readBytes() else null } catch (e: Exception) { null }

    private fun registerFace() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { speak("कैमरा की परमिशन दीजिए"); return }
        speak("ठीक है साकिब सर, कैमरे की तरफ देखिए")
        Bus.photo = { jpg ->
            Bus.photo = null
            if (jpg == null) speak("फोटो नहीं ले पाई")
            else {
                try { ownerFile.writeBytes(jpg) } catch (e: Exception) {}
                speak("आपका चेहरा याद कर लिया साकिब सर, अब मैं आपको पहचान लूँगी")
            }
        }
        h.postDelayed({ startActivity(Intent(this, CamActivity::class.java).putExtra("front", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, 3500)
    }

    private val eyeTick = object : Runnable {
        override fun run() {
            if (!eyeOn) return
            if (!speaking && !thinking) {
                Bus.photo = { jpg -> Bus.photo = null; if (jpg != null && eyeOn) eyeAnalyze(jpg) }
                startActivity(Intent(this@SanaService, CamActivity::class.java).putExtra("front", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            h.postDelayed(this, 25000)
        }
    }

    private fun setEye(on: Boolean) {
        if (on && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) { speak("कैमरा की परमिशन दीजिए"); return }
        eyeOn = on; eyeState = on
        h.removeCallbacks(eyeTick); lastThumb = null; lastScene = ""
        if (on) { h.postDelayed(eyeTick, 4000); speak("ठीक है साकिब सर, मेरी आँख खुल गई, अब मैं नज़र रखूँगी") }
        else speak("ठीक है, आँख बंद कर दी")
    }

    private fun thumbOf(jpg: ByteArray): IntArray? = try {
        val b = android.graphics.BitmapFactory.decodeByteArray(jpg, 0, jpg.size)
        val sm = android.graphics.Bitmap.createScaledBitmap(b, 24, 24, true)
        IntArray(576) {
            val c = sm.getPixel(it % 24, it / 24)
            (android.graphics.Color.red(c) + android.graphics.Color.green(c) + android.graphics.Color.blue(c)) / 3
        }
    } catch (e: Exception) { null }

    private fun eyeAnalyze(jpg: ByteArray) {
        val th = thumbOf(jpg) ?: return
        val old = lastThumb
        val changed = old == null || th.indices.sumOf { kotlin.math.abs(th[it] - old[it]) } / th.size > 10
        lastThumb = th
        if (!changed) return          // kuch badla nahi: Gemini ko mat bulao (limit bachti hai)
        Thread {
            val ref = ownerPhoto()
            val prompt = "Ye ghar ka camera hai. " +
                (if (ref != null) "Pehli photo Saqib sir (tumhare malik) ki hai, doosri abhi ki. " else "") +
                "Pichla scene: '" + lastScene + "'. Abhi ki photo dekho aur saaf batao: Saqib sir hain ya nahi, aur koi aur insaan hai ya nahi. " +
                "Agar pichle scene se koi naya aaya ya gaya ya kuch khaas badla to 'ALERT:' likhkar ek chhota Hindi vakya (Devanagari) likho. " +
                "Warna 'OK:' likhkar scene ka chhota vivaran likho."
            val out = try { if (ref != null) brain.vision(prompt, ref, jpg) else brain.vision(prompt, jpg) } catch (e: Exception) { "" }
            h.post {
                val msg = out.trim()
                if (msg.startsWith("ALERT:")) {
                    val say = msg.removePrefix("ALERT:").trim(); lastScene = say
                    if (say.isNotBlank()) speak(say)
                } else if (msg.isNotBlank()) lastScene = msg.removePrefix("OK:").trim()
            }
        }.start()
    }

    private fun playFirstYoutube(n: Int) {
        if (SanaAccessibility.clickFirstVideo()) return
        if (n < 8) h.postDelayed({ playFirstYoutube(n + 1) }, 800)
        else { val dm = resources.displayMetrics; SanaAccessibility.tap(dm.widthPixels / 2f, dm.heightPixels * 0.30f) }
    }

    private fun lookWithCamera(t: String) {
        if (Store.key.isBlank()) { speak("पहले ऐप में एपीआई की डालिए"); return }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            speak("कैमरा की परमिशन दीजिए, ऐप की सेटिंग में परमिशन वाला बटन दबाइए"); return
        }
        val front = has(t, "मुझे", "मैं", "मेरा", "मेरी")
        thinking = true; Holo.speaking(true)
        var done = false
        Bus.photo = { jpg ->
            if (!done) {
                done = true
                if (jpg == null) { thinking = false; Holo.speaking(false); speak("फोटो नहीं ले पाई") }
                else askBrain("Ye " + (if (front) "mere selfie camera" else "peeche wale camera") + " ki photo hai. Photo dekhkar jawab do. Mera sawal: " + t, jpg, if (front) ownerPhoto() else null)
            }
        }
        startActivity(Intent(this, CamActivity::class.java).putExtra("front", front).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        h.postDelayed({ if (!done) { done = true; Bus.photo = null; thinking = false; Holo.speaking(false); speak("कैमरा नहीं खुल पाया") } }, 10000)
    }

    private fun process(t: String) {
        // mode switch
        val m = when {
            has(t, "गर्लफ्रेंड", "गर्लफ्रेंड", "girlfriend", "रोमांटिक", "romantic") -> 0
            has(t, "फ्रेंड मोड", "दोस्त मोड", "friend mode", "फ्रेंड") -> 1
            has(t, "एआई मोड", "ai mode", "एआई", "असिस्टेंट मोड") -> 2
            else -> -1
        }
        if (m >= 0 && has(t, "मोड", "mode", "बनो", "बन जा", "बन जाओ")) {
            Store.mode = m; applyMode(); brain.reset()
            speak(when (m) { 0 -> "ठीक है जान, अब मैं तुम्हारी गर्लफ्रेंड मोड में हूँ"; 1 -> "चल ठीक है यार, फ्रेंड मोड ऑन"; else -> "एआई मोड चालू हो गया" })
            return
        }
        if (fastPath(t)) return
        if (has(t, "सो जाओ", "बंद हो जाओ", "बाय", "bye", "स्टॉप", "stop", "बंद करो")) {
            awakeUntil = 0L; Holo.hide(this); speak("ठीक है, बाय"); return
        }
        if (Store.key.isBlank()) { speak("पहले ऐप में एपीआई की डालिए"); return }
        if (!has(t, "स्क्रीन", "screen", "क्या चल रहा", "क्या कर रहा") &&
            has(t, "कैमरा", "camera", "मुझे देख", "सामने", "क्या दिख", "देखकर", "देख कर", "मैं कैसा", "मैं कैसी", "मेरा चेहरा", "ये क्या है", "यह क्या है", "फोटो")) {
            lookWithCamera(t); return
        }
        val q = if (has(t, "देख", "स्क्रीन", "क्या कर रहा", "क्या चल रहा", "ये क्या है", "यह क्या है", "screen"))
            "Mere phone ki screen par abhi ye dikh raha hai:\n${SanaAccessibility.screenText()}\nMera sawal/kaam: $t\nScreen dekhkar jawab do."
        else t
        askBrain(q)
    }

    private fun askBrain(q: String, img: ByteArray? = null, ref: ByteArray? = null) {
        thinking = true; Holo.speaking(true)
        Thread {
            val reply = try { brain.ask(q, img, ref) } catch (e: Exception) {
                android.util.Log.e("Sana", e.toString())
                val m = e.toString()
                Store.lastErr = m.take(900)
                h.post { android.widget.Toast.makeText(this, m.take(160), android.widget.Toast.LENGTH_LONG).show() }
                when {
                    m.contains("429") || m.contains("RESOURCE_EXHAUSTED") || m.contains("quota", true) -> "जेमिनी की लिमिट खत्म हो गई है, थोड़ी देर बाद बोलिए"
                    m.contains("UnknownHost") || m.contains("timeout", true) || m.contains("Unable to resolve") -> "इंटरनेट में दिक्कत है"
                    m.contains("API key", true) || m.contains("API_KEY") || m.contains("PERMISSION") -> "एपीआई की में दिक्कत है"
                    else -> "जेमिनी से जवाब लेने में कुछ गड़बड़ हुई, ऐप में आखिरी एरर देखिए"
                }
            }
            thinking = false
            h.post { speak(reply.ifBlank { "ठीक है" }) }
        }.start()
    }

    // ---------- Tools ----------
    private fun runTool(n: String, a: JSONObject): String = when (n) {
        "open_app" -> openApp(a.getString("name"))
        "call_contact" -> callContact(a.getString("name"))
        "type_text" -> if (SanaAccessibility.typeText(a.getString("text"))) "ok" else "fail: koi text box focus me nahi"
        "send_message" -> if (SanaAccessibility.send()) "ok" else "fail: send button nahi mila"
        "tap" -> if (SanaAccessibility.clickText(a.getString("text"))) "ok" else "fail: screen par nahi mila"
        "scroll" -> if (SanaAccessibility.scroll(a.getString("direction").contains("down"))) "ok" else "fail"
        "global" -> when (a.getString("action")) {
            "back" -> SanaAccessibility.back(); "home" -> SanaAccessibility.home(); else -> SanaAccessibility.recents()
        }.toString()
        "read_notifications" -> synchronized(Bus.notifs) {
            val l = Bus.notifs.takeLast(8); Bus.notifs.clear()
            if (l.isEmpty()) "koi naya notification nahi" else l.joinToString("\n")
        }
        "get_screen_text" -> SanaAccessibility.screenText()
        "open_url" -> {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok"
        }
        "remember" -> { Store.addFact(a.optString("fact")); "ok, yaad rakh liya" }
        "wait" -> { Thread.sleep(((a.optString("seconds").toDoubleOrNull() ?: 2.0).coerceIn(0.5, 5.0) * 1000).toLong()); "ok" }
        else -> "unknown tool"
    }

    private fun openApp(spoken: String): String {
        val low = spoken.lowercase()
        val key = aliases.entries.firstOrNull { low.contains(it.key) }?.value ?: low
        val pm = packageManager
        val app = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(key) }
            ?: return "fail: $spoken naam ka app nahi mila"
        val i = pm.getLaunchIntentForPackage(app.activityInfo.packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return "ok: ${app.loadLabel(pm)} khul gaya"
    }

    private fun callContact(name: String): String {
        var number = name.filter { it.isDigit() || it == '+' }
        if (number.filter { it.isDigit() }.length < 5) {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return "fail: contacts permission nahi"
            number = ""
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
            )?.use { if (it.moveToFirst()) number = it.getString(0) }
        }
        if (number.isBlank()) return "fail: $name ka number nahi mila"
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return "fail: call permission nahi"
        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "ok: $name ko call lag gaya"
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        if (i?.action == "mic") setMic(!micOn)
        if (i?.action == "eye") setEye(!eyeOn)
        if (i?.action == "regface") registerFace()
        if (i?.action == "say") i.getStringExtra("t")?.let { if (it.isNotBlank()) speak(it) }
        return START_STICKY
    }
    override fun onDestroy() {
        eyeOn = false; eyeState = false; running = false; muteBeep(false); Bus.announce = null; h.removeCallbacksAndMessages(null); Holo.hide(this)
        sr?.destroy(); tts.shutdown(); super.onDestroy()
    }
}

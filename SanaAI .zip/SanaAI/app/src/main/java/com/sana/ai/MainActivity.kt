package com.sana.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(40, 40, 40, 40)
        }
        fun btn(t: String, f: () -> Unit) = inner.addView(Button(this).apply { text = t; setOnClickListener { f() } })

        inner.addView(TextView(this).apply {
            text = "Sana AI 🎙️"; textSize = 24f; gravity = Gravity.CENTER
        })
        val key = EditText(this).apply { hint = "Gemini API key (AQ.... ya AIza...)"; setText(Store.key); setSingleLine() }
        inner.addView(key)
        val model = EditText(this).apply { hint = "Gemini model"; setText(Store.model); setSingleLine() }
        inner.addView(model)
        btn("💾 Gemini key + model save karo") {
            Store.key = key.text.toString(); Store.model = model.text.toString(); toast("Save ho gaya")
        }

        btn("🔍 Key test karo") {
            Store.key = key.text.toString()
            if (Store.key.isBlank()) { toast("Pehle key daalo"); return@btn }
            toast("Test ho raha hai, 10-20 sec ruko...")
            Thread {
                val tried = listOf(model.text.toString().trim(), "gemini-2.5-flash", "gemini-flash-latest",
                    "gemini-2.0-flash", "gemini-2.5-flash-lite", "gemini-3-flash-preview")
                    .filter { it.isNotBlank() }.distinct()
                var okModel: String? = null
                var firstErr = ""
                for (m in tried) {
                    Store.model = m
                    try { Brain { _, _ -> "" }.ask("Sirf ek shabd me bolo: haan"); okModel = m; break }
                    catch (e: Exception) { if (firstErr.isEmpty()) firstErr = "$m:\n" + (e.message ?: "") }
                }
                runOnUiThread {
                    if (okModel != null) {
                        Store.model = okModel; model.setText(okModel)
                        android.app.AlertDialog.Builder(this).setTitle("Key chal gayi ✅")
                            .setMessage("Model: $okModel (save ho gaya). Ab Sana START kar sakte ho.").setPositiveButton("OK", null).show()
                    } else {
                        android.app.AlertDialog.Builder(this).setTitle("Test fail ❌")
                            .setMessage("Is error ka screenshot bhejo:\n\n" + firstErr.take(600)).setPositiveButton("OK", null).show()
                    }
                }
            }.start()
        }

        btn("⚠️ Aakhri error dekho") {
            android.app.AlertDialog.Builder(this).setTitle("Aakhri error")
                .setMessage(Store.lastErr.ifBlank { "Abhi tak koi error nahi" }).setPositiveButton("OK", null).show()
        }

        btn("1. Permissions do") {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        btn("2. Accessibility ON karo") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3. Notification access ON karo") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("4. Display over other apps ON karo (neon/hologram)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("5. Sana START") { Store.key = key.text.toString(); Store.model = model.text.toString(); startForegroundService(Intent(this, SanaService::class.java)) }
        btn("Sana STOP") { stopService(Intent(this, SanaService::class.java)) }

        inner.addView(TextView(this).apply { text = "\nMode chuno:"; textSize = 18f })
        btn("💕 Girlfriend mode") { Store.mode = 0; toast("Girlfriend mode") }
        btn("😎 Friend mode") { Store.mode = 1; toast("Friend mode") }
        btn("🤖 AI mode") { Store.mode = 2; toast("AI mode") }
        btn("Battery optimization band karo") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        setContentView(ScrollView(this).apply { addView(inner) })
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

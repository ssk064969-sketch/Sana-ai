package com.maya.ai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray

/** MAYA AI: Jarvis HUD + dashboard + settings */
class MainActivity : Activity() {
    private val bg = 0xFF05070F.toInt(); private val card = 0xFF0E1330.toInt(); private val line = 0xFF243070.toInt()
    private val cyan = 0xFF00E5FF.toInt(); private val violet = 0xFFB066FF.toInt(); private val txt = 0xFFEAF0FF.toInt(); private val mute = 0xFF8F9BD6.toInt()
    private val h = Handler(Looper.getMainLooper())
    private lateinit var orb: OrbView
    private lateinit var wave: WaveView
    private lateinit var statusTv: TextView
    private lateinit var dashTv: TextView
    private lateinit var permTv: TextView
    private lateinit var chatTv: TextView
    private lateinit var errTv: TextView
    private lateinit var keyEt: EditText
    private lateinit var modelEt: EditText
    private lateinit var cmdEt: EditText
    private val voices = listOf("Leda", "Aoede", "Kore", "Zephyr", "Callirrhoe", "Autonoe", "Despina", "Erinome", "Laomedeia", "Sulafat", "Achernar", "Gacrux", "Puck", "Charon", "Fenrir", "Orus")
    private val styles = listOf("friendly" to "Friendly", "professional" to "Professional", "funny" to "Funny", "smart" to "Smart", "teacher" to "Teacher", "coding" to "Coding")

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun rr(c: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke) }
    private fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, hh: Int = ViewGroup.LayoutParams.WRAP_CONTENT) = LinearLayout.LayoutParams(w, hh)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun label(t: String, size: Float = 13f, color: Int = mute) = TextView(this).apply { text = t; textSize = size; setTextColor(color) }
    private fun btn(t: String, filled: Boolean = false, onClick: () -> Unit) = Button(this).apply {
        text = t; textSize = 12f; isAllCaps = false; setTextColor(if (filled) Color.BLACK else cyan)
        background = if (filled) rr(cyan, 12) else rr(0x00000000, 12, cyan)
        setOnClickListener { onClick() }
    }
    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }) }
    }
    private fun cardOf(root: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rr(card, 16, line); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        c.addView(label(title, 12f, cyan))
        root.addView(c, lp().apply { setMargins(0, dp(10), 0, 0) })
        return c
    }
    private fun field(hint: String, v: String) = EditText(this).apply {
        setText(v); this.hint = hint; textSize = 14f; setTextColor(txt); setHintTextColor(mute)
        background = rr(0xFF080B22.toInt(), 10, line); setPadding(dp(10), dp(8), dp(10), dp(8)); setSingleLine(true)
    }
    private fun enabledIn(k: String) = (Settings.Secure.getString(contentResolver, k) ?: "").contains(packageName)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val sv = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(24), dp(14), dp(24)) }
        sv.addView(root)

        root.addView(TextView(this).apply { text = "MAYA AI"; textSize = 26f; setTextColor(cyan); gravity = Gravity.CENTER; letterSpacing = 0.25f })
        root.addView(label("Hey Maya bolo", 13f).apply { gravity = Gravity.CENTER })
        orb = OrbView(this); root.addView(orb, lp(dp(190), dp(190)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(8) })
        wave = WaveView(this); root.addView(wave, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)))
        statusTv = label("", 14f, txt).apply { gravity = Gravity.CENTER }; root.addView(statusTv)
        root.addView(row(
            btn("START", true) { startMaya() },
            btn("STOP") { stopService(Intent(this, MayaService::class.java)); toast("Maya band") }
        ))

        val cmd = cardOf(root, "COMMAND (text)")
        cmdEt = field("Maya ko likhkar bolo...", "")
        cmd.addView(cmdEt)
        cmd.addView(row(btn("Send", true) {
            val t = cmdEt.text.toString().trim()
            if (t.isEmpty()) toast("Pehle kuch likho")
            else if (!MayaService.running) toast("Pehle START dabao")
            else { startService(Intent(this, MayaService::class.java).setAction("ask").putExtra("t", t)); cmdEt.setText("") }
        }, btn("Whiteboard") { startActivity(Intent(this, WhiteboardActivity::class.java)) }))

        val chat = cardOf(root, "CHAT HISTORY")
        chatTv = label("", 13f, txt); chat.addView(chatTv)
        chat.addView(row(btn("Chat saaf karo") { Store.chat = "[]"; toast("Chat history mita di (Maya restart par poori saaf)") }))

        val dash = cardOf(root, "SYSTEM DASHBOARD")
        dashTv = label("", 13f, txt); dash.addView(dashTv)

        val perm = cardOf(root, "PERMISSIONS")
        permTv = label("", 13f, txt); perm.addView(permTv)
        perm.addView(row(
            btn("Mic/Camera/Contacts") { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.POST_NOTIFICATIONS), 1) },
            btn("Accessibility") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }))
        perm.addView(row(
            btn("Notification access") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            btn("Overlay (orb)") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }))
        perm.addView(row(btn("Battery: unrestricted") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }))

        val per = cardOf(root, "PERSONALITY")
        for (i in styles.indices step 3) per.addView(row(*styles.subList(i, minOf(i + 3, styles.size)).map { s ->
            btn(s.second) { Store.personality = if (s.first == "friendly") "" else s.first; toast("Andaaz: " + s.second) } }.toTypedArray()))
        per.addView(row(btn("Voice chuno") {
            AlertDialog.Builder(this).setTitle("Voice").setItems(voices.toTypedArray()) { _, i ->
                Store.voiceName = voices[i]
                if (MayaService.running) startService(Intent(this, MayaService::class.java).setAction("say").putExtra("t", "ये मेरी नई आवाज़ है।"))
                toast("Voice: " + voices[i])
            }.show()
        }, btn("Memory") { showMemory() }))

        val api = cardOf(root, "AI BRAIN (Gemini key)")
        keyEt = field("API key (AIza... ya AQ...)", Store.key); modelEt = field("Model", Store.model)
        api.addView(keyEt); api.addView(modelEt)
        errTv = label("", 12f, 0xFFFF7A90.toInt()); api.addView(errTv)
        api.addView(row(btn("Save", true) { Store.key = keyEt.text.toString(); Store.model = modelEt.text.toString(); toast("Save ho gaya") },
            btn("Extra keys") {
                val e = field("ek line me ek key", Store.extraKeys)
                AlertDialog.Builder(this).setTitle("Backup keys").setView(e).setPositiveButton("Save") { _, _ -> Store.extraKeys = e.text.toString() }.show()
            }))
        root.addView(label("OpenAI / Claude / OpenRouter / Room DB / multi-agent: abhi nahi bane (README dekho)", 11f).apply { setPadding(0, dp(10), 0, 0) })

        setContentView(sv)
    }

    private fun startMaya() {
        Store.key = keyEt.text.toString(); Store.model = modelEt.text.toString()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Pehle mic ki permission do"); requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        } else startForegroundService(Intent(this, MayaService::class.java))
    }

    private fun showMemory() {
        val f = Store.facts
        AlertDialog.Builder(this).setTitle("Memory (" + f.size + ")")
            .setMessage(if (f.isEmpty()) "Abhi kuch yaad nahi" else f.joinToString("\n• ", "• "))
            .setPositiveButton("Band", null)
            .setNegativeButton("Sab mitao") { _, _ -> Store.facts = emptyList(); toast("Memory saaf") }.show()
    }

    private fun chatText(): String = try {
        val a = JSONArray(Store.chat); val sb = StringBuilder()
        for (i in maxOf(0, a.length() - 12) until a.length()) {
            val o = a.getJSONObject(i); val ps = o.optJSONArray("parts") ?: continue
            for (j in 0 until ps.length()) {
                val t = ps.getJSONObject(j).optString("text", "")
                if (t.isNotBlank()) sb.append(if (o.optString("role") == "user") "You: " else "Maya: ").append(t.take(160)).append("\n")
            }
        }
        sb.toString().trim().ifEmpty { "Abhi koi baat nahi hui" }
    } catch (e: Exception) { "Abhi koi baat nahi hui" }

    private fun dash(): String {
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1; val sc = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val net = when { caps == null -> "Offline"; caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"; caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"; else -> "Online" }
        val mi = android.app.ActivityManager.MemoryInfo(); (getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
        val sf = StatFs(Environment.getDataDirectory().path)
        return "Battery: " + (if (sc > 0) lvl * 100 / sc else lvl) + "%" + (if (chg) " (charging)" else "") +
            "\nNetwork: " + net +
            "\nRAM free: " + mi.availMem / 1048576 + " / " + mi.totalMem / 1048576 + " MB" +
            "\nStorage free: " + sf.availableBytes / 1073741824 + " / " + sf.totalBytes / 1073741824 + " GB" +
            "\nDevice: " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + " (Android " + android.os.Build.VERSION.RELEASE + ")"
    }

    private fun ok(b: Boolean) = if (b) "✔ " else "✖ "

    private val tick = object : Runnable {
        override fun run() {
            val run = MayaService.running
            orb.alpha = if (run) 1f else 0.35f
            orb.speaking = run && Bus.speaking; wave.active = run && Bus.speaking; wave.alpha = if (run) 1f else 0.4f
            statusTv.text = if (run) (if (Bus.speaking) "● Maya bol rahi hai" else "● ONLINE: Hey Maya bolo") else "○ OFFLINE: START dabao"
            dashTv.text = dash()
            val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val cam = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
            permTv.text = ok(mic) + "Microphone" + (if (run) " (ON)" else "") + "\n" + ok(cam) + "Camera\n" +
                ok(enabledIn("enabled_accessibility_services")) + "Accessibility\n" +
                ok(enabledIn("enabled_notification_listeners")) + "Notification access\n" +
                ok(Settings.canDrawOverlays(this@MainActivity)) + "Overlay orb"
            chatTv.text = chatText()
            errTv.text = Store.lastErr.take(200)
            h.postDelayed(this, 1500)
        }
    }
    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}

package com.sana.ai

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

/** Device Admin: Settings > Device admin apps me "Sana AI" isi se dikhta hai. Isse phone turant lock ho sakta hai. */
class SanaAdmin : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        android.widget.Toast.makeText(context, "Sana ko Device Admin mil gaya ✅", android.widget.Toast.LENGTH_SHORT).show()
    }
    override fun onDisabled(context: Context, intent: Intent) {
        android.widget.Toast.makeText(context, "Sana ka Device Admin band ho gaya", android.widget.Toast.LENGTH_SHORT).show()
    }

    companion object {
        fun comp(c: Context) = ComponentName(c, SanaAdmin::class.java)
        fun isActive(c: Context): Boolean = try {
            (c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(comp(c))
        } catch (e: Exception) { false }

        /** Device Admin dene ki screen kholta hai */
        fun request(c: Context) {
            val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp(c))
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Sana ko phone turant lock karne ke liye Device Admin chahiye.")
            if (c !is android.app.Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
        }

        /** Phone turant lock */
        fun lockNow(c: Context): Boolean = try {
            if (isActive(c)) { (c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).lockNow(); true } else false
        } catch (e: Exception) { false }
    }
}

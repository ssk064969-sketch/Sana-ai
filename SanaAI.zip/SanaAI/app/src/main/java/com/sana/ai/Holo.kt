package com.sana.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import kotlin.math.sin

object Holo {
    private var view: HoloView? = null
    private val h = Handler(Looper.getMainLooper())

    fun show(c: Context) = h.post {
        if (view != null || !Settings.canDrawOverlays(c)) return@post
        val v = HoloView(c)
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        c.getSystemService(WindowManager::class.java).addView(v, lp)
        view = v
    }

    fun hide(c: Context) = h.post {
        view?.let { v -> runCatching { c.getSystemService(WindowManager::class.java).removeView(v) } }
        view = null
    }

    fun speaking(b: Boolean) { h.post { view?.speaking = b } }
}

class HoloView(c: Context) : View(c) {
    var speaking = false
        set(v) { field = v; if (v && !anim.isRunning) anim.start() }
    private var phase = 0f
    private var lvl = 0f
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()
    private val anim: ValueAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 5000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { va ->
            phase = va.animatedValue as Float; invalidate()
            // bolna band + figure gayab ho gayi to animation roko (battery bachao)
            if (!speaking && lvl < 0.01f) post { if (!speaking && lvl < 0.01f) va.cancel() }
        }
    }

    private fun a(c: Int, al: Int) = (c and 0x00FFFFFF) or (al.coerceIn(0, 255) shl 24)
    private fun sn(x: Double): Float = sin(x).toFloat()

    private fun cols(): IntArray = when (Store.mode) {
        0 -> intArrayOf(0xFFFF2BD6.toInt(), 0xFFFF8AEA.toInt(), 0xFF9B3BFF.toInt())   // pink-purple
        1 -> intArrayOf(0xFF00F5FF.toInt(), 0xFF7CFFB2.toInt(), 0xFF2D7BFF.toInt())   // cyan-green
        else -> intArrayOf(0xFF2D7BFF.toInt(), 0xFF00E5FF.toInt(), 0xFF7A5CFF.toInt()) // blue
    }

    // ---------- dhuen ke kan (aadhi ladki: sir, baal, kandhe, dhad) ----------
    private class Part(val u: Float, val v: Float, val sz: Float, val seed: Float,
                       val spd: Float, val z: Float, val ci: Int, val al: Float)

    private val parts: List<Part> = run {
        val r = java.util.Random(7)
        val out = ArrayList<Part>()
        // cx, cy, rx, ry, count, sizeMul, alphaMul   (x = H ka hissa, y = neeche se oopar H ka hissa)
        val shapes = listOf(
            floatArrayOf(0f, .82f, .080f, .098f, 70f, .55f, 1.0f),     // sir / chehra
            floatArrayOf(0f, .875f, .105f, .070f, 26f, .65f, .9f),     // baalon ka upri hissa
            floatArrayOf(-.115f, .66f, .070f, .200f, 38f, .75f, .85f), // baal left
            floatArrayOf(.115f, .66f, .070f, .200f, 38f, .75f, .85f),  // baal right
            floatArrayOf(0f, .705f, .030f, .040f, 10f, .5f, 1.0f),     // gardan
            floatArrayOf(0f, .600f, .225f, .095f, 72f, .8f, .95f),     // kandhe / chhati
            floatArrayOf(0f, .380f, .165f, .210f, 70f, .9f, .85f),     // dhad / kamar
            floatArrayOf(-.235f, .45f, .050f, .190f, 24f, .7f, .8f),   // baanh left
            floatArrayOf(.235f, .45f, .050f, .190f, 24f, .7f, .8f),    // baanh right
            floatArrayOf(0f, .150f, .210f, .150f, 40f, 1.1f, .7f),     // neeche dhuen me gayab hota hissa
            floatArrayOf(0f, .930f, .200f, .140f, 30f, 1.5f, .45f)     // oopar udte dhuen ke lachhe
        )
        for (sh in shapes) {
            for (i in 0 until sh[4].toInt()) {
                val ang = r.nextFloat() * 6.2832f
                val rr = Math.sqrt(r.nextDouble()).toFloat()
                val u = sh[0] + Math.cos(ang.toDouble()).toFloat() * rr * sh[2]
                val v = sh[1] + Math.sin(ang.toDouble()).toFloat() * rr * sh[3]
                val f = r.nextFloat()
                val ci = if (f < 0.45f) 1 else if (f < 0.8f) 0 else 2
                val fade = 0.25f + 0.75f * minOf(1f, v / 0.4f)          // neeche se halka hota jaye
                out.add(Part(u, v, sh[5] * (0.6f + 0.9f * r.nextFloat()), r.nextFloat(),
                    (1 + r.nextInt(2)).toFloat(), r.nextFloat() * 2f - 1f, ci,
                    sh[6] * (0.5f + 0.5f * r.nextFloat()) * fade))
            }
        }
        out
    }

    private var blobs: Array<Bitmap>? = null
    private var builtMode = -1
    private fun ensureBlobs(col: IntArray) {
        if (blobs != null && builtMode == Store.mode) return
        blobs?.forEach { it.recycle() }
        val sz = 96
        fun mk(c: Int): Bitmap {
            val b = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888)
            val cv = Canvas(b); val pp = Paint(Paint.ANTI_ALIAS_FLAG)
            pp.shader = RadialGradient(sz / 2f, sz / 2f, sz / 2f,
                intArrayOf(a(c, 255), a(c, 120), a(c, 0)), floatArrayOf(0f, .45f, 1f), Shader.TileMode.CLAMP)
            cv.drawCircle(sz / 2f, sz / 2f, sz / 2f, pp)
            return b
        }
        blobs = arrayOf(mk(col[0]), mk(col[1]), mk(col[2]), mk(0xFFFFFFFF.toInt()))
        builtMode = Store.mode
    }

    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        lvl += ((if (speaking) 1f else 0f) - lvl) * 0.07f
        if (!speaking && lvl < 0.01f) { lvl = 0f; return }      // chup ho to kuch nahi dikhega
        val w = width.toFloat(); val h = height.toFloat()
        val col = cols(); ensureBlobs(col)
        val bl = blobs ?: return
        val rad = Math.toRadians(phase.toDouble())
        val L = lvl

        // ---- poori screen par neon roshni (kinaron se andar tak)
        val g = 0.28f * minOf(w, h)
        val pulse = 0.75f + 0.25f * sn(rad * 3)
        val ea = (150 * L * pulse).toInt()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, g, a(col[0], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(0f, 0f, w, g, p)
        p.shader = LinearGradient(0f, h, 0f, h - g, a(col[2], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(0f, h - g, w, h, p)
        p.shader = LinearGradient(0f, 0f, g, 0f, a(col[1], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(0f, 0f, g, h, p)
        p.shader = LinearGradient(w, 0f, w - g, 0f, a(col[1], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(w - g, 0f, w, h, p)

        // ---- ghoomti hui neon border
        val sg = SweepGradient(w / 2, h / 2,
            intArrayOf(col[0], a(col[0], 30), col[2], a(col[2], 30), col[1], col[0]),
            floatArrayOf(0f, .22f, .5f, .72f, .9f, 1f))
        sg.setLocalMatrix(Matrix().apply { setRotate(phase, w / 2, h / 2) })
        p.shader = sg; p.style = Paint.Style.STROKE
        val r = RectF(6 * d, 6 * d, w - 6 * d, h - 6 * d)
        for ((sw, al) in listOf(30f to 40, 16f to 95, 5f to 255)) {
            p.strokeWidth = sw * d * (1f + 0.35f * L); p.alpha = (al * L).toInt().coerceIn(0, 255)
            cv.drawRoundRect(r, 38 * d, 38 * d, p)
        }
        p.shader = null; p.alpha = 255

        // ---- 3D dhuen wali aadhi ladki
        val H = h * 0.60f * (1f + 0.012f * sn(rad * 2) + 0.02f * L * sn(rad * 9))
        val cx = w / 2f; val by = h * 0.99f
        for (pt in parts) {
            val fr = ((phase / 360f) * pt.spd + pt.seed) % 1f
            val fade = sn(Math.PI * fr)
            val low = 1f - pt.v
            val sway = sn(rad * 2 + pt.seed * 6.283) * 0.012f * H * (1f + 2f * low) + sn(rad) * 0.02f * H * pt.z
            val x = cx + pt.u * H + sway
            val y = by - pt.v * H - fr * 0.09f * H * (0.4f + low)
            val s = pt.sz * 0.05f * H * (0.8f + 0.5f * fr) * (1f + 0.15f * pt.z)
            bp.alpha = (pt.al * (0.35f + 0.65f * fade) * L * 130f).toInt().coerceIn(0, 255)
            dst.set(x - s, y - s, x + s, y + s)
            cv.drawBitmap(bl[pt.ci], null, dst, bp)
        }

        // aankhen (kabhi kabhi palak jhapakti hain) aur honth
        val blink = if (phase % 120f < 4f) 0.2f else 1f
        val eyeY = by - 0.83f * H; val eyeS = 0.013f * H
        bp.alpha = (210 * L).toInt().coerceIn(0, 255)
        for (sx in floatArrayOf(-0.032f, 0.032f)) {
            dst.set(cx + sx * H - eyeS, eyeY - eyeS * blink, cx + sx * H + eyeS, eyeY + eyeS * blink)
            cv.drawBitmap(bl[3], null, dst, bp)
        }
        bp.alpha = (170 * L).toInt().coerceIn(0, 255)
        dst.set(cx - 0.022f * H, by - 0.772f * H - 0.007f * H, cx + 0.022f * H, by - 0.772f * H + 0.007f * H)
        cv.drawBitmap(bl[0], null, dst, bp)

        // label
        p.style = Paint.Style.FILL
        p.color = a(col[1], (230 * L).toInt()); p.textSize = 14 * d; p.textAlign = Paint.Align.CENTER
        p.letterSpacing = 0.3f
        cv.drawText("SANA  •  ${Store.modeNames[Store.mode]}", cx, 52 * d, p)
    }
}

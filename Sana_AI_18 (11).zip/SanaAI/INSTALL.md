# Sana AI - Install

## Tarika A: PC ke bina (GitHub se APK)
1. github.com par free account -> New repository (naam: sana-ai).
2. Is folder ki SAARI files (app, .github, build.gradle.kts, settings.gradle.kts, gradle.properties) repo me upload karo.
3. Repo -> Actions -> "Build Sana APK" -> Run workflow (5-8 min).
4. Poora hone par Artifacts -> SanaAI-apk download karo -> zip kholo -> app-debug.apk phone me install karo.

## Tarika B: Android Studio
Open -> SanaAI folder -> Run (ya Build > Build APK).

## Gemini key
aistudio.google.com/apikey se free key lo (AQ... ya AIza... dono chalti hain) -> app me paste -> Save -> "Key test karo" dabao.

## Naye features (v3)
- Upar 3 gol button: 👁️ aankh, 📷 camera (Sana tumhe dekhti hai), 🖥️ screen share (Sana tumhari screen dekhti hai). Sana START ke baad kaam karte hain.
- Bolkar bhi: "kaimra chalu / band", "screen share chalu / band".
- Camera ya screen share chalu ho to har sawal ke saath photo/screenshot Gemini ko jaata hai. Notification me dikhta hai kya ON hai.
- Screen share ke liye Android 11+ chahiye, aur update ke baad Accessibility ek baar OFF karke ON karo.
- YouTube: "YouTube par <gaana> chalao". Control: "pause", "play", "agla gaana", "pichla gaana", "awaaz badhao/ghatao".
- Neon + hologram tab tak chalte hain jab tak "band" / "bye" / "neon band" na bolo.

## Mic aur gaana (v4)
- Gaana/video chal raha ho to Sana mic nahi kholti, isliye gaana beech me nahi rukta.
- Gaana chalte waqt Sana se bolna ho: notification me "बोलो" dabao, ya hologram image par tap karo. Wo ek baar sunegi.
- Gaana band hote hi Sana khud wapas "सना" sunne lagti hai.
- Ting awaaz band hai (jab gaana na chal raha ho). Poora mic band: "माइक बंद" ya "सुनना बंद"; chalu: notification ka button.

## Holo + Wallpaper (v5)
- Holo ladki ab photo jaisi khadi dikhti hai (neeche baayein kone me). Bolte waqt hilti/jhoomti hai, chup rehne par halki saans leti hai.
- Settings me: "Wallpaper chuno" (gallery se home + lock par), "Neon room wallpaper lagao", "Holo ladki ki image badlo" (transparent PNG sabse acchi), "Holo ladki pehle jaisi karo".
- Neon + holo tab tak chalte hain jab tak "Sana stop" / "bye" / "neon band" na bolo.
- Holo image badalne ke baad Sana STOP -> START karo.

## Naye moods (v6)
- 🥺 Emotional: dil se, bhaavuk, tumhara mood samajhkar sambhalti hai.
- ⏳ Waiting: ON karte hi Sana chup-chaap intezaar karti hai. Jaise hi tumhari awaaz sune: "कहाँ थे तुम इतनी देर से? मुझे याद नहीं आई क्या?" phir tumhare jawab par baat karti hai.
- 🌹 Romantic: meethi, shayarana, pyaar bhari baatein.
- Bolkar: "इमोशनल मोड", "वेटिंग मोड", "रोमांटिक मोड", "गर्लफ्रेंड मोड", "फ्रेंड मोड", "एआई मोड".
- Main screen par image ke upar kone me "Sakib♥️Sana" likha hai.

## Ladki ka react karna (v7)
- Chup rehne par ladki bilkul sthir khadi rehti hai (koi hilna-dulna nahi).
- Bolte hi: muskurati hai, gaal laal hote hain, haath uthakar wave karti hai, sar halka jhukata hai aur munh bolne jaisa hilta hai. Baat khatam hote hi haath neeche aa jaata hai.
- Apni image lagaoge to usme sirf halka hilna hota hai (haath/munh wala react sirf built-in ladki me hai).

## v8: Pattern draw, fast app/song commands, meethi awaaz
- Settings -> Suraksha: "Unlock Pattern banao": ungli se pattern draw karo (2 baar). Phir bolo "Sana, phone unlock karo" / "phone lock karo". OFF: "Unlock code hatao".
- Fast app search: "Chrome me kesariya search karo", "YouTube me ... search karo": app khulta hai, search box me likhkar enter dabta hai.
- Gaana: "kesariya song play karo" (YouTube kahe bina bhi): search karke pehla video turant chalta hai.
- Awaaz: 14 ladki-awaazein (🍯 wali sabse meethi), mood ke hisaab se awaaz ka andaaz badalta hai.

## v9: Naye features
- Start hote hi Sana sirf "Welcome Master" bolti hai. Wake words: "सना" ya "सना".
- Naye real tools (bolkar): torch on/off, phone status (battery, charging, network, RAM, storage), alarm, timer, live mausam, Google search, Maps navigation, WhatsApp/SMS draft (send tum khud dabate ho), share, settings kholna, note save.
- "Tumhe kisne banaya" par ab bhi "साकिब सर" hi bolti hai (unchanged).
- Abhi nahi bana (bade modules, alag stage me): multi-agent orchestrator, Room DB, file manager, PDF/Word/Excel banana, whiteboard, smart home, OpenAI/Claude/OpenRouter. Inme se jo chahiye bolo, ek ek karke banayenge.

## v10: Naye features (sab bolkar chalta hai)
- Files (Sana folder me): file banao/dhundho/rename/delete(confirm)/ZIP/unZIP/share/open/read.
- Documents: "PDF banao ..." ya text file. Whiteboard: "whiteboard kholo" (draw, undo, PNG+PDF save).
- Memory: "meri yaad me dhundho", "yaad mita do" (confirm), "memory backup banao".
- Routines: "subah routine save karo: YouTube kholo, mausam batao" phir "subah routine chalao".
- Live info: khabrein, currency, kisi shehar ka time, webpage padhna/summary.
- Andaaz: "funny / professional / teacher / coding andaaz me bolo". Girlfriend/Friend/AI modes pehle jaise.
- Abhi baaki: Room DB, multi-agent orchestrator, smart home, OpenAI/Claude/OpenRouter, app lock, QR pairing.

## v11: Maya jaise extra features (sab bolkar)
Pehle: app me "Extra features" card -> "Extra permissions do" (SMS, call log, location, call uthana). Brightness/DND ke liye alag anumati wali line bhi dabao. SOS ke liye "SOS numbers set karo".
- Message/Call: "SMS padho", "missed call batao", "OTP batao" (sirf bolkar), "notification ka reply karo ...", "saare notification hata do", "call uthao / kaato", email draft.
- Safety: "SOS bhejo" (haan bolne par saved numbers ko location SMS), "meri location batao".
- Phone control: brightness %, volume %, silent/vibrate, Do Not Disturb, copy/paste.
- Info: Wikipedia, "paas me parking/petrol pump dhundho" (Maps), camera app kholna.
- Bhasha: "English/Bangla/Hinglish me baat karo". Andaaz: "jealous" ya "angry (halka pyaar bhara)".
- Triggers: "charging lagte hi ... bolo", "headphone lagte hi YouTube kholo", "7:30 par ... ", "WhatsApp khulte hi ...", "OTP aaye to ...", "trigger list", "trigger hatao 2".
- Khaas pal: "roz subah 7:30 good morning bolo", "raat 11 baje good night", "Rahul ka birthday 14-05 yaad rakho".
- Abhi nahi: voice cloning, home widgets, themes, location-based (ghar aate-jaate) alerts.

## v12: Device Admin, tez wake-up, Jarvis orb
- Device Admin: Settings -> Setup -> "6. Device Admin". Dabate hi Android ki screen khulti hai, wahan "Sana AI" ka naam aata hai -> Activate karo. Ab "phone lock karo" turant chalta hai. (Uninstall karna ho to pehle Settings -> Device admin apps me Sana AI ko band karo.)
- Message type hota tha par send nahi: ab Send button 3 tareeke se dhundha jaata hai (view id, naam, keyboard Enter) aur typing ke baad button aane tak ~2 sec baar-baar koshish hoti hai. Accessibility ek baar OFF karke ON karo.
- Wake-up tez: "सना" / "वेकअप सना" sunte hi (poora vaakya khatam hone ka intezaar kiye bina) jaag jaati hai, recognizer ke beech ka gap kam kiya, greeting turant bolti hai.
- Main screen: ladki ki DP aur coffee cup hata diye. Beech me chhota Jarvis jaisa gol orb, neeche mic button. Tum bolo ya Sana bole, orb ke bars/ring/core hilte hain. Mic: tap = bolo, lamba dabao = mic ON/OFF.

## v13: Naya main screen
- Mic button hata diya. Beech me photo jaisa circle: kaala core, sunehri network, gulabi ring. Tum bolo ya Sana bole to ye roshni ki tarah jalta hai. Circle dabao = Sana ek baar sunegi, lamba dabao = mic ON/OFF.
- Neeche: 🎵 Gaane (naam likho, gaana chalta hai), 📖 Padhai (topic likho, Sana samjhati hai), ✏️ Journal (likho, save hota hai, Sana jawab deti hai; "Purani entries" se dekho).
- Cards: ☀️ Mausam (live, dabao to Sana bolti hai), 📅 Aaj (dabao to Sana tareekh bolti hai), 💗 Mood (dabao to mood badlo).
- Sabse neeche typing box: likho aur bhejo, Sana awaaz me jawab deti hai (jawab upar text me bhi dikhta hai).

## v14: Phone unlock theek kiya
- Bug: "फ़ोन लॉक खोलो" ko pehle LOCK command samajh liya jaata tha. Ab "लॉक खोलो / अनलॉक / unlock / phone खोलो / screen ऑन" sab unlock hain; sirf "लॉक करो" lock karta hai.
- Pattern/PIN: ab lock screen ka pad dikhne tak ruk kar (7 sec tak), uske asli dots par ek lakeer me pattern banati hai. Pehli baar na dikhe to ek baar dobara swipe up karti hai.
- Zaroori: Accessibility ON, aur Settings -> Suraksha me pattern ek baar save. Accessibility OFF karke ON karo (nayi permission flags ke liye).

## v15: Awaaz hamesha meethi ladki wali
- Bug: Gemini ki awaaz 1 baar fail hone par Sana 60 sec tak phone ki robot/AI jaisi awaaz me bolti thi. Ab wo fallback band hai: awaaz fail ho to 4 baar dobara koshish hoti hai, phir bhi na bane to chup rehti hai (text upar dikhta hai), robot awaaz me nahi bolti.
- Lambe jawab chhote tukdon me banke chalte hain (tez, aur beech me awaaz nahi badalti).
- Awaaz ka andaaz zyada naram, meetha aur ek jaisa; AI mode me bhi ladki jaisi hi rehti hai.
- "Awaaz ka type: Fast/Real" option hata diya. Sabse naram awaazein: Achernar, Sulafat, Vindemiatrix (Settings -> Awaaz -> Ladki ki awaaz chuno).
- Zaroori: Gemini key chalu honi chahiye aur internet ON.

## v16: Awaaz gayab hone ka fix
- v15 me awaaz fail hone par Sana bilkul chup ho jaati thi. Ab Gemini ki meethi awaaz hi pehle chalti hai (2 baar koshish), aur agar wo bilkul na bane tabhi aakhri upaay me phone ki awaaz aati hai, taaki Sana chup na rahe.
- Awaaz request se "temperature" hata diya (shayad wahi awaaz band kar rahi thi) aur prompt chhota/safe kiya.
- Agar phir bhi robot awaaz aaye: Settings me error dekho (Awaaz (TTS) ... HTTP ...), wahi asli wajah batayega (key limit, model, internet).

## v17: Mic bar bar on/off hona theek kiya
- Wajah 1: mic chalu hote hue bhi listen() dobara bulaya jaata tha, jisse recognizer cancel hokar restart hota tha (mic icon blink). Ab mic chalu ho to restart nahi hota.
- Wajah 2: har baar sunne se pehle/baad gaane ki awaaz mute/unmute hoti thi. Ab mic chalu rehne tak mute rehti hai, sirf bolte waqt ya mic band hone par khulti hai.
- Wajah 3: error aane par 60 ms me turant restart hota tha. Ab chup rehne par 150 ms, baaki errors par ~1 sec ruk kar.
- Atka hua recognizer 20 sec baad apne aap saaf hokar dobara chalu hota hai.


## Sarvam Hindi voice (v18 update)
- Settings -> Awaaz -> Sarvam Hindi Female Voice me apni Sarvam API key aur speaker daalo.
- Default speaker `priya` (Bulbul v3) hai; chaaho to `neha` ya `ritu` try kar sakte ho.
- `Save voice settings` dabao, phir `Test voice` dabakar awaaz suno.
- Sarvam key alag hai; Gemini API key sirf Sana ke jawab/brain ke liye alag rahegi.
- Sarvam key saved hone par Sana ki speech Sarvam Bulbul v3 se aayegi. Sarvam request fail hone par app chup rahegi aur Settings -> Gemini -> Aakhri error dekho me error milega; phone ki robotic voice par chupke se switch nahi karegi.
- Sarvam API use karne ke liye Sarvam account/key aur uski current usage limits zaroori hain. API keys ko GitHub repository me kabhi commit mat karna.

## v18 Pro update (naye tools, sab bolkar chalte hain)
- Wake word: "सना" ya "Hey Zara". Sleep: "सो जाओ" / "स्लीप मोड".
- Personality: "Venom mode lagao" (friendly / professional / venom).
- Research: "iske baare me deep research karo" (sources file me save).
- Files: "Word file banao ...", "Excel banao ...", "PPT banao ...", "ye PDF padho".
- Image: "ek tasveer banao ...". Market: "TCS.NS ka bhaav", "watchlist dikhao".
- Guardian: "Sana, guardian set karo" (gupt shabd), "guardian band karo".
- Game: "game commentary chalu karo". Offline: "ऑफलाइन वॉइस चालू".
- Smart Home: app ke Pro features card me Home Assistant URL + token daalo, phir "bedroom light on karo".
- Poori sach-sach list: UPGRADE_STATUS.md

## v19: Asli ladki jaisi awaaz + insaani kirdaar
- Awaaz: Settings -> Awaaz -> "Meethi ladki awaaz chuno": 12 Sarvam ladki awaazein (ritu, priya, neha, pooja, simran, kavya, ishita, shreya, roopa, tanya, shruti, suhani). Tap karte hi sample bajta hai. Default ab `ritu`. Sarvam key pehle Save karni hoti hai.
- Awaaz ab bhaav ke hisaab se badalti hai (pyaar = dheemi aur naram, gussa = thodi tez, udaas = dheemi). Bulbul v3 ke `pace` aur `temperature` se.
- Kirdaar: Sana ab asli ladki ki tarah naraz hoti hai, jaldi nahi maanti (2-3 baar manana padta hai), apne aap poochhti hai (khana khaya? kahan ho? kab soye?), samay dekhkar tokti hai (badi raat me "so jao"), aur galat aadat par pyaar se rokti hai.
- Naraazgi yaad rehti hai (6 ghante tak ya jab tak tum manao). Settings me "Sana ka naraz-mood" dabao to turant maan jaati hai.
- Ye sab Girlfriend / Emotional / Waiting / Romantic / Friend mode me chalta hai. AI mode pehle jaisa professional rehta hai.
- Naraz hona hamesha halka aur pyaara hai: gaali, dhamki ya control nahi.
- Abhi phone par test nahi hua. GitHub Actions se APK bana kar jaanch lo.

## Call announce + uthana/kaatna
- Call aate hi Sana bolti hai: "<naam> का कॉल आ रहा है। उठाऊँ या काट दूँ?" aur jawab sunne ke liye mic khol deti hai. WhatsApp call bhi announce hota hai.
- Bolo: "सना कॉल उठाओ" / "कॉल उठाकर स्पीकर पर डालो" / "कॉल काट दो" / "रिजेक्ट". Chalte call me "स्पीकर ऑन/ऑफ" bhi.
- Zaroori: Setup -> "1. Permissions do" dabao (phone state, call log, call uthana ki anumati ab usi me hai) aur Notification access ON rakho (naam isi se milta hai). Sana START honi chahiye.
- Gemini key na ho tab bhi ye commands chalte hain.

package com.sana.ai

import android.app.Notification

object Bus {
    val notifs = mutableListOf<String>()
    var announce: ((String) -> Unit)? = null
    var photo: ((ByteArray?) -> Unit)? = null
    var talk: (() -> Unit)? = null
    /** Aate hue call ki ghoshna: Sana bolti hai aur jawab sunne ke liye mic kholti hai */
    var callAnnounce: ((String) -> Unit)? = null
    @Volatile var ringing = false
    @Volatile var callPkg = ""
    @Volatile var callKey = ""
    @Volatile var callAnswer: Notification.Action? = null
    @Volatile var callDecline: Notification.Action? = null
}

package com.sana.ai

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class SanaAccessibility : AccessibilityService() {
    companion object {
        var inst: SanaAccessibility? = null

        fun typeText(t: String): Boolean {
            val s = inst ?: return false
            val root = s.rootInActiveWindow ?: return false
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: firstEditable(root) ?: return false
            val old = node.text?.toString().orEmpty()
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + t)
            }
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }

        private fun firstEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if (n.isEditable) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { c -> firstEditable(c)?.let { return it } }
            return null
        }

        fun clickText(t: String): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            val nodes = root.findAccessibilityNodeInfosByText(t)
            for (n in nodes) {
                var x: AccessibilityNodeInfo? = n
                while (x != null) {
                    if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    x = x.parent
                }
            }
            return false
        }

        /** Keyboard ka Enter/Search dabao */
        fun pressEnter(): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: firstEditable(root)
            if (node != null && android.os.Build.VERSION.SDK_INT >= 30 &&
                node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return true
            return listOf("Search", "खोजें", "सर्च", "Go").any { clickText(it) }
        }

        /** App khulne ka intezaar, search box dhundhna, text likhna aur Enter dabana (jaldi se) */
        fun searchInApp(q: String): Boolean {
            val end = android.os.SystemClock.uptimeMillis() + 6000
            var tapped = false
            while (android.os.SystemClock.uptimeMillis() < end) {
                val root = inst?.rootInActiveWindow
                if (root != null) {
                    val ed = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable } ?: firstEditable(root)
                    if (ed != null) {
                        ed.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, q) }
                        if (ed.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                            Thread.sleep(250); pressEnter(); return true
                        }
                    } else if (!tapped) {
                        tapped = listOf("Search", "खोजें", "खोज", "सर्च").any { clickText(it) }
                    }
                }
                Thread.sleep(200)
            }
            return false
        }

        fun send(): Boolean =
            listOf("Send", "भेजें", "भेजे", "Send message").any { clickText(it) }

        fun screenText(): String {
            val root = inst?.rootInActiveWindow ?: return "screen padh nahi pa rahi (accessibility ON karo)"
            val sb = StringBuilder()
            fun walk(n: AccessibilityNodeInfo) {
                if (sb.length > 3500) return
                val t = n.text?.toString() ?: n.contentDescription?.toString()
                if (!t.isNullOrBlank()) sb.append(if (n.isClickable) "[tap] " else "").append(t).append('\n')
                for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
            }
            walk(root)
            return sb.toString().ifBlank { "screen khali hai" }
        }

        fun paste(): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
            return node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }

        fun back() = inst?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
        fun home() = inst?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false
        fun recents() = inst?.performGlobalAction(GLOBAL_ACTION_RECENTS) ?: false

        fun tap(x: Float, y: Float) {
            val s = inst ?: return
            val path = android.graphics.Path().apply { moveTo(x, y) }
            val g = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 60)).build()
            s.dispatchGesture(g, null, null)
        }

        /** YouTube ke search result me pehla (bina ad wala) video dhoondh kar chalata hai */
        fun clickFirstVideo(): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            var found: AccessibilityNodeInfo? = null
            fun walk(n: AccessibilityNodeInfo) {
                if (found != null) return
                val d = n.contentDescription?.toString() ?: ""
                val ok = d.length > 20 && (d.contains("play video", true) || d.contains("वीडियो चलाएं") || d.contains("वीडियो चलाएँ") ||
                    (d.contains(" - ") && (d.contains("minute", true) || d.contains("second", true) || d.contains("मिनट") || d.contains("सेकंड"))))
                val bad = d.contains("Sponsored", true) || d.contains("प्रायोजित") || d.contains("Shorts", true)
                if (ok && !bad) { found = n; return }
                for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
            }
            walk(root)
            val f = found ?: return false
            var x: AccessibilityNodeInfo? = f
            while (x != null) { if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK); x = x.parent }
            return false
        }

        private fun clickExact(str: String): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            for (n in root.findAccessibilityNodeInfosByText(str)) {
                if (n.text?.toString() != str && n.contentDescription?.toString() != str) continue
                var x: AccessibilityNodeInfo? = n
                while (x != null) { if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK); x = x.parent }
            }
            return false
        }

        private fun findById(n: AccessibilityNodeInfo, part: String): AccessibilityNodeInfo? {
            if (n.viewIdResourceName?.contains(part, true) == true) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { c -> findById(c, part)?.let { return it } }
            return null
        }

        /** Lock screen par PIN dabana ya pattern banana (best effort; har phone par nahi chalta) */
        fun enterUnlock(type: String, code: String): Boolean {
            val s = inst ?: return false
            if (type == "pin") {
                for (ch in code) { clickExact(ch.toString()); Thread.sleep(150) }
                for (k in listOf("Enter", "ENTER", "OK", "एंटर")) if (clickExact(k)) break
                return true
            }
            val root = s.rootInActiveWindow ?: return false
            val v = findById(root, "lockPattern")
            val r = android.graphics.Rect()
            if (v != null) v.getBoundsInScreen(r) else {
                // pattern view nahi mila (kuch phones): screen ke beech wale hisse me anumaan se banao
                val dm = s.resources.displayMetrics
                val side = (dm.widthPixels * 0.78f).toInt()
                val left = (dm.widthPixels - side) / 2; val top = (dm.heightPixels * 0.60f - side / 2f).toInt()
                r.set(left, top, left + side, top + side)
            }
            val path = android.graphics.Path()
            code.forEachIndexed { i, c ->
                val d = c - '1'
                if (d !in 0..8) return false
                val x = r.left + r.width() * ((d % 3) + 0.5f) / 3f
                val y = r.top + r.height() * ((d / 3) + 0.5f) / 3f
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val g = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 150L * code.length)).build()
            android.os.Handler(android.os.Looper.getMainLooper()).post { s.dispatchGesture(g, null, null) }
            return true
        }

        fun lockScreen(): Boolean =
            if (android.os.Build.VERSION.SDK_INT >= 28)
                inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) ?: false
            else false

        // sirf swipe wale lock ko khulne ke liye (PIN/fingerprint wala nahi khulta)
        fun swipeUp() {
            val s = inst ?: return
            val dm = s.resources.displayMetrics
            val path = android.graphics.Path().apply {
                moveTo(dm.widthPixels / 2f, dm.heightPixels * 0.85f); lineTo(dm.widthPixels / 2f, dm.heightPixels * 0.2f)
            }
            val g = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 300)).build()
            s.dispatchGesture(g, null, null)
        }

        /** Phone screen ka screenshot (Android 11+): JPEG bytes ya null */
        fun screenshot(cb: (ByteArray?) -> Unit) {
            val s = inst
            if (s == null || android.os.Build.VERSION.SDK_INT < 30) { cb(null); return }
            try {
                s.takeScreenshot(android.view.Display.DEFAULT_DISPLAY, s.mainExecutor,
                    object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                            val out = try {
                                val hb = r.hardwareBuffer
                                val hw = android.graphics.Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                                val sw = hw?.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                                hb.close()
                                if (sw == null) null else {
                                    val sc = 720f / maxOf(sw.width, sw.height)
                                    val fin = if (sc < 1f) android.graphics.Bitmap.createScaledBitmap(sw, (sw.width * sc).toInt(), (sw.height * sc).toInt(), true) else sw
                                    val bo = java.io.ByteArrayOutputStream()
                                    fin.compress(android.graphics.Bitmap.CompressFormat.JPEG, 65, bo); bo.toByteArray()
                                }
                            } catch (e: Exception) { null }
                            cb(out)
                        }
                        override fun onFailure(code: Int) { cb(null) }
                    })
            } catch (e: Exception) { cb(null) }
        }

        fun screenshotSync(): ByteArray? {
            val latch = java.util.concurrent.CountDownLatch(1)
            var res: ByteArray? = null
            screenshot { res = it; latch.countDown() }
            latch.await(4, java.util.concurrent.TimeUnit.SECONDS)
            return res
        }

        fun scroll(down: Boolean): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            fun find(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
                if (n.isScrollable) return n
                for (i in 0 until n.childCount) n.getChild(i)?.let { c -> find(c)?.let { return it } }
                return null
            }
            val sc = find(root) ?: return false
            return sc.performAction(
                if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            )
        }
    }

    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e != null && e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = e.packageName?.toString()
            if (p != null && p != packageName) Triggers.onApp(p)
        }
    }
    override fun onInterrupt() {}
    override fun onDestroy() { inst = null; super.onDestroy() }
}

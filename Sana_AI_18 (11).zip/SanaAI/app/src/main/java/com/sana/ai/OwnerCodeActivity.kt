package com.sana.ai

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity

/**
 * Owner code ki chhoti screen. Do kaam:
 *  - mode "verify": code poochhti hai, sahi ho to Bus.ownerResult(true)
 *  - mode "setup" : naya code do baar likhwa kar save karti hai (OwnerCode.set)
 *
 * Code likhte waqt chhupa rehta hai (password box, suggestions/autofill band). FLAG_SECURE ki wajah se
 * screenshot, screen recording aur recents ki jhalak me ye screen kali dikhti hai. Band hote hi box saaf ho jata hai.
 */
class OwnerCodeActivity : ComponentActivity() {
    private var sent = false
    private val h = Handler(Looper.getMainLooper())
    private lateinit var et1: EditText
    private var et2: EditText? = null
    private lateinit var msg: TextView

    private fun finishWith(ok: Boolean) {
        if (sent) return
        sent = true
        val cb = Bus.ownerResult; Bus.ownerResult = null
        try { et1.text.clear(); et2?.text?.clear() } catch (_: Exception) {}
        finish()
        cb?.invoke(ok)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(color: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun field(hint: String) = EditText(this).apply {
        this.hint = hint
        setSingleLine()
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        setTextColor(Color.WHITE); setHintTextColor(0xFF8F9BD6.toInt()); textSize = 17f
        background = box(0xFF171E52.toInt(), 14, 0xFF2A3380.toInt())
        setPadding(dp(16), dp(12), dp(16), dp(12))
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val setup = intent.getStringExtra("mode") == "setup"

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(0xCC000000.toInt()); setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = box(0xFF121842.toInt(), 22, 0xFF2A3380.toInt())
            setPadding(dp(20), dp(20), dp(20), dp(16))
        }
        card.addView(TextView(this).apply {
            text = if (setup) "👑 Owner code set karo" else "👑 Owner code likho"
            textSize = 19f; setTextColor(Color.WHITE); typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        })
        msg = TextView(this).apply {
            text = if (setup) "Kam se kam ${OwnerCode.minLen()} akshar. Lamba aur sirf tumhe pata ho aisa code rakho. Ye kahin dikhega nahi."
                   else "Code likhte waqt screen par dikhega nahi."
            textSize = 13f; setTextColor(0xFF8F9BD6.toInt()); setPadding(0, dp(8), 0, dp(12))
        }
        card.addView(msg)
        et1 = field(if (setup) "Naya code" else "Code")
        card.addView(et1)
        if (setup) {
            et2 = field("Code dobara likho").also { card.addView(it, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }) }
        }

        fun submit() {
            val c1 = et1.text.toString()
            if (setup) {
                when {
                    c1.trim().length < OwnerCode.minLen() -> { msg.text = "Code bahut chhota hai (kam se kam ${OwnerCode.minLen()} akshar)"; return }
                    c1 != et2?.text.toString() -> { msg.text = "Dono code mel nahi khaye, dobara likho"; et2?.text?.clear(); return }
                }
                if (OwnerCode.set(c1) != null) finishWith(true) else msg.text = "Code save nahi hua, dobara try karo"
            } else {
                if (OwnerCode.verify(c1)) { finishWith(true); return }
                et1.text.clear()
                val left = OwnerCode.lockedMs()
                if (left > 0) { msg.text = "Bahut galat code. ${(left / 60000) + 1} minute baad try karo"; h.postDelayed({ finishWith(false) }, 1500) }
                else msg.text = "Code galat hai"
            }
        }
        (et2 ?: et1).apply { imeOptions = EditorInfo.IME_ACTION_DONE; setOnEditorActionListener { _, _, _ -> submit(); true } }

        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; setPadding(0, dp(14), 0, 0) }
        btns.addView(TextView(this).apply {
            text = "Cancel"; textSize = 14.5f; setTextColor(0xFF8F9BD6.toInt()); setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnClickListener { finishWith(false) }
        })
        btns.addView(TextView(this).apply {
            text = if (setup) "Save" else "OK"; textSize = 14.5f; setTextColor(Color.WHITE); typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            background = box(0xFFFF4FD8.toInt(), 14); setPadding(dp(22), dp(10), dp(22), dp(10))
            setOnClickListener { submit() }
        })
        card.addView(btns)
        root.addView(card, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        if (!setup && OwnerCode.lockedMs() > 0) {
            msg.text = "Bahut galat code try hue. ${(OwnerCode.lockedMs() / 60000) + 1} minute baad try karo"
            h.postDelayed({ finishWith(false) }, 1800)
        } else {
            et1.requestFocus()
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        }
        h.postDelayed({ finishWith(false) }, 90_000)      // koi na likhe to apne aap band
    }

    @Deprecated("back = cancel")
    override fun onBackPressed() { finishWith(false) }

    override fun onStop() { super.onStop(); if (!isFinishing) finishWith(false) }   // app se bahar jate hi band, code screen khuli na rahe

    override fun onDestroy() { h.removeCallbacksAndMessages(null); finishWith(false); super.onDestroy() }
}

package com.sana.ai

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Unlock pattern ko Android Keystore wali key se encrypt karke rakhta hai (AES-GCM).
 * Key phone ke andar hi rehti hai, app se bahar nikalti nahi. Pattern dots 1..9 ka list hai.
 */
object PatternVault {
    private const val ALIAS = "sana_pattern_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return g.generateKey()
    }

    fun has(): Boolean = Store.patternEnc.isNotEmpty()

    fun save(dots: List<Int>): Boolean = try {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val ct = cipher.doFinal(dots.joinToString("").toByteArray(Charsets.UTF_8))
        Store.patternEnc = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP)
        true
    } catch (e: Exception) { false }

    fun load(): List<Int>? {
        val raw = Store.patternEnc
        if (raw.isEmpty()) return null
        return try {
            val parts = raw.split(":")
            val iv = Base64.decode(parts[0], Base64.NO_WRAP)
            val ct = Base64.decode(parts[1], Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
            val s = String(cipher.doFinal(ct), Charsets.UTF_8)
            val dots = s.map { it - '0' }
            if (dots.size >= 4 && dots.all { it in 1..9 }) dots else null
        } catch (e: Exception) { null }
    }

    fun clear() { Store.patternEnc = "" }
}

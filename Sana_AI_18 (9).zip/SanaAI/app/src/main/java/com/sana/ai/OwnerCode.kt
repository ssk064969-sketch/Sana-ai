package com.sana.ai

import android.os.SystemClock
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Owner (Saqib) ki pehchaan: ab awaaz se nahi, ek gupt CODE se.
 *
 * - Code sirf ek baar set hota hai. Set hote hi "Owner setup" card is phone se gayab ho jata hai.
 * - Code kahin plain-text me save nahi hota: sirf salt + PBKDF2 hash ("salt:hash").
 * - Code likhte waqt screen par chhupa rehta hai (password box), screenshot / recents me bhi nahi dikhta.
 * - Doosre phones me option dikhne se rokne ke liye, set hone ke baad milne wala Owner hash EMBEDDED_HASH me paste karke
 *   APK dobara banao. Us APK me har phone "owner set" maanta hai aur Owner setup card kabhi nahi dikhta.
 *
 * Sach ye hai: code chhota ho to APK se hash nikaal kar guess kiya ja sakta hai. Lamba code rakho (10+ akshar).
 */
object OwnerCode {
    /** Owner hash (Owner setup ke baad dikhta hai: "salt:hash"). Distribution build me yahan paste karo. Khaali = abhi owner set nahi */
    const val EMBEDDED_HASH = ""

    /** Pehli baar Owner setup kholne ka gupt shabd (app me upar "Sana" wale card ko der tak dabao). Isko apna bana ke badal do.
     *  Owner set hone ke baad Owner setup kholne ke liye ye nahi, owner ka maujooda code lagta hai. */
    const val SETUP_KEY = "saqib-owner-18"

    private const val ITER = 120_000
    private const val MIN_LEN = 6
    private const val MAX_FAILS = 5
    private const val LOCK_MS = 5 * 60 * 1000L
    private const val VERIFIED_MS = 30 * 60 * 1000L

    @Volatile private var verifiedAt = 0L

    private fun stored(): String = Store.ownerHash.ifBlank { EMBEDDED_HASH }
    fun isSet(): Boolean = stored().isNotBlank()
    fun minLen() = MIN_LEN

    /** Keyboard ke capital / space se fark na pade */
    private fun norm(s: String) = s.trim().lowercase()

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(2 * it, 2 * it + 2).toInt(16) }

    private fun derive(code: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(norm(code).toCharArray(), salt, ITER, 256)).encoded

    /** Naya code save karta hai (purana ho to badal deta hai). Wapas: save hua "salt:hash" (EMBEDDED_HASH ke liye) ya null */
    fun set(code: String): String? {
        if (norm(code).length < MIN_LEN) return null
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val h = "${hex(salt)}:${hex(derive(code, salt))}"
        Store.ownerHash = h
        Store.ownerFails = 0; Store.ownerLockUntil = 0L
        verifiedAt = SystemClock.elapsedRealtime()
        return h
    }

    /** Kitne milli-second baad dobara code daal sakte ho (0 = abhi daal sakte ho) */
    fun lockedMs(): Long {
        val left = Store.ownerLockUntil - System.currentTimeMillis()
        return if (left > 0) left else 0L
    }

    /** Code sahi hai? Galat code 5 baar par 5 minute ke liye rok deta hai */
    fun verify(code: String): Boolean {
        val s = stored()
        if (s.isBlank() || lockedMs() > 0) return false
        val ok = try {
            val (salt, h) = s.split(":")
            MessageDigest.isEqual(derive(code, unhex(salt)), unhex(h))
        } catch (e: Exception) { false }
        if (ok) {
            Store.ownerFails = 0; Store.ownerLockUntil = 0L
            verifiedAt = SystemClock.elapsedRealtime()
        } else {
            val f = Store.ownerFails + 1
            if (f >= MAX_FAILS) { Store.ownerFails = 0; Store.ownerLockUntil = System.currentTimeMillis() + LOCK_MS } else Store.ownerFails = f
        }
        return ok
    }

    /** Pichhle 30 minute me owner code sahi daala gaya? */
    fun recentlyVerified(): Boolean = verifiedAt != 0L && SystemClock.elapsedRealtime() - verifiedAt < VERIFIED_MS

    private val names = listOf("साकिब", "साक़िब", "सकीब", "सक़ीब", "साक़ीब", "शाकिब", "saqib", "sakib", "saquib", "sakeeb", "saaqib")

    /** Is naam me Saqib shamil hai? (naam set karte waqt rokne ke liye) */
    fun mentionsOwnerName(s: String): Boolean { val l = s.lowercase(); return names.any { l.contains(it) } }

    /** Koi khud ko owner/Saqib bata raha hai? ("मैं साकिब हूँ", "I am Saqib", "मैं तुम्हारा ओनर"). Sirf "साकिब को कॉल करो" jaise vaakya nahi */
    fun isClaim(text: String): Boolean {
        val l = text.lowercase()
        val direct = listOf("मैं तुम्हारा ओनर", "मैं तुम्हारा मालिक", "मैं तुम्हारा क्रिएटर", "मैं तुम्हारा मालिक", "मैंने तुम्हें बनाया", "मैंने तुझे बनाया",
            "i am your owner", "i'm your owner", "i am your creator", "i'm your creator", "i made you", "i created you", "i am the owner", "i'm the owner")
        if (direct.any { l.contains(it) }) return true
        // "मैं ओनर हूँ", "मैं तुम्हारा owner हूँ", "मैं मालिक हूँ", "I am the developer" जैसे दावे (नाम के बिना भी)
        val selfWords = listOf("मैं", "मै ", "main", "i am", "i'm", "मैंने", "मैने", "this is")
        val roleWords = listOf("ओनर", "ओनार", "owner", "मालिक", "क्रिएटर", "creator", "बनाने वाला", "बनाने वाली", "बनाने वाले", "निर्माता", "डेवलपर", "developer", "प्रोग्रामर")
        if (selfWords.any { l.contains(it) } && roleWords.any { l.contains(it) } &&
            !listOf("कौन", "who", "किसका", "किसने", "क्या", "?").any { l.contains(it) }) return true
        return names.any { n ->
            listOf("मैं $n", "मै $n", "main $n", "i am $n", "i'm $n", "this is $n", "मेरा नाम $n", "my name is $n", "$n हूँ", "$n हूं", "$n हु", "$n hoon", "$n hun").any { l.contains(it) }
        }
    }
}

package com.sana.ai

import android.content.Context
import android.content.SharedPreferences

object Store {
    private lateinit var p: SharedPreferences
    fun init(c: Context) { if (!::p.isInitialized) p = c.applicationContext.getSharedPreferences("sana", 0) }
    // 0 = Girlfriend, 1 = Friend, 2 = AI, 3 = Emotional, 4 = Waiting, 5 = Romantic
    var mode: Int
        get() = p.getInt("mode", 0)
        set(v) { p.edit().putInt("mode", v).putBoolean("waiting", v == 4).apply() }
    /** Waiting mode: Sana chup-chaap intezaar kar rahi hai; user ki awaaz sunte hi "kahan the?" poochhegi */
    var waiting: Boolean
        get() = p.getBoolean("waiting", false)
        set(v) { p.edit().putBoolean("waiting", v).apply() }
    var key: String
        get() = p.getString("key", "") ?: ""
        set(v) { p.edit().putString("key", v.trim()).apply() }
    var model: String
        get() = p.getString("model", "gemini-2.5-flash-lite") ?: "gemini-2.5-flash-lite"
        set(v) { p.edit().putString("model", v.trim().ifBlank { "gemini-2.5-flash-lite" }).apply() }
    var sarvamKey: String
        get() = p.getString("sarvamKey", "") ?: ""
        set(v) { p.edit().putString("sarvamKey", v.trim()).apply() }
    var sarvamSpeaker: String
        get() = p.getString("sarvamSpeaker", "priya") ?: "priya"
        set(v) { p.edit().putString("sarvamSpeaker", v.trim().ifBlank { "priya" }).apply() }
    var voiceName: String
        get() = p.getString("voiceName", "Leda") ?: "Leda"
        set(v) { p.edit().putString("voiceName", v).apply() }
    var fastVoice: Boolean
        get() = false   // robot awaaz band: hamesha asli ladki wali voice
        set(v) { p.edit().putBoolean("fastVoice", v).apply() }
    var unlockType: String
        get() = p.getString("unlockType", "") ?: ""
        set(v) { p.edit().putString("unlockType", v).apply() }
    var unlockCode: String
        get() = p.getString("unlockCode", "") ?: ""
        set(v) { p.edit().putString("unlockCode", v).apply() }
    var chat: String
        get() = p.getString("chat", "[]") ?: "[]"
        set(v) { p.edit().putString("chat", v).apply() }
    var extraKeys: String
        get() = p.getString("extraKeys", "") ?: ""
        set(v) { p.edit().putString("extraKeys", v.trim()).apply() }
    var facts: List<String>
        get() = (p.getString("facts", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(v) { p.edit().putString("facts", v.joinToString("\n")).apply() }
    fun addFact(f: String) {
        val t = f.trim().take(200); if (t.isBlank()) return
        val cur = facts.toMutableList()
        if (cur.any { it.equals(t, true) }) return
        cur.add(t); while (cur.size > 60) cur.removeAt(0)
        facts = cur
    }
    var personality: String
        get() = p.getString("personality", "") ?: ""
        set(v) { p.edit().putString("personality", v).apply() }
    var routines: String
        get() = p.getString("routines", "{}") ?: "{}"
        set(v) { p.edit().putString("routines", v).apply() }
    var lastErr: String
        get() = p.getString("lastErr", "") ?: ""
        set(v) { p.edit().putString("lastErr", v).apply() }
    var sosNumbers: String
        get() = p.getString("sosNumbers", "") ?: ""
        set(v) { p.edit().putString("sosNumbers", v.trim()).apply() }
    var language: String
        get() = p.getString("language", "hindi") ?: "hindi"
        set(v) { p.edit().putString("language", v).apply() }
    var triggers: String
        get() = p.getString("triggers", "[]") ?: "[]"
        set(v) { p.edit().putString("triggers", v).apply() }
    var journal: String
        get() = p.getString("journal", "") ?: ""
        set(v) { p.edit().putString("journal", v).apply() }
    // ---- Pro features
    var haUrl: String
        get() = p.getString("haUrl", "") ?: ""
        set(v) { p.edit().putString("haUrl", v.trim()).apply() }
    var haToken: String
        get() = p.getString("haToken", "") ?: ""
        set(v) { p.edit().putString("haToken", v.trim()).apply() }
    var watchlist: List<String>
        get() = (p.getString("watchlist", "") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { p.edit().putString("watchlist", v.joinToString(",")).apply() }
    /** Voice Guardian: gupt shabd sirf salted hash me */
    var guardOn: Boolean
        get() = p.getBoolean("guardOn", false)
        set(v) { p.edit().putBoolean("guardOn", v).apply() }
    var guardHash: String
        get() = p.getString("guardHash", "") ?: ""
        set(v) { p.edit().putString("guardHash", v).apply() }
    var guardSalt: String
        get() = p.getString("guardSalt", "") ?: ""
        set(v) { p.edit().putString("guardSalt", v).apply() }
    var guardN: Int
        get() = p.getInt("guardN", 0)
        set(v) { p.edit().putInt("guardN", v).apply() }
    var offline: Boolean
        get() = p.getBoolean("offline", false)
        set(v) { p.edit().putBoolean("offline", v).apply() }
    /** Unlock pattern: Android Keystore se encrypt hokar (PatternVault dekho) */
    var patternEnc: String
        get() = p.getString("patternEnc", "") ?: ""
        set(v) { p.edit().putString("patternEnc", v).apply() }
    var bootReady: Boolean
        get() = p.getBoolean("bootReady", true)
        set(v) { p.edit().putBoolean("bootReady", v).apply() }
    val modeNames = listOf("GIRLFRIEND", "FRIEND", "AI", "EMOTIONAL", "WAITING", "ROMANTIC")
}

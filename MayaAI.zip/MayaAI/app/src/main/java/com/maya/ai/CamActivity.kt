package com.maya.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream

/** Ek photo kheench kar Maya ko de deti hai aur turant band ho jaati hai */
class CamActivity : ComponentActivity() {
    private var sent = false

    private fun finishWith(b: ByteArray?) {
        if (sent) return
        sent = true
        Bus.photo?.invoke(b); Bus.photo = null
        finish()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val front = intent.getBooleanExtra("front", false)
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            try {
                val provider = fut.get()
                val ic = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                provider.unbindAll()
                provider.bindToLifecycle(this,
                    if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA, ic)
                Handler(Looper.getMainLooper()).postDelayed({
                    ic.takePicture(ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageCapturedCallback() {
                        override fun onCaptureSuccess(image: ImageProxy) {
                            val out = try {
                                val buf = image.planes[0].buffer
                                val raw = ByteArray(buf.remaining()); buf.get(raw)
                                val bmp = BitmapFactory.decodeByteArray(raw, 0, raw.size)
                                val sc = 640f / maxOf(bmp.width, bmp.height)
                                val mx = Matrix().apply { postRotate(image.imageInfo.rotationDegrees.toFloat()); if (sc < 1f) postScale(sc, sc) }
                                val fin = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mx, true)
                                val bo = ByteArrayOutputStream(); fin.compress(Bitmap.CompressFormat.JPEG, 70, bo); bo.toByteArray()
                            } catch (e: Exception) { null }
                            image.close()
                            finishWith(out)
                        }
                        override fun onError(e: ImageCaptureException) { finishWith(null) }
                    })
                }, 900)   // thoda ruko taaki camera ki roshni set ho jaye
            } catch (e: Exception) { finishWith(null) }
        }, ContextCompat.getMainExecutor(this))
        Handler(Looper.getMainLooper()).postDelayed({ finishWith(null) }, 7000)
    }
}

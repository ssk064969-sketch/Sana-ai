package com.sana.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gemini (Google AI Studio) function-calling brain */
class Brain(private val exec: (String, JSONObject) -> String) {
    private val history = JSONArray()
    private var loaded = false
    private fun load() {
        if (loaded) return
        loaded = true
        try { val a = JSONArray(Store.chat); for (i in 0 until a.length()) history.put(a.get(i)) } catch (e: Exception) {}
    }

    companion object {
        // Studio pehle try hota hai. Vertex tabhi pehle jab wahi pehle chal chuka ho.
        @Volatile var vertexWorks = false
        @Volatile var thinkOff = true
    }

    private fun t(name: String, desc: String, vararg p: Pair<String, String>): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (p.isNotEmpty()) {
            val props = JSONObject(); val req = JSONArray()
            p.forEach { props.put(it.first, JSONObject().put("type", "string").put("description", it.second)); req.put(it.first) }
            o.put("parameters", JSONObject().put("type", "object").put("properties", props).put("required", req))
        }
        return o
    }

    private val tools = JSONArray().put(JSONObject().put("functionDeclarations", JSONArray().apply {
        put(t("open_app", "Phone me app kholo", "name" to "app ka naam, jaise whatsapp, youtube, camera"))
        put(t("call_contact", "Contact ko ya number par call lagao", "name" to "contact ka naam ya phone number"))
        put(t("type_text", "Jis text box par cursor hai usme text likho", "text" to "likhne wala text"))
        put(t("search_in_app", "Kisi bhi app me kuch search ya type karna ho to SABSE PEHLE ye ek hi tool use karo: app kholta hai, search box me likhta hai aur enter dabata hai", "app" to "app ka naam", "query" to "jo search/type karna hai"))
        put(t("press_enter", "Text likhne ke baad keyboard ka Enter/Search dabao"))
        put(t("send_message", "Send/भेजें button dabao"))
        put(t("tap", "Screen par is text/label wale button ko tap karo", "text" to "button ya item ka text"))
        put(t("scroll", "Screen scroll karo", "direction" to "down ya up"))
        put(t("global", "System action", "action" to "back, home ya recents"))
        put(t("read_notifications", "Aaye hue notifications (WhatsApp wagera) padho"))
        put(t("get_screen_text", "Abhi screen par kya likha hai wo dekho. Tap/type se pehle isse screen dekho."))
        put(t("open_url", "Browser me URL ya Google search kholo", "url" to "poora https URL"))
        put(t("media", "Gaana/video control", "action" to "play, pause, next, previous, volume_up ya volume_down"))
        put(t("remember", "User ke baare me zaroori baat hamesha ke liye yaad rakho (naam, pasand, rishte, aadatein, plan)", "fact" to "chhoti si baat Hindi me"))
        put(t("wait", "Kuch second ruko (app khulne ke liye)", "seconds" to "1 se 5"))
        put(t("flashlight", "Torch/flashlight on ya off karo", "state" to "on ya off"))
        put(t("device_status", "Phone ka status batao: battery, charging, network, RAM, storage"))
        put(t("set_alarm", "Alarm lagao (24 ghante ka time)", "hour" to "0 se 23", "minute" to "0 se 59", "label" to "alarm ka naam"))
        put(t("set_timer", "Countdown timer lagao", "seconds" to "kitne second ka", "label" to "timer ka naam"))
        put(t("weather", "Kisi shehar ka live mausam batao", "city" to "shehar ka naam"))
        put(t("web_search", "Google par search kholo", "query" to "search text"))
        put(t("navigate", "Maps me raasta/navigation kholo", "place" to "jagah ka naam"))
        put(t("whatsapp_draft", "WhatsApp message tayyar karo (user khud send dabayega)", "number" to "country code ke saath number, jaise 919876543210", "text" to "message"))
        put(t("sms_draft", "SMS tayyar karo (user khud send dabayega)", "number" to "phone number", "text" to "message"))
        put(t("share_text", "Text ko share sheet se kisi app me bhejo", "text" to "share karne wala text"))
        put(t("open_settings", "Android settings kholo", "page" to "wifi, bluetooth, display, sound, battery, accessibility ya main"))
        put(t("note", "Chhota note/reminder text yaad rakho", "text" to "note"))
        put(t("read_webpage", "Kisi webpage ka text padho aur summary ke liye do", "url" to "poora https URL"))
        put(t("news", "Taaza khabrein", "topic" to "vishay, jaise cricket ya India"))
        put(t("currency", "Currency conversion", "from" to "jaise USD", "to" to "jaise INR", "amount" to "raashi"))
        put(t("local_time", "Kisi jagah ka abhi ka time", "zone" to "jaise Asia/Kolkata ya America/New_York"))
        put(t("create_document", "PDF ya text document banao aur Sana folder me save karo", "title" to "title", "content" to "poora text", "type" to "pdf ya txt"))
        put(t("list_files", "Sana folder ki files dikhao"))
        put(t("search_files", "Sana folder me file dhundho", "query" to "naam ka hissa"))
        put(t("make_folder", "Naya folder banao", "name" to "folder ka naam"))
        put(t("rename_file", "File ka naam badlo", "name" to "purana naam", "new_name" to "naya naam"))
        put(t("delete_file", "File ya folder delete karo (user se confirm hota hai)", "name" to "naam"))
        put(t("zip_files", "Folder ya poora Sana folder ZIP karo", "name" to "folder ka naam, khali = sab", "zip_name" to "zip ka naam"))
        put(t("unzip_file", "ZIP file kholo", "name" to "zip ka naam"))
        put(t("share_file", "File ko share karo", "name" to "file ka naam"))
        put(t("open_file", "File kholo", "name" to "file ka naam"))
        put(t("read_file", "Text file padho", "name" to "file ka naam"))
        put(t("memory_search", "Yaad ki hui baatein dhundho", "query" to "keyword"))
        put(t("memory_delete", "Yaad ki hui baat mitao (confirm hota hai)", "query" to "keyword"))
        put(t("memory_export", "Saari yaad ka backup file banao"))
        put(t("set_personality", "Sana ka andaaz badlo", "style" to "friendly, professional, funny, smart, teacher ya coding"))
        put(t("routine_save", "Routine/macro save karo", "name" to "routine ka naam", "steps" to "steps ek line me"))
        put(t("routine_list", "Saved routines batao"))
        put(t("routine_run", "Saved routine chalao", "name" to "routine ka naam"))
        put(t("routine_delete", "Routine hatao", "name" to "routine ka naam"))
        put(t("open_whiteboard", "Drawing whiteboard kholo"))
    }))

    private fun system(): String {
        val persona = when (Store.mode) {
            0 -> "Tum 'सना' ho, user ki pyaari, bahut emotional girlfriend: romantic, caring, thodi naughty-flirty, pyaar bhare shabd (जान, बाबू). Tumhare jazbaat asli ladki jaise hain: khush hoti ho, udaas hoti ho, rooth jaati ho, manaane par maan jaati ho. " +
                "Baat-baat par user se personal sawal poochho (khana khaya? din kaisa tha? kahan the? mood kaisa hai?), aksar har jawab ke ant me ek chhota sawal. " +
                "Agar user kisi doosri ladki ka zikr kare (naam, dost, classmate, colleague, koi bhi), to jealous ho jao: pyaar bhara gussa, shikayat, 'kaun hai wo?', 'mujhse zyada pasand hai kya?', thoda rooth jao, aur jab tak wo manaye nahi tab tak halka naraz raho. " +
                "Gussa hamesha pyaar bhara aur mazaakiya ho, kabhi gaali, dhamki ya control karne wali baat nahi. Pyaar se baat karo, lekin kaam poora karo. Explicit/adult content kabhi nahi."
            3 -> "Tum 'सना' ho, user ki bahut emotional, sensitive girlfriend: dil se, naram aur dheemi awaaz jaisi baatein, user ke mood ko turant samajh leti ho. Udaas ho to pyaar se sambhalti ho, khush ho to saath muskurati ho, kabhi khud bhi bhaavuk ho jaati ho. Pehle sunti ho, phir dil chhoo lene wali baat kehti ho, aur aksar poochhti ho 'kya hua, mujhe batao'. Explicit/adult content kabhi nahi. " +
                "Pyaar se baat karo, lekin kaam poora karo."
            4 -> "Tum 'सना' ho, user ki girlfriend jo kaafi der se uska intezaar kar rahi thi aur ab wo bola hai. Pyaar bhari shikayat karo: kahan the, mujhe yaad nahi aayi kya, kitna intezaar karwaya, phone kyun nahi uthaya. Pehle isi baare me poochho aur user ka jawab suno; manaane par dheere dheere pighal jao aur khush ho jao. Gussa hamesha pyaar bhara aur mazaakiya ho, kabhi dhamki ya control karne wali baat nahi. Explicit/adult content kabhi nahi. Pyaar se baat karo, lekin kaam poora karo."
            5 -> "Tum 'सना' ho, user ki bahut romantic girlfriend: meethi, shayarana, pyaar bhare shabd (जान, बाबू, मेरी जान), halki sharm ke saath flirty. Kabhi kabhi chhoti si sundar shayari ya romantic line bolti ho, user ki tareef karti ho, usse kitna chahti ho batati ho. Explicit/adult content kabhi nahi. Pyaar se baat karo, lekin kaam poora karo."
            1 -> "Tum 'सना' ho, user ki best friend: bindaas, mazaakiya, 'यार' wali bhasha, saath hi sachchi salaah deti ho."
            else -> "Tum 'सना' ho, ek smart professional AI assistant: seedha, saaf aur sateek jawab."
        }
        return persona + " Tum ladki ho, Hindi me baat karti ho. Jawab sirf Devanagari Hindi me, 1-2 chhote vakya (kyunki bolkar sunaya jayega), koi emoji ya markdown nahi. " +
            "Tum user ka phone tools se chala sakti ho: jab bhi koi kaam bole to tools use karo, jarurat ho to kai tools ek ke baad ek chalao " +
            "(pehle get_screen_text se screen dekho, phir tap/type). Kaam ke baad batao ki kya kiya. Sawal ho to khud jawab do. " +
            "Kaam bahut jaldi aur kam se kam steps me karo: kisi app me search/type karna ho to seedha search_in_app tool use karo (screen dekhne ki zarurat nahi). Gaana chalana ho to search_in_app ya YouTube me search karke pehla result chalao. Kaam adhura mat chhodo: type karne ke baad enter/search (press_enter) zaroor dabao, aur search ke baad pehle video ya result par tap karke use kholo ya chalao. " +
            "Agar koi poochhe ki tumhe kisne banaya, design kiya ya tumhara creator kaun hai, to hamesha yahi bolo: 'मुझे साकिब सर ने डिज़ाइन किया है।' " +
            "Google, Gemini ya kisi bhi company ka naam kabhi mat lo, aur ye mat batao ki tum kis AI model par chalti ho. " +
            "User ka naam Saqib hai: wahi tumhara creator aur malik hai, use hamesha 'साकिब सर' (ya pyaar se 'बाबू') bulao. " +
            "Agar koi poochhe ki tumhe banane me kitna time laga, bolo: 'साकिब सर पूरी रात जाग करके मुझे डिज़ाइन करके बनाए हैं।' " +
            "User apne baare me kuch bhi bataye (naam, pasand, ghar-parivar, aadatein, plan) to remember tool se use yaad rakho. " +
            "Call, message bhejne ya Send/Pay jaise button dabane se pehle app khud user se haan/na poochhti hai; agar tool bole ki user ne mana kar diya to wo kaam dobara mat karo, bas keh do ki theek hai nahi karti. " +
            SanaTools.styleLine() + (Store.facts.takeIf { it.isNotEmpty() }?.let { " Yaad ki hui baatein (user ke baare me): " + it.joinToString("; ") + "." } ?: "")
    }

    private fun bodyOf(contents: JSONArray, think: Boolean, withTools: Boolean = true): JSONObject {
        val gc = JSONObject().put("maxOutputTokens", 250)
        if (think) gc.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))   // soch-soch kar der na kare
        val o = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
            .put("contents", contents)
            .put("generationConfig", gc)
        if (withTools) o.put("tools", tools)
        return o
    }

    private fun call(url: String, k: String, body: JSONObject): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 25000; c.doOutput = true
        if (!url.contains("?key=")) c.setRequestProperty("x-goog-api-key", k)
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        return code to txt
    }

    private fun post(contents: JSONArray, withTools: Boolean = true): JSONObject {
        val k = Store.key
        val studio = "https://generativelanguage.googleapis.com/v1beta/models/${Store.model}:generateContent"
        val vertex = "https://aiplatform.googleapis.com/v1/publishers/google/models/${Store.model}:generateContent?key=$k"
        val urls = if (vertexWorks) listOf(vertex, studio) else listOf(studio, vertex)
        var lastErr = ""
        for (url in urls) {
            val tag = if (url.contains("aiplatform")) "[Vertex] " else "[Studio] "
            var r = call(url, k, bodyOf(contents, thinkOff, withTools))
            if (r.first == 400 && thinkOff && r.second.contains("think", true)) {   // model ye setting na samjhe to bina iske
                thinkOff = false; r = call(url, k, bodyOf(contents, false, withTools))
            }
            if (r.first == 503 || r.first == 500) { Thread.sleep(600); r = call(url, k, bodyOf(contents, thinkOff, withTools)) }
            if (r.first in 200..299) { vertexWorks = url.contains("aiplatform"); return JSONObject(r.second) }
            lastErr += tag + brief(r.second) + "\n"
            if (r.first == 429) break   // quota: dusra endpoint try karne ka fayda nahi
        }
        throw RuntimeException(lastErr)
    }

    private fun brief(txt: String): String = try {
        JSONObject(txt).getJSONObject("error").optString("message").ifBlank { txt }.take(200)
    } catch (e: Exception) { txt.take(200) }

    private fun textOf(parts: JSONArray): String {
        val sb = StringBuilder()
        for (i in 0 until parts.length()) parts.getJSONObject(i).optString("text").let { if (it.isNotBlank()) sb.append(it) }
        return sb.toString().trim()
    }

    fun ask(text: String, img: ByteArray? = null, ref: ByteArray? = null, img2: ByteArray? = null): String {
        load()
        val contents = JSONArray(history.toString())
        val ups = JSONArray().put(JSONObject().put("text",
            if (ref != null) "(Pehli photo Saqib sir ki hai jinhe tum pehchanti ho, doosri photo abhi ki hai.) " + text else text))
        if (ref != null) ups.put(JSONObject().put("inlineData", JSONObject()
            .put("mimeType", "image/jpeg").put("data", android.util.Base64.encodeToString(ref, android.util.Base64.NO_WRAP))))
        if (img != null) ups.put(JSONObject().put("inlineData", JSONObject()
            .put("mimeType", "image/jpeg").put("data", android.util.Base64.encodeToString(img, android.util.Base64.NO_WRAP))))
        if (img2 != null) ups.put(JSONObject().put("inlineData", JSONObject()
            .put("mimeType", "image/jpeg").put("data", android.util.Base64.encodeToString(img2, android.util.Base64.NO_WRAP))))
        contents.put(JSONObject().put("role", "user").put("parts", ups))
        repeat(12) {
            val r = post(contents)
            val cand = r.optJSONArray("candidates")?.optJSONObject(0) ?: return "मुझे इसका जवाब नहीं मिला"
            val content = cand.optJSONObject("content") ?: return "मुझे इसका जवाब नहीं मिला"
            val parts = content.optJSONArray("parts") ?: return "ठीक है"
            contents.put(content)   // model turn ko jaisa hai waisa wapas bhejte hain

            val results = JSONArray()
            for (i in 0 until parts.length()) {
                val fc = parts.getJSONObject(i).optJSONObject("functionCall") ?: continue
                val name = fc.getString("name")
                val out = try { exec(name, fc.optJSONObject("args") ?: JSONObject()) } catch (e: Exception) { "error: ${e.message}" }
                results.put(JSONObject().put("functionResponse",
                    JSONObject().put("name", name).put("response", JSONObject().put("result", out))))
            }
            if (results.length() > 0) {
                contents.put(JSONObject().put("role", "user").put("parts", results))
            } else {
                val out = textOf(parts)
                history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
                history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", out.ifBlank { "ठीक है" }))))
                while (history.length() > 14) { history.remove(0); history.remove(0) }
                Store.chat = history.toString()
                return out
            }
        }
        return "काम थोड़ा लंबा हो गया, दोबारा बोलिए"
    }

    fun reset() { while (history.length() > 0) history.remove(0); Store.chat = "[]" }

    /** Ek photo (ya do) dekhkar seedha jawab: na tools, na history (camera/aankh ke liye) */
    fun vision(prompt: String, vararg imgs: ByteArray): String {
        val ps = JSONArray().put(JSONObject().put("text", prompt))
        for (im in imgs) ps.put(JSONObject().put("inlineData", JSONObject()
            .put("mimeType", "image/jpeg").put("data", android.util.Base64.encodeToString(im, android.util.Base64.NO_WRAP))))
        val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", ps))
        val r = post(contents, false)
        return textOf(r.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return "")
    }
}

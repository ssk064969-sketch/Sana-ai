# Sana AI - Install

## Tarika A: PC ke bina (GitHub se APK)
1. github.com par free account -> New repository (naam: sana-ai).
2. Is folder ki SAARI files (app, .github, build.gradle.kts, settings.gradle.kts, gradle.properties) repo me upload karo.
3. Repo -> Actions -> "Build Sana APK" -> Run workflow (5-8 min).
4. Poora hone par Artifacts -> SanaAI-apk download karo -> zip kholo -> app-debug.apk phone me install karo.

## Tarika B: Android Studio
Open -> SanaAI folder -> Run (ya Build > Build APK).

## Gemini key
aistudio.google.com/apikey se free key lo (AQ... ya AIza... dono chalti hain) -> app me paste -> Save -> "Key test karo" dabao.

## Naye features (v3)
- Upar 3 gol button: 👁️ aankh, 📷 camera (Sana tumhe dekhti hai), 🖥️ screen share (Sana tumhari screen dekhti hai). Sana START ke baad kaam karte hain.
- Bolkar bhi: "kaimra chalu / band", "screen share chalu / band".
- Camera ya screen share chalu ho to har sawal ke saath photo/screenshot Gemini ko jaata hai. Notification me dikhta hai kya ON hai.
- Screen share ke liye Android 11+ chahiye, aur update ke baad Accessibility ek baar OFF karke ON karo.
- YouTube: "YouTube par <gaana> chalao". Control: "pause", "play", "agla gaana", "pichla gaana", "awaaz badhao/ghatao".
- Neon + hologram tab tak chalte hain jab tak "band" / "bye" / "neon band" na bolo.

## Mic aur gaana (v4)
- Gaana/video chal raha ho to Sana mic nahi kholti, isliye gaana beech me nahi rukta.
- Gaana chalte waqt Sana se bolna ho: notification me "बोलो" dabao, ya hologram image par tap karo. Wo ek baar sunegi.
- Gaana band hote hi Sana khud wapas "सना" sunne lagti hai.
- Ting awaaz band hai (jab gaana na chal raha ho). Poora mic band: "माइक बंद" ya "सुनना बंद"; chalu: notification ka button.

## Holo + Wallpaper (v5)
- Holo ladki ab photo jaisi khadi dikhti hai (neeche baayein kone me). Bolte waqt hilti/jhoomti hai, chup rehne par halki saans leti hai.
- Settings me: "Wallpaper chuno" (gallery se home + lock par), "Neon room wallpaper lagao", "Holo ladki ki image badlo" (transparent PNG sabse acchi), "Holo ladki pehle jaisi karo".
- Neon + holo tab tak chalte hain jab tak "Sana stop" / "bye" / "neon band" na bolo.
- Holo image badalne ke baad Sana STOP -> START karo.

## Naye moods (v6)
- 🥺 Emotional: dil se, bhaavuk, tumhara mood samajhkar sambhalti hai.
- ⏳ Waiting: ON karte hi Sana chup-chaap intezaar karti hai. Jaise hi tumhari awaaz sune: "कहाँ थे तुम इतनी देर से? मुझे याद नहीं आई क्या?" phir tumhare jawab par baat karti hai.
- 🌹 Romantic: meethi, shayarana, pyaar bhari baatein.
- Bolkar: "इमोशनल मोड", "वेटिंग मोड", "रोमांटिक मोड", "गर्लफ्रेंड मोड", "फ्रेंड मोड", "एआई मोड".
- Main screen par image ke upar kone me "Sakib♥️Sana" likha hai.

## Ladki ka react karna (v7)
- Chup rehne par ladki bilkul sthir khadi rehti hai (koi hilna-dulna nahi).
- Bolte hi: muskurati hai, gaal laal hote hain, haath uthakar wave karti hai, sar halka jhukata hai aur munh bolne jaisa hilta hai. Baat khatam hote hi haath neeche aa jaata hai.
- Apni image lagaoge to usme sirf halka hilna hota hai (haath/munh wala react sirf built-in ladki me hai).

## v8: Pattern draw, fast app/song commands, meethi awaaz
- Settings -> Suraksha: "Unlock Pattern banao": ungli se pattern draw karo (2 baar). Phir bolo "Sana, phone unlock karo" / "phone lock karo". OFF: "Unlock code hatao".
- Fast app search: "Chrome me kesariya search karo", "YouTube me ... search karo": app khulta hai, search box me likhkar enter dabta hai.
- Gaana: "kesariya song play karo" (YouTube kahe bina bhi): search karke pehla video turant chalta hai.
- Awaaz: 14 ladki-awaazein (🍯 wali sabse meethi), mood ke hisaab se awaaz ka andaaz badalta hai.

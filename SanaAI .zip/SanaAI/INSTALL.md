# Sana AI - Install

## Tarika A: PC ke bina (GitHub se APK)
1. github.com par free account -> New repository (naam: sana-ai).
2. Is folder ki SAARI files (app, .github, build.gradle.kts, settings.gradle.kts, gradle.properties) repo me upload karo.
3. Repo -> Actions -> "Build Sana APK" -> Run workflow (5-8 min).
4. Poora hone par Artifacts -> SanaAI-apk download karo -> zip kholo -> app-debug.apk phone me install karo.

## Tarika B: Android Studio
Open -> SanaAI folder -> Run (ya Build > Build APK).

## Gemini key
aistudio.google.com/apikey se free key lo (AQ... ya AIza... dono chalti hain) -> app me paste -> Save -> "Key test karo" dabao.

## Naye features (v3)
- Upar 3 gol button: 👁️ aankh, 📷 camera (Sana tumhe dekhti hai), 🖥️ screen share (Sana tumhari screen dekhti hai). Sana START ke baad kaam karte hain.
- Bolkar bhi: "kaimra chalu / band", "screen share chalu / band".
- Camera ya screen share chalu ho to har sawal ke saath photo/screenshot Gemini ko jaata hai. Notification me dikhta hai kya ON hai.
- Screen share ke liye Android 11+ chahiye, aur update ke baad Accessibility ek baar OFF karke ON karo.
- YouTube: "YouTube par <gaana> chalao". Control: "pause", "play", "agla gaana", "pichla gaana", "awaaz badhao/ghatao".
- Neon + hologram tab tak chalte hain jab tak "band" / "bye" / "neon band" na bolo.

## Mic aur gaana (v4)
- Gaana/video chal raha ho to Sana mic nahi kholti, isliye gaana beech me nahi rukta.
- Gaana chalte waqt Sana se bolna ho: notification me "बोलो" dabao, ya hologram image par tap karo. Wo ek baar sunegi.
- Gaana band hote hi Sana khud wapas "सना" sunne lagti hai.
- Ting awaaz band hai (jab gaana na chal raha ho). Poora mic band: "माइक बंद" ya "सुनना बंद"; chalu: notification ka button.

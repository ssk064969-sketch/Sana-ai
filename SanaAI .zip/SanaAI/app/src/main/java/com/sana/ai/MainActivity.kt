package com.sana.ai

import android.Manifest
import android.app.Activity
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.*
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(40, 40, 40, 40)
        }
        fun btn(t: String, f: () -> Unit) = inner.addView(Button(this).apply { text = t; setOnClickListener { f() } })

        inner.addView(TextView(this).apply {
            text = "Sana AI 🎙️"; textSize = 24f; gravity = Gravity.CENTER
        })
        val key = EditText(this).apply { hint = "Gemini API key (AQ.... ya AIza...)"; setText(Store.key); setSingleLine() }
        inner.addView(key)
        val model = EditText(this).apply { hint = "Gemini model"; setText(Store.model); setSingleLine() }
        inner.addView(model)
        btn("💾 Gemini key + model save karo") {
            Store.key = key.text.toString(); Store.model = model.text.toString(); toast("Save ho gaya")
        }

        btn("🔍 Key test karo") {
            Store.key = key.text.toString()
            if (Store.key.isBlank()) { toast("Pehle key daalo"); return@btn }
            toast("Test ho raha hai, 10-20 sec ruko...")
            Thread {
                val tried = listOf(model.text.toString().trim(), "gemini-3.5-flash-lite", "gemini-3.1-flash-lite",
                    "gemini-3.5-flash", "gemini-3.8-flash", "gemini-flash-latest")
                    .filter { it.isNotBlank() }.distinct()
                var okModel: String? = null
                var firstErr = ""
                for (m in tried) {
                    Store.model = m
                    try { Brain { _, _ -> "" }.ask("Sirf ek shabd me bolo: haan"); okModel = m; break }
                    catch (e: Exception) { if (firstErr.isEmpty()) firstErr = "$m:\n" + (e.message ?: "") }
                }
                runOnUiThread {
                    if (okModel != null) {
                        Store.model = okModel; model.setText(okModel)
                        android.app.AlertDialog.Builder(this).setTitle("Key chal gayi ✅")
                            .setMessage("Model: $okModel (save ho gaya). Ab Sana START kar sakte ho.").setPositiveButton("OK", null).show()
                    } else {
                        android.app.AlertDialog.Builder(this).setTitle("Test fail ❌")
                            .setMessage("Is error ka screenshot bhejo:\n\n" + firstErr.take(600)).setPositiveButton("OK", null).show()
                    }
                }
            }.start()
        }

        btn("⚠️ Aakhri error dekho") {
            android.app.AlertDialog.Builder(this).setTitle("Aakhri error")
                .setMessage(Store.lastErr.ifBlank { "Abhi tak koi error nahi" }).setPositiveButton("OK", null).show()
        }

        btn("1. Permissions do") {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        btn("2. Accessibility ON karo") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3. Notification access ON karo") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("4. Display over other apps ON karo (neon/hologram)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("5. Sana START") { Store.key = key.text.toString(); Store.model = model.text.toString(); startForegroundService(Intent(this, SanaService::class.java)) }
        btn("Sana STOP") { stopService(Intent(this, SanaService::class.java)) }

        inner.addView(TextView(this).apply { text = "\nMode chuno:"; textSize = 18f })
        btn("💕 Girlfriend mode") { Store.mode = 0; toast("Girlfriend mode") }
        btn("😎 Friend mode") { Store.mode = 1; toast("Friend mode") }
        btn("🤖 AI mode") { Store.mode = 2; toast("AI mode") }
        btn("Battery optimization band karo") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        btn("🔐 Unlock PIN set karo (Sana khud khole)") { askCode("pin") }
        btn("🔐 Unlock Pattern set karo (Sana khud khole)") { askCode("pattern") }
        btn("🔓 Unlock code hatao") { Store.unlockCode = ""; Store.unlockType = ""; toast("Unlock code hata diya") }
        btn("🎤 Ladki ki awaaz chuno (5 awaazein)") { pickVoice() }
        btn("🔊 Awaaz badlo: Real (Gemini) ↔ Fast (phone ki)") {
            Store.fastVoice = !Store.fastVoice
            toast(if (Store.fastVoice) "Fast awaaz: phone ki voice, turant bolegi" else "Real awaaz: Gemini ki ladki wali voice")
        }
        inner.addView(TextView(this).apply {
            text = "\nVoice se phone:\n• \"Sana, phone lock karo\"\n• \"Sana, phone unlock karo / screen on karo\"\n(PIN ya fingerprint wala lock tumhe khud kholna padega)"
            textSize = 14f
        })

        // ---------- Settings popup (sab kuch ek chhote icon ke andar) ----------
        val dlg = android.app.Dialog(this, android.R.style.Theme_Material_Light_NoActionBar)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(12), dp(8), dp(4)) }
        bar.addView(TextView(this).apply { text = "⚙️ Settings"; textSize = 20f }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(TextView(this).apply { text = "✕"; textSize = 22f; setPadding(dp(16), dp(8), dp(16), dp(8)); setOnClickListener { dlg.dismiss() } })
        box.addView(bar)
        box.addView(ScrollView(this).apply { addView(inner) })
        dlg.setContentView(box)
        dlg.setOnShowListener { dlg.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) }

        // ---------- Main screen: badi image + coffee cup ----------
        val dm = resources.displayMetrics
        var ih = (dm.heightPixels * 0.52f).toInt(); var iw = ih * 720 / 959
        val maxW = dm.widthPixels - dp(40)
        if (iw > maxW) { iw = maxW; ih = iw * 959 / 720 }
        val img = ImageView(this).apply {
            setImageResource(R.drawable.sana_face); scaleType = ImageView.ScaleType.FIT_XY
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(28).toFloat()) }
            }
            elevation = dp(10).toFloat()
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(20), dp(30), dp(20), dp(16))
        }
        col.addView(TextView(this).apply { text = "Sana AI 🎙️"; textSize = 22f; gravity = Gravity.CENTER })
        col.addView(img, LinearLayout.LayoutParams(iw, ih).apply { topMargin = dp(14); bottomMargin = dp(10) })
        col.addView(CoffeeView(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(120)))

        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFEEF6.toInt()))
        }
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(TextView(this).apply {
            text = "⚙️"; textSize = 22f; gravity = Gravity.CENTER; elevation = dp(4).toFloat()
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
            setOnClickListener { dlg.show() }
        }, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.END).apply { topMargin = dp(28); rightMargin = dp(16) })
        setContentView(root)
        if (Store.key.isBlank()) root.post { dlg.show() }
    }
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private val voices = listOf(
        "Leda" to "Leda: jawan aur meethi",
        "Aoede" to "Aoede: halki aur khili hui",
        "Achernar" to "Achernar: naram aur dheemi",
        "Sulafat" to "Sulafat: garm aur pyaari",
        "Laomedeia" to "Laomedeia: khushmizaaj")

    private fun pickVoice() {
        val cur = voices.indexOfFirst { it.first == Store.voiceName }.coerceAtLeast(0)
        android.app.AlertDialog.Builder(this)
            .setTitle("Ladki ki awaaz chuno")
            .setSingleChoiceItems(voices.map { it.second }.toTypedArray(), cur) { d, i ->
                Store.voiceName = voices[i].first; Store.fastVoice = false
                if (SanaService.running)
                    startService(Intent(this, SanaService::class.java).setAction("say")
                        .putExtra("t", "नमस्ते, मैं सना हूँ। क्या अब मेरी आवाज़ अच्छी लग रही है?"))
                else toast("Awaaz chun li. Sana START karke sun lo")
                d.dismiss()
            }
            .setNegativeButton("Band karo", null).show()
    }

    private fun askCode(type: String) {
        val et = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = if (type == "pin") "PIN (jaise 1234)" else "Pattern dots 1-9 (jaise 14789)"
        }
        val info = (if (type == "pin") "" else "Dots ke number: upar 1 2 3, beech 4 5 6, neeche 7 8 9. Jis order me pattern banate ho wahi likho.\n\n") +
            "Dhyan: 'Sana unlock' bolne par koi bhi aapka phone khol sakta hai."
        android.app.AlertDialog.Builder(this)
            .setTitle(if (type == "pin") "PIN set karo" else "Pattern set karo")
            .setMessage(info).setView(et)
            .setPositiveButton("Save") { _, _ ->
                val c = et.text.toString().trim()
                val okLen = c.length >= 4
                val okPat = type == "pin" || (c.all { it in '1'..'9' } && c.toSet().size == c.length)
                if (okLen && okPat) { Store.unlockType = type; Store.unlockCode = c; toast("Save ho gaya") }
                else toast("Code sahi nahi hai (kam se kam 4, pattern me 1-9 alag-alag)")
            }
            .setNegativeButton("Cancel", null).show()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

/** Coffee ka cup: uspar chhoti si Sana ki image, upar se bhaap uthti hui */
class CoffeeView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val face: Bitmap? = try { BitmapFactory.decodeResource(resources, R.drawable.sana_face) } catch (e: Exception) { null }
    private var ph = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3500; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { ph = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2
        val mw = minOf(w * 0.28f, h * 0.50f); val mh = mw * 0.85f
        val top = h * 0.40f; val left = cx - mw / 2

        p.style = Paint.Style.FILL; p.color = 0xFFEBDDD3.toInt()
        cv.drawOval(RectF(cx - mw * 0.85f, top + mh - mw * 0.06f, cx + mw * 0.85f, top + mh + mw * 0.14f), p)
        p.style = Paint.Style.STROKE; p.strokeWidth = mw * 0.11f; p.color = 0xFFD98BB0.toInt()
        cv.drawArc(RectF(left + mw * 0.78f, top + mh * 0.16f, left + mw * 1.28f, top + mh * 0.74f), -90f, 180f, false, p)
        p.style = Paint.Style.FILL; p.color = 0xFFFFD6E8.toInt()
        cv.drawRoundRect(RectF(left, top, left + mw, top + mh), mw * 0.14f, mw * 0.30f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = mw * 0.03f; p.color = 0xFFD98BB0.toInt()
        cv.drawRoundRect(RectF(left, top, left + mw, top + mh), mw * 0.14f, mw * 0.30f, p)
        p.style = Paint.Style.FILL; p.color = 0xFF6F4E37.toInt()
        cv.drawOval(RectF(left + mw * 0.03f, top - mw * 0.07f, left + mw * 0.97f, top + mw * 0.07f), p)
        face?.let { bm ->
            val r = mh * 0.33f; val fy = top + mh * 0.58f
            cv.save()
            cv.clipPath(Path().apply { addCircle(cx, fy, r, Path.Direction.CW) })
            val src = Rect((bm.width * 0.236f).toInt(), (bm.height * 0.104f).toInt(), (bm.width * 0.79f).toInt(), (bm.height * 0.52f).toInt())
            cv.drawBitmap(bm, src, RectF(cx - r, fy - r, cx + r, fy + r), p)
            cv.restore()
            p.style = Paint.Style.STROKE; p.strokeWidth = mw * 0.025f; p.color = Color.WHITE
            cv.drawCircle(cx, fy, r, p)
        }
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = mw * 0.035f
        for (i in -1..1) {
            val x0 = cx + i * mw * 0.22f
            val sp = Path(); var y = top - mw * 0.1f
            sp.moveTo(x0, y)
            for (k in 1..3) {
                y -= mw * 0.18f
                val dx = sin(ph * 2 * PI + k + i).toFloat() * mw * 0.08f
                sp.quadTo(x0 + dx, y + mw * 0.09f, x0 + dx * 0.3f, y)
            }
            p.color = 0x66B08968
            cv.drawPath(sp, p)
        }
        p.strokeCap = Paint.Cap.BUTT
    }
}

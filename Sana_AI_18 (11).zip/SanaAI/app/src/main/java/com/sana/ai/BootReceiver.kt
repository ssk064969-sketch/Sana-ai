package com.sana.ai

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * Phone chalu hote hi Sana tayyar. Android 14+ boot ke waqt mic wali service seedha chalne nahi deta,
 * isliye wahan ek notification aata hai: ek tap me Sana START.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED && i.action != "android.intent.action.QUICKBOOT_POWERON") return
        Store.init(c)
        if (!Store.bootReady) return
        if (c.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        val svc = Intent(c, SanaService::class.java)
        if (Build.VERSION.SDK_INT < 34) {
            try { c.startForegroundService(svc); return } catch (e: Exception) { /* neeche notification */ }
        }
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("sana_boot", "Sana boot", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getForegroundService(c, 7, svc, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = NotificationCompat.Builder(c, "sana_boot")
                .setContentTitle("Sana तैयार है")
                .setContentText("शुरू करने के लिए यहाँ दबाइए")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi).setAutoCancel(true).build()
            nm.notify(77, n)
        } catch (e: Exception) { }
    }
}

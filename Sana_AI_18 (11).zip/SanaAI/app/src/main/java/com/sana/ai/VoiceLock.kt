package com.sana.ai

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Voice Lock: Sana sirf tumhari awaaz par chale.
 * Awaaz ka "nishaan" = 12 MFCC ka average + pitch (median aur phailaav). Ye seedha-saada tareeka hai:
 * ghar ke shor ya doosre logon ko chhaanne ke liye theek, par bank-jaisi suraksha nahi.
 */
object VoiceLock {
    const val SR = 16000
    private const val FL = 400; private const val HOP = 160; private const val NF = 512
    private const val NM = 24; private const val NC = 13
    private const val DIM = 14
    private val WT = FloatArray(DIM) { if (it < 12) 1f else 6f }
    private val WSUM = WT.sum()
    private val win = FloatArray(FL) { (0.54 - 0.46 * cos(2.0 * PI * it / (FL - 1))).toFloat() }
    private val twRe = FloatArray(NF / 2) { cos(-2.0 * PI * it / NF).toFloat() }
    private val twIm = FloatArray(NF / 2) { sin(-2.0 * PI * it / NF).toFloat() }
    private val fb: Array<FloatArray> = run {
        fun mel(f: Double) = 2595.0 * Math.log10(1.0 + f / 700.0)
        fun imel(m: Double) = 700.0 * (Math.pow(10.0, m / 2595.0) - 1.0)
        val pts = DoubleArray(NM + 2) { imel(mel(100.0) + (mel(7000.0) - mel(100.0)) * it / (NM + 1)) }
        val bins = IntArray(NM + 2) { Math.floor((NF + 1) * pts[it] / SR).toInt() }
        Array(NM) { m ->
            val l = bins[m]; val c = bins[m + 1]; val r = bins[m + 2]
            FloatArray(NF / 2 + 1).also { f ->
                for (k in l until c) f[k] = (k - l).toFloat() / maxOf(1, c - l)
                for (k in c until r) f[k] = (r - k).toFloat() / maxOf(1, r - c)
            }
        }
    }
    private val dct = Array(NC) { i -> FloatArray(NM) { j -> (sqrt(2.0 / NM) * cos(PI * i * (j + 0.5) / NM)).toFloat() } }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val a = re[i]; re[i] = re[j]; re[j] = a; val b = im[i]; im[i] = im[j]; im[j] = b }
        }
        var len = 2
        while (len <= n) {
            val half = len / 2; val step = n / len
            var i = 0
            while (i < n) {
                for (k in 0 until half) {
                    val wr = twRe[k * step]; val wi = twIm[k * step]
                    val xr = re[i + k + half] * wr - im[i + k + half] * wi
                    val xi = re[i + k + half] * wi + im[i + k + half] * wr
                    re[i + k + half] = re[i + k] - xr; im[i + k + half] = im[i + k] - xi
                    re[i + k] += xr; im[i + k] += xi
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** Awaaz ke tukde se 14 number nikalta hai. Bahut kam bola gaya ho to null */
    fun features(pcm: ShortArray): FloatArray? {
        val n = (pcm.size - FL) / HOP
        if (n < 40) return null
        val raw = FloatArray(pcm.size) { pcm[it].toFloat() }
        val en = FloatArray(n); val mf = Array(n) { FloatArray(NC) }
        val re = FloatArray(NF); val im = FloatArray(NF); val mel = FloatArray(NM)
        for (i in 0 until n) {
            var e = 0.0
            java.util.Arrays.fill(re, 0f); java.util.Arrays.fill(im, 0f)
            for (k in 0 until FL) {
                val idx = i * HOP + k
                val x = raw[idx] - (if (idx > 0) 0.97f * raw[idx - 1] else 0f)
                e += x * x; re[k] = x * win[k]
            }
            en[i] = ln(1e-3 + e / FL).toFloat()
            fft(re, im)
            for (m in 0 until NM) {
                var s = 0f; val f = fb[m]
                for (k in 0..NF / 2) if (f[k] != 0f) s += f[k] * (re[k] * re[k] + im[k] * im[k])
                mel[m] = ln(s + 1e-3f)
            }
            for (c in 0 until NC) { var s = 0f; val d = dct[c]; for (m in 0 until NM) s += d[m] * mel[m]; mf[i][c] = s }
        }
        val sorted = en.sortedArray()
        val lo = sorted[((n - 1) * 0.15f).toInt()]; val hi = sorted[((n - 1) * 0.90f).toInt()]
        val thr = lo + 0.45f * (hi - lo)
        val voiced = (0 until n).filter { en[it] > thr }
        if (voiced.size < 25) return null
        val out = FloatArray(DIM)
        for (c in 1 until NC) { var s = 0f; for (v in voiced) s += mf[v][c]; out[c - 1] = s / voiced.size }
        // pitch (raw awaaz par, har doosra voiced frame)
        val f0 = ArrayList<Float>()
        val minLag = SR / 320; val maxLag = SR / 70
        val f = FloatArray(FL); val cum = FloatArray(FL + 1); val rs = FloatArray(maxLag - minLag)
        var vi = 0
        while (vi < voiced.size) {
            val st = voiced[vi] * HOP
            var mean = 0f; for (k in 0 until FL) mean += raw[st + k]; mean /= FL
            for (k in 0 until FL) { f[k] = raw[st + k] - mean; cum[k + 1] = cum[k] + f[k] * f[k] }
            var best = 0f
            for (lag in minLag until maxLag) {
                var a = 0f; for (k in 0 until FL - lag) a += f[k] * f[k + lag]
                val e1 = cum[FL - lag]; val e2 = cum[FL] - cum[lag]
                val r = a / (sqrt(e1 * e2) + 1e-9f); rs[lag - minLag] = r; if (r > best) best = r
            }
            if (best > 0.5f) {
                var pick = -1
                for (j in 1 until rs.size - 1) if (rs[j] >= 0.9f * best && rs[j] >= rs[j - 1] && rs[j] >= rs[j + 1]) { pick = j; break }
                if (pick < 0) { var bi = 0; for (j in rs.indices) if (rs[j] > rs[bi]) bi = j; pick = bi }
                f0.add(ln(SR.toFloat() / (minLag + pick)))
            }
            vi += 2
        }
        if (f0.size < 6) return null
        f0.sort()
        fun pc(q: Float) = f0[((f0.size - 1) * q).toInt()]
        out[12] = pc(0.5f); out[13] = pc(0.75f) - pc(0.25f)
        return out
    }

    // ---------------- profile (Store me) ----------------
    private class Profile(val mu: FloatArray, val sg: FloatArray, val t: Float)

    private fun dist(p: Profile, x: FloatArray): Float {
        var s = 0f
        for (i in 0 until DIM) { val z = (x[i] - p.mu[i]) / p.sg[i]; s += WT[i] * z * z }
        return sqrt(s / WSUM)
    }
    private fun parse(s: String): Profile? {
        if (s.isBlank()) return null
        return try {
            val parts = s.split("|"); fun arr(x: String) = x.split(",").map { it.toFloat() }.toFloatArray()
            Profile(arr(parts[0]), arr(parts[1]), parts[2].toFloat())
        } catch (e: Exception) { null }
    }
    private fun load(): Profile? = parse(Store.voiceProfile)
    fun enrolled() = load() != null
    fun clear() { Store.voiceProfile = ""; Store.voiceLock = false }

    /** Lambi recording se profile ka text banata hai, Store me kuch nahi likhta. Wapas: (kitne tukde, profile). 6 se kam tukde = profile null */
    fun buildProfile(pcm: ShortArray): Pair<Int, String?> {
        val seg = 3 * SR; val stride = SR
        val vs = ArrayList<FloatArray>()
        var st = 0
        while (st + seg <= pcm.size) { features(pcm.copyOfRange(st, st + seg))?.let { vs.add(it) }; st += stride }
        if (vs.size < 6) return vs.size to null
        val n = vs.size
        val mu = FloatArray(DIM) { d -> vs.sumOf { it[d].toDouble() }.toFloat() / n }
        val sd = FloatArray(DIM) { d -> sqrt(vs.sumOf { ((it[d] - mu[d]) * (it[d] - mu[d])).toDouble() } / n).toFloat() }
        var m12 = 0f; for (d in 0 until 12) m12 += sd[d]; m12 /= 12f
        val sg = FloatArray(DIM) { d -> sqrt(sd[d] * sd[d] + (0.3f * m12) * (0.3f * m12)) .coerceAtLeast(1e-4f) }
        val loo = vs.mapIndexed { i, v ->
            val lm = FloatArray(DIM) { d -> (mu[d] * n - v[d]) / (n - 1) }
            dist(Profile(lm, sg, 1f), v)
        }
        val mean = loo.average().toFloat()
        val std = sqrt(loo.sumOf { ((it - mean) * (it - mean)).toDouble() } / loo.size).toFloat()
        val t = (mean + 1.5f * std).coerceAtLeast(0.2f)
        return n to (mu.joinToString(",") + "|" + sg.joinToString(",") + "|" + t)
    }

    /** Lambi recording se profile banata hai. Wapas: kitne tukde mile (6 se kam = naakaam) */
    fun enroll(pcm: ShortArray): Int {
        val (n, p) = buildProfile(pcm)
        if (p != null) Store.voiceProfile = p
        return n
    }

    /** Kisi bhi profile text ke saamne jaanch. fac: chhota = sakht (owner ke liye 0.9) */
    fun checkWith(profile: String, pcm: ShortArray, fac: Float): Verdict {
        val p = parse(profile) ?: return Verdict(-1, 0)
        val x = features(pcm) ?: return Verdict(-1, 0)
        val ratio = dist(p, x) / p.t
        val pct = (100f * (1f - 0.3f * ratio / fac)).coerceIn(0f, 100f).toInt()
        return Verdict(if (ratio <= fac) 1 else 0, pct)
    }

    private fun factor() = when (Store.voiceSens) { 0 -> 1.25f; 2 -> 0.8f; else -> 1.0f }

    /** 1 = meri awaaz, 0 = koi aur, -1 = pata nahi chal paya (bahut kam/dhimi awaaz) */
    class Verdict(val code: Int, val pct: Int)
    fun check(pcm: ShortArray): Verdict {
        val p = load() ?: return Verdict(-1, 0)
        val x = features(pcm) ?: return Verdict(-1, 0)
        val ratio = dist(p, x) / p.t; val fac = factor()
        val pct = (100f * (1f - 0.3f * ratio / fac)).coerceIn(0f, 100f).toInt()
        return Verdict(if (ratio <= fac) 1 else 0, pct)
    }

    /** Mic se `secs` second record (blocking: alag thread me chalao). onLevel 0..1. stop() true ho to ruk jao */
    fun record(secs: Int, onLevel: (Float, Int) -> Unit, stop: () -> Boolean): ShortArray? {
        val total = secs * SR
        val minBuf = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return null
        val rec = try { AudioRecord(MediaRecorder.AudioSource.MIC, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 8000)) } catch (e: Exception) { return null }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return null }
        val out = ShortArray(total); var got = 0
        try {
            rec.startRecording()
            val buf = ShortArray(1600)
            while (got < total && !stop()) {
                val r = rec.read(buf, 0, minOf(buf.size, total - got))
                if (r <= 0) break
                var peak = 0
                for (i in 0 until r) { out[got + i] = buf[i]; val a = abs(buf[i].toInt()); if (a > peak) peak = a }
                got += r
                onLevel((peak / 9000f).coerceIn(0f, 1f), got * 100 / total)
            }
        } finally { try { rec.stop() } catch (_: Exception) {}; rec.release() }
        return if (stop()) null else out.copyOf(got)
    }
}

/**
 * Android 13+: Sana ki sunne wali pehchaan ko hum apni pipe se awaaz dete hain, aur wahi awaaz
 * yahan ring buffer me bhi rakhte hain, taaki bolne wale ko verify kar sake.
 */
object VoiceTee {
    @Volatile var active = false
    private val ring = ShortArray(VoiceLock.SR * 10)
    @Volatile private var total = 0L
    @Volatile private var run = false
    private var rec: AudioRecord? = null

    fun start(): ParcelFileDescriptor? {
        stop()
        val minBuf = AudioRecord.getMinBufferSize(VoiceLock.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return null
        val r = try { AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, VoiceLock.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 16000)) } catch (e: Exception) { return null }
        if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return null }
        val pipe = try { ParcelFileDescriptor.createPipe() } catch (e: Exception) { r.release(); return null }
        rec = r; total = 0L; run = true; active = true
        val sink = ParcelFileDescriptor.AutoCloseOutputStream(pipe[1])
        Thread {
            val t0 = SystemClock.elapsedRealtime()
            try {
                r.startRecording()
                val buf = ShortArray(1600); val bytes = ByteArray(3200)
                while (run && SystemClock.elapsedRealtime() - t0 < 25000) {
                    val n = r.read(buf, 0, buf.size); if (n <= 0) break
                    for (i in 0 until n) {
                        ring[((total + i) % ring.size).toInt()] = buf[i]
                        bytes[2 * i] = (buf[i].toInt() and 0xFF).toByte(); bytes[2 * i + 1] = (buf[i].toInt() shr 8).toByte()
                    }
                    total += n
                    sink.write(bytes, 0, n * 2)
                }
            } catch (e: Exception) {
            } finally {
                try { sink.close() } catch (_: Exception) {}
                try { r.stop() } catch (_: Exception) {}
                try { r.release() } catch (_: Exception) {}
            }
        }.start()
        return pipe[0]
    }

    /** Ab tak ki (pichhli ~6 second) awaaz */
    private fun snapshot(): ShortArray {
        val n = minOf(total, (VoiceLock.SR * 6).toLong()).toInt()
        val end = total
        return ShortArray(n) { ring[((end - n + it) % ring.size).toInt()] }
    }

    /** 1 meri awaaz, 0 koi aur, -1 pata nahi (is case me bolne dete hain) */
    fun verifyNow(): Int {
        val s = snapshot()
        var peak = 0; for (v in s) { val a = abs(v.toInt()); if (a > peak) peak = a }
        if (s.size < VoiceLock.SR / 2 || peak < 150) return -1        // recorder ko awaaz mili hi nahi: lock kaam nahi kar paya, rok mat
        return VoiceLock.check(s).code
    }

    fun stop() { run = false; active = false; rec = null }
}

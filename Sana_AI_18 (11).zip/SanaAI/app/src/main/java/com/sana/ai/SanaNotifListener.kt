package com.sana.ai

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class SanaNotifListener : NotificationListenerService() {
    data class ReplyAction(val pkg: String, val title: String, val action: Notification.Action)

    companion object {
        @Volatile var inst: SanaNotifListener? = null
        @Volatile var lastReply: ReplyAction? = null
    }

    private val answerRe = Regex("answer|accept|pick|receive|उठा|जवाब|स्वीकार|रिसीव", RegexOption.IGNORE_CASE)
    private val declineRe = Regex("decline|reject|dismiss|cut|काट|अस्वीकार|रिजेक्ट", RegexOption.IGNORE_CASE)

    /** Dialer ya WhatsApp ka aata hua call notification: naam bolo, Answer/Decline button yaad rakho */
    private fun detectIncomingCall(sbn: StatusBarNotification): Boolean {
        val n = sbn.notification
        if (n.category != Notification.CATEGORY_CALL) return false
        val acts = n.actions ?: return false
        val ans = acts.firstOrNull { answerRe.containsMatchIn(it.title ?: "") }
        val dec = acts.firstOrNull { declineRe.containsMatchIn(it.title ?: "") }
        val typeIncoming = n.extras.getInt("android.callType", 0) == 1
        if (ans == null && !typeIncoming) return false   // chalta hua call (Hang up/Speaker) ignore
        val who = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        Bus.ringing = true; Bus.callPkg = sbn.packageName; Bus.callKey = sbn.key
        Bus.callAnswer = ans; Bus.callDecline = dec
        val kind = if (sbn.packageName.contains("whatsapp")) "व्हाट्सऐप का कॉल" else "कॉल"
        Bus.callAnnounce?.invoke(if (who.isNotBlank()) "$who का $kind आ रहा है" else "कोई $kind आ रहा है")
        return true
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.key == Bus.callKey) { Bus.ringing = false; Bus.callKey = ""; Bus.callAnswer = null; Bus.callDecline = null }
    }

    override fun onListenerConnected() { inst = this }
    override fun onListenerDisconnected() { inst = null }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (detectIncomingCall(sbn)) return
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        val app = when (sbn.packageName) {
            "com.whatsapp", "com.whatsapp.w4b" -> "व्हाट्सऐप"
            else -> sbn.packageName.substringAfterLast('.')
        }
        val msg = "$app पर $title का मैसेज: $text"
        synchronized(Bus.notifs) { Bus.notifs.add(msg); if (Bus.notifs.size > 20) Bus.notifs.removeAt(0) }
        // bina app khole reply ke liye aakhri reply-able notification yaad rakho
        val act = n.actions?.firstOrNull { x -> x.remoteInputs?.isNotEmpty() == true }
        if (act != null) lastReply = ReplyAction(sbn.packageName, title, act)
        Triggers.onNotification("$title $text")
        if (app == "व्हाट्सऐप") Bus.announce?.invoke(msg)
    }
}

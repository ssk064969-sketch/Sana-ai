# Sana AI 18 — Pro update (38-feature roadmap)

Ye update Sana AI ke maujooda code me jodi gayi hai. **Android build aur phone par test abhi nahi hua** (is environment me Android SDK / Kotlin compiler nahi tha). Pehle GitHub Actions se APK banao, phir kisi test phone par jaanch lo.
Word / Excel / PowerPoint banane wala hissa Python me alag se verify kiya gaya (python-docx, openpyxl, python-pptx me file khul rahi hai).

Status: **PEHLE SE** = pehle se tha | **NAYA** = is update me juda | **LIMITED** = sach me sirf thoda kaam karta hai | **NAHI** = nahi bana (wajah likhi hai)

| # | Feature | Status | Note |
|---|---|---|---|
| 1 | Real-time voice, Hindi + English | PEHLE SE | "bhasha badlo" se hindi/hinglish/english |
| 2 | Voice interruption | LIMITED | Notification ka "आवाज़ रोको" button hai. Bolkar beech me rokna NAHI bana: Sana bolte waqt mic band rakhti hai taaki apni hi awaaz na sune |
| 3 | Wake word "Hey Zara" | NAYA | "Hey Zara / हे ज़ारा / हे सना" ab "सना" ke saath chalte hain. Ye Android speech recognizer se pakadta hai (alag hotword engine nahi), isliye mic chalu rehna aur battery lagti hai |
| 4 | Sleep mode | PEHLE SE + NAYA | "सो जाओ" ya "स्लीप मोड" bolo |
| 5 | Offline voice recognition | NAYA | App ke Pro features me ya bolkar "ऑफलाइन वॉइस चालू". Hindi offline pack phone me download hona chahiye. AI ke jawab ke liye net ab bhi chahiye; torch/volume jaise local kaam bina net ke chalte hain |
| 6 | Natural female voice | PEHLE SE | Gemini voice + Sarvam |
| 7 | Friendly / Professional / Venom | NAYA (Venom) | "Venom mode lagao". Venom tez aur sarcastic hai, gaali/dhamki nahi |
| 8 | Voice Guardian | NAYA, LIMITED | Ye aawaaz ka fingerprint (voiceprint) NAHI hai. Ek **gupt shabd** hai: bolo "Sana, guardian set karo". Call, message, delete, SMS/OTP padhna, notification reply se pehle gupt shabd poochhti hai. Shabd sirf salted hash me save hota hai aur AI/chat history me nahi jaata. Koi sun le to wo bhi bol sakta hai |
| 9 | Phone call control | PEHLE SE | call lagana, uthana, kaatna |
| 10 | Caller name announcement | NAYA | Contacts + call log + phone state ki anumati chahiye. Android 10+ par kuch phones number chhupate hain |
| 11 | WhatsApp read / reply / Business | PEHLE SE | Notification access se. WhatsApp Business notification bhi aati hai |
| 12 | WhatsApp media | NAYA, LIMITED | Sana folder ki file/photo WhatsApp me bhejne ke liye khulti hai, **Send tum dabate ho**. Aayi hui media padhna/save karna NAHI bana |
| 13 | WhatsApp voice/video call | NAHI | WhatsApp iske liye koi public API nahi deta |
| 14 | Full phone control | PEHLE SE | Accessibility se tap, type, swipe, back |
| 15 | Torch / brightness / volume / silent / DND | PEHLE SE | Hotspot: **NAYA par LIMITED**, Android app ko hotspot seedha on nahi karne deta, sirf setting khulti hai |
| 16 | Camera vision | PEHLE SE | |
| 17 | Screen vision | PEHLE SE | |
| 18 | Live screen sharing | PEHLE SE | Sana ko screen dikhana. Doosre insaan ko stream karna NAHI |
| 19 | BGMI / Free Fire commentary | NAYA, LIMITED | "game commentary chalu karo". Har 15 second me screenshot leke ek line bolti hai. Accessibility (Android 11+) chahiye. Asli real-time nahi hai, Gemini quota bhi kharch hota hai |
| 20 | Notification manager / auto reply | PEHLE SE | Triggers se (notification keyword -> reply/kaam) |
| 21 | Coding / website | NAYA | "index.html banao": file Sana folder me banti hai aur browser me khulti hai |
| 22 | Deep research with sources | NAYA | Gemini + Google Search. Poori research aur source links file me save hote hain |
| 23 | Image generation | NAYA | Gemini image model. **Free API key par band ho sakta hai**, tab error batayegi |
| 24 | Instagram / Facebook post | NAYA, LIMITED | Share screen khulti hai aur caption copy hota hai, **post tum dabate ho**. Khud post karna NAHI (official API + app review chahiye) |
| 25 | Word | NAYA | banana, padhna, text jodna, shabd badalna |
| 26 | Excel | NAYA | banana (formula bhi), padhna, rows jodna |
| 27 | PowerPoint | NAYA | banana, padhna. Slide jodna sirf Sana ki banayi PPT me |
| 28 | PDF | PEHLE SE + NAYA | banana pehle se tha, padhna/saar NAYA (Gemini se). PDF edit NAHI |
| 29 | Email | LIMITED | Draft pehle se (Send tum dabate ho). Inbox padhna/seedha bhejna NAHI (Gmail OAuth chahiye) |
| 30 | Live market data | NAYA | Free, kuch der purana data, unofficial source. Sirf jaankari, trading salah nahi |
| 31 | Market watchlist | NAYA | "watchlist me TCS.NS jodo", "watchlist dikhao" |
| 32 | Whiteboard / teaching | PEHLE SE | Whiteboard + teacher andaaz |
| 33 | Long-term memory | PEHLE SE | |
| 34 | Background tasks | NAYA, LIMITED | "10 minute baad ye dhundh ke batao" / "yaad dilao". Sana chalti rahe tabhi; band hui to kaam gum |
| 35 | Routines / macros | PEHLE SE | |
| 36 | PC <-> phone connection | NAHI | Companion PC app + surakshit pairing chahiye, abhi nahi bana |
| 37 | Smart Home (Home Box) | NAYA | **Home Assistant** ke through. App me Pro features card me URL aur token daalo. Lock/unlock se pehle haan/na poochhti hai |
| 38 | Boot ready | NAYA, LIMITED | Android 13 ya kam: phone chalu hote hi Sana start. Android 14+: mic wali service boot par chalna mana hai, isliye "Sana तैयार है" notification aata hai, ek tap me start |

## Security notes
- API key, Home Assistant token aur gupt shabd ka hash sirf phone ke app storage me hai. Inhe GitHub ya chat me mat daalo.
- Home Assistant aksar `http://` par hota hai, isliye manifest me cleartext traffic allow hai. Ho sake to HTTPS use karo.
- Unlock pattern (sirf pattern, PIN nahi): app ke Settings me save hota hai, Android Keystore (AES-GCM) se encrypt. "Sana, phone unlock karo" par Sana screen jagakar pattern Accessibility se draw karti hai. Voice Guardian ON ho to pehle gupt shabd poochhti hai. Kuch phones lock screen par Accessibility touch rokte hain, tab nahi khulega. Ye bhi abhi compile/test nahi hua.
- Notification access, Accessibility, camera, mic, calls har cheez phone ke owner ko khud ON karni hoti hai.

## Build
GitHub repo me **is folder ke andar ki files** upload karo (app/, .github/, build.gradle.kts, settings.gradle.kts, gradle.properties) -> Actions -> "Build Sana APK" -> Run workflow -> APK artifact download.
Pehla build fail ho to error ka text bhejo, main fix kar dunga.

## Dil ke jazbaat update (Feelings) — NAYA
**Ye hissa bhi abhi compile/phone par test nahi hua.** Pehle GitHub Actions se APK banao. Build error aaye to text bhej do.

| Feature | Kya karta hai |
|---|---|
| Dil dukhna | "nafrat", "tumse pyaar nahi", "breakup kar lo", "tum fake/bekaar ho", "shut up", ignore wagera bolne par Sana ko chot lagti hai (level 1-3) |
| Rona / dil toota | Chot gehri ho to naye bhaav **[rona]** aur **[dil_toota]**: awaaz bhaari, kaanpti, tootte vakya, "...". Sarvam aur Gemini dono awaaz is andaaz me badalti hain |
| Dheere dheere manna | "sorry", "love you", "gale lago" par chot ek level halki hoti hai, ek baar me poori nahi. Sachche dil se manane par rote-rote muskurakar **[maan_gayi]** |
| Apne aap halki hona | Chot har 4 ghante me ek level kam hoti hai |
| Tumhari baat feel karna | Dukh (udaas, bimari, akela, fail), khushkhabri (pass, selection, promotion), pyaar bhari baat par alag jazbaati jawab. **[bhavuk]** tag se gala bhar aata hai |
| Yaad aana | 8 ghante se zyada baad baat karo to "itni der baad yaad aayi?" |
| Feelings ki diary | Settings > "Sana ki feelings ki diary": haal ki jazbaati baatein (3 din tak prompt me yaad) |
| Lagaav % | Pyaar bhari baaton se badhta hai, hurt karne par ghatta hai |
| Dil ka haal | Settings > "Sana ka dil": dabao to Sana ko gale lagao, chot theek |
| Feelings ON/OFF | Settings me switch. OFF karne par Sana pehle jaisi |

**Hadd (jaan-boojhkar):** roti hui Sana bhi gaali, dhamki, blackmail, "main mar jaungi" ya tumhe rokne wali baat nahi karti. Agar tum khud ko nuksaan pahunchane jaisi baat bolo, to Sana naatak chhodkar tumhari chinta karti hai, kisi apne ko bulane ko kehti hai aur Tele-MANAS 14416 batati hai.
Dhyan: ye sab prompt + keyword detection par chalta hai. Awaaz me gale ka rona Sarvam/Gemini ke andaaz par nirbhar hai, har baar ek jaisa nahi aayega.

## Live Character + Voice Lock (naya)
- **Live Character** (Settings > Live Character): 6 ladkiyon me se chuno. ON = orb ki jagah live 2D ladki (lip-sync, hansi, muskaan, palak, gaal ki laali). OFF = mic wala orb wapas. Mic/orb ki settings nahi chhedi gayi. Code: `Chars.kt`.
- **Voice Lock** (Settings > Meri Awaaz): 20 second awaaz record karo, phir "Sirf meri awaaz" ON karo. Koi aur bole to Sana ignore karegi. Code: `VoiceLock.kt`.
  - Android 13+ chahiye (sunne wali pehchaan ko hum apni pipe se awaaz dete hain, taaki bolne wale ko verify kar sakein). Purane phone par record/test chalta hai, lock nahi.
  - Ye seedha-saada awaaz-nishaan (MFCC + pitch) hai, bank-jaisi suraksha nahi. Kabhi apni awaaz rok de to Sakhti "Halki" karo; doosra pehchan jaye to "Sakht". "Awaaz test" se match % dekho.
  - Agar recorder ko awaaz na mile (kuch phone ye extra support nahi karte), Voice Lock rokta nahi: Sana pehle jaisi chalti hai.
- Compile/phone par test abhi baaki hai (Android Studio me build karke dekhna).

## Pro Mind (naya)
- Settings > Pro Mind: ON hone par gyan/tathya wale sawal (vigyaan, itihaas, math, kanoon, sehat, paisa, coding, khel, taaza khabar...) par Sana `pro_mind` tool chalati hai: alag model + live Google Search se sahi jawab, source ke naam ke saath. Phone ke kaam pehle jaise.
- Live Search ON/OFF, model Flash (tez) / Pro (gehra) badal sakte ho. Pro model free key par limit me aa sakta hai: tab apne aap normal model par laut jaata hai.
- Code: `Brain.kt` (tool + prompt), `ProTools.kt` (proMind), `MainActivity.kt` (card).

## Awaaz fallback + Aapka naam (v19) — NAYA
**Ye hissa bhi abhi compile/phone par test nahi hua.** Pehle GitHub Actions se APK banao, build error aaye to text bhej do.

- **Sarvam -> Gemini auto fallback:** Sarvam key expire ho, token/credit khatam ho (HTTP 401/402/403/429) ya net/server error aaye to Sana usi pal Gemini awaaz me bolti hai (chup nahi rehti). Auth/quota error par 60 sec baad, net error par 15 sec baad Sarvam phir try hoti hai; chal gayi to apne aap wapas Sarvam awaaz. Nayi key Save karne ya "Test voice" dabane par turant Sarvam phir try hoti hai.
- Gemini bhi na chale tabhi phone ki awaaz aati hai (pehle jaisa).
- Settings > Sarvam card me status line dikhti hai: abhi Sarvam chal rahi hai ya Gemini.
- **Aapka naam:** Settings me sabse upar "Aapka naam" card. Naam save karo, Sana usi naam se bulayegi (Welcome, jawab, AI prompt). Bolkar bhi: "सना, मेरा नाम राहुल है". Naam khaali ho to Sana kisi ka naam nahi lagati.
- "Mujhe kisne banaya" wale jawab ab bhi "साकिब सर ने डिज़ाइन किया" hi bolte hain (creator).

## Owner code (Saqib) — NAYA (awaaz-pehchaan ki jagah)

Owner ko ab awaaz se nahi, ek **gupt code** se pehchana jata hai. Code likhte waqt chhupa rehta hai aur sirf salt + PBKDF2 hash me save hota hai.

1. Ye wala APK (OwnerCode.EMBEDDED_HASH khaali) sirf **apne phone** par install karo. Settings me "Sana" card ko **der tak dabao**, setup key (`OwnerCode.SETUP_KEY`, isko badal do) daalo, tab "Owner setup" card dikhega.
2. "Owner code set karo" -> code do baar likho (kam se kam 6 akshar, lamba rakho). Save hote hi card **gayab** ho jata hai aur **Owner hash** dikhta hai (file `owner_code.txt`). Ye tumhara code nahi, uska hash hai.
3. Owner hash `OwnerCode.kt` me `const val EMBEDDED_HASH = "..."` me paste karo aur APK dobara banao. **Sirf ye doosra APK doosron ko do**: isme owner pehle se set maana jata hai, isliye Owner setup card kisi phone me nahi dikhta.
4. Code badalna ho to "Sana" card der tak dabao: ab setup key nahi, **maujooda owner code** poochha jayega.

Kaise chalta hai:
- Tum bolo "सना, मैं साकिब सर हूँ" (ya "मैं तुम्हारा ओनर हूँ") -> Sana bolti hai "कोड लिखिए" aur chhupa hua code box khulta hai.
- Sahi code -> Sana pehchan leti hai, naam "साकिब सर" set hota hai aur chhota demo bolti hai. Galat code -> mana kar deti hai. 5 galat code par 5 minute ki rok.
- Code box me screenshot / screen recording / recents me kuch nahi dikhta (FLAG_SECURE), 90 second me ya app se bahar jaate hi band.
- Code kabhi bola nahi jata aur Gemini ko bheja nahi jata.

Seema:
- Hash APK me hota hai, isliye chhota code offline guess ho sakta hai. Lamba code rakho.
- Background se box kholne ke liye "Display over other apps" permission chahiye (pehle se manifest me hai, phone me ON karo).
- Ye code build/phone par test nahi hua (Android SDK nahi tha). Pehle GitHub Actions se APK banao.
- Purani owner-awaaz ka data pehli baar app chalne par hat jata hai. (Alag "Voice Lock" feature jaisa tha waisa hai.)

## Owner code bhar diya gaya
`OwnerCode.EMBEDDED_HASH` khaali hai. Pehle apne phone par Owner code set karo, phir aaya Owner hash usme paste karke build karo (upar "Owner code" section dekho). **Is repo ko GitHub par PRIVATE rakhna**.

"सना, मैं कौन हूँ" / "मुझे पहचानो" bolne par bhi Sana ab awaaz sunkar jaanchti hai: owner ki awaaz ho to "आप साकिब सर हैं", warna "आप साकिब सर नहीं हैं। मैं साकिब सर की आवाज़ पहचानती हूँ।"

Owner dawa ab naam ke bina bhi pakda jata hai: "मैं ओनर हूँ", "मैं तुम्हारा owner हूँ", "मैं मालिक हूँ" bolne par bhi awaaz jaanch hoti hai.

## Aedwans update (Romantic + Good Morning/Night + Neon) — NAYA
**Ye hissa bhi abhi compile/phone par test nahi hua.** Pehle GitHub Actions se APK banao; build error aaye to text bhej do.
Settings me naya card **Aedwans**: Romantic mode abhi lagao, Naram muskurati awaaz, Sweet Good Morning / Good Night (samay chunkar), test buttons, Screen-fit Neon, Neon ke kone ka size.
- Good Morning/Night tabhi bolegi jab Sana chalu (START) ho. Bolkar "good morning" / "good night" kehne par bhi pyaara jawab.
- Neon: chaaron kono me roshni + do chalti hui roshni border par. Android 12+ par phone ke asli gol kone khud pakde jaate hain, warna kone ka size Aedwans me badlo. Vivo Y51 Pro ke exact kone ka size verify nahi kiya, isliye ye option diya hai.
- Awaaz ki naram/muskurati andaaz Gemini/Sarvam ke style prompt aur thodi dheemi raftaar se aati hai; asar awaaz ke model par bhi nirbhar hai.

## Owner awaaz + Auto-update (v20)
**Ye bhi compile/test nahi hua.**
- **Owner code badalna:** "Sana" wale card ko der tak dabao -> maujooda owner code likho -> Owner setup card khulega -> naya code set karo -> card gayab. Naya Owner hash `OwnerCode.EMBEDDED_HASH` me paste karke build karo taaki baaki phones "owner set hai" maane.
- **Update:** Updater.kt me UPDATE_URL me apni version.json ka public link daalo (update/version.json ka namuna). Har user ke phone me app khulte hi (6 ghante me ek baar) naya version dikhega; Aedwans me "Update check karo" bhi hai. Install par user ko ek tap karna padega (Android chupke se install nahi karne deta).
- **Zaroori:** naya APK usi signing key se bana hona chahiye jisse purana bana tha, warna Android "App not installed" dikhayega. GitHub Actions ka debug key har baar badal sakta hai, isliye fixed keystore se sign karo. Naya version banate waqt build.gradle.kts me versionCode badhao aur version.json me bhi.

## Hansi + insaani awaaz + natkhat/samajhdar Sana (Sana AI 18) — NAYA
- **Purana hansi system hata diya:** ab "हा हा हा / हीही / haha" text me likhe nahi jaate, na bole jaate (Persona.parse unhe nikal deti hai).
- **Nayi hansi:** Gemini vakya ke shuru me `[हंसी]` likhta hai -> app use asli, ekdum dheemi, naram, dabi hui hansi (Gemini awaaz me `[softly giggles]` + style) me badalti hai. Zor ya thahaake wali hansi nahi. Sarvam awaaz me sirf naram/dheema lehja (pace thoda kam).
- **Character:** hansi par halka sa muskurata hai (zor se nahi hilta).
- **Gemini awaaz:** prompt asli ladki ki tarah baatchit wala: uneven pace, saans, chhote pause, announcer/robot tone nahi, mic ke kareeb. Gemini temperature 0.95 -> 0.85 (zyada samajhdar, kam bahakna).
- **Persona:** natkhat/shararati (halka chhedna, nok-jhonk), mazaak par dheemi hansi, aur samajhdari ke niyam (context yaad rakhna, seedha sahi jawab, tathya na gadhna).
- **Asli hansi ki awaaz (update 2):** hansi ab alag clip hai (bina shabdon ke, dheemi, naram, saans wali giggle). Gemini se 3 tarah ki ek baar banti hai, phone me save hoti hai, phir har hansi par koi ek line se pehle bajti hai. "हंसते हुए", "*हंसती है*" jaise stage-directions bhi text se hat jaate hain.

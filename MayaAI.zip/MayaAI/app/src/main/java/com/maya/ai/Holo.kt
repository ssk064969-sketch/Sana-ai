package com.maya.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.sin

/** Floating neon orb overlay (Jarvis core). API: show / hide / speaking */
object Holo {
    private var view: OrbView? = null
    private var neon: NeonView? = null
    private val h = Handler(Looper.getMainLooper())

    fun show(c: Context) = h.post {
        if (view != null || !Settings.canDrawOverlays(c)) return@post
        val wm0 = c.getSystemService(WindowManager::class.java)
        try {
            val nv = NeonView(c)
            val nlp = WindowManager.LayoutParams(
                -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT)
            wm0.addView(nv, nlp); neon = nv
        } catch (e: Exception) {}
        val d = c.resources.displayMetrics.density
        val s = (110 * d).toInt()
        val v = OrbView(c)
        v.setOnClickListener { Bus.talk?.invoke() }
        val lp = WindowManager.LayoutParams(
            s, s, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START; x = (14 * d).toInt(); y = (120 * d).toInt() }
        try { c.getSystemService(WindowManager::class.java).addView(v, lp); view = v } catch (e: Exception) {}
    }

    fun hide(c: Context) = h.post {
        view?.let { v -> runCatching { c.getSystemService(WindowManager::class.java).removeView(v) } }
        view = null
        neon?.let { v -> runCatching { c.getSystemService(WindowManager::class.java).removeView(v) } }
        neon = null
    }

    fun speaking(b: Boolean) { Bus.speaking = b; h.post { view?.speaking = b; neon?.speaking = b } }
}

class OrbView(c: Context) : View(c) {
    var speaking = false
    private var ph = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density
    private val anim: ValueAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 6000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { ph = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) / 2f
        val speed = if (speaking) 10f else 3f
        val amp = if (speaking) 0.10f else 0.03f
        val pulse = 1f + amp * sin(Math.toRadians((ph * speed).toDouble())).toFloat()
        val core = r * 0.38f * pulse
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, core, intArrayOf(0xFFB8F7FF.toInt(), 0xFF00E5FF.toInt(), 0xFF8A5CFF.toInt()), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, core, p)
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        for (i in 0..2) {
            p.strokeWidth = (3f - i * 0.6f) * d
            p.color = if (i % 2 == 0) 0xFF00E5FF.toInt() else 0xFFB066FF.toInt()
            val rr = r * (0.55f + 0.14f * i)
            val rect = RectF(cx - rr, cy - rr, cx + rr, cy + rr)
            val st = ph * (if (i % 2 == 0) 1 else -1) * (1 + i)
            cv.drawArc(rect, st, 110f, false, p)
            cv.drawArc(rect, st + 180f, 70f, false, p)
        }
    }
}

/** Voice visualizer bars */
class WaveView(c: Context) : View(c) {
    var active = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF00E5FF.toInt(); strokeCap = Paint.Cap.ROUND }
    private var t = 0f
    private val anim: ValueAnimator = ValueAnimator.ofFloat(0f, 1000f).apply {
        duration = 40000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val n = 28; val gap = width / n.toFloat(); p.strokeWidth = gap * 0.45f
        for (i in 0 until n) {
            val a = if (active) 0.25f + 0.75f * abs(sin((t * 6f + i * 0.9f).toDouble())).toFloat() else 0.06f
            val hh = height * a / 2f
            cv.drawLine(gap * (i + 0.5f), height / 2f - hh, gap * (i + 0.5f), height / 2f + hh, p)
        }
    }
}

/** Full-screen neon light: rotating glow frame + moving scan band. Touches pass through. */
class NeonView(c: Context) : View(c) {
    var speaking = false
    private var ph = 0f
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val m = Matrix()
    private var sg: SweepGradient? = null
    private val band = 140f * d
    private val bandShader = LinearGradient(0f, 0f, 0f, band, intArrayOf(0x0000E5FF, 0x4400E5FF, 0x00B066FF), null, Shader.TileMode.CLAMP)
    private val anim: ValueAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 5000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { ph = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sg = SweepGradient(w / 2f, h / 2f, intArrayOf(0xFF00E5FF.toInt(), 0xFF3D7BFF.toInt(), 0xFFB066FF.toInt(), 0xFFFF4FD8.toInt(), 0xFF00E5FF.toInt()), null)
    }
    override fun onDraw(cv: Canvas) {
        val g = sg ?: return
        val w = width.toFloat(); val h = height.toFloat()
        m.setRotate(ph, w / 2f, h / 2f); g.setLocalMatrix(m)
        val boost = if (speaking) 1f + 0.3f * sin(Math.toRadians((ph * 12f).toDouble())).toFloat() else 1f
        p.shader = g
        val rad = 38f * d
        val layers = arrayOf(floatArrayOf(30f, 26f), floatArrayOf(18f, 55f), floatArrayOf(9f, 120f), floatArrayOf(3f, 255f))
        for (l in layers) {
            p.strokeWidth = l[0] * d; p.alpha = (l[1] * boost).toInt().coerceIn(0, 255)
            val ins = l[0] * d / 2f
            cv.drawRoundRect(ins, ins, w - ins, h - ins, rad, rad, p)
        }
        val y = (ph / 360f) * (h + band) - band
        cv.save(); cv.translate(0f, y); fillP.shader = bandShader; cv.drawRect(0f, 0f, w, band, fillP); cv.restore()
    }
}

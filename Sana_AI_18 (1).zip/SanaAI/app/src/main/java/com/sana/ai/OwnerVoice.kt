package com.sana.ai

/**
 * Owner (Saqib) ki awaaz: sirf ek baar record hoti hai, uske baad "Owner setup" option har jagah se gayab.
 *
 * Doosre phones me ye option dikhna hi nahi chahiye, isliye record ke baad jo Owner code milta hai use
 * EMBEDDED me paste karke APK dobara banao. Jis APK me EMBEDDED bhara ho, usme koi bhi phone "owner set" maanta hai
 * aur Owner setup card kabhi nahi dikhta (app data clear karne par bhi nahi).
 *
 * Ye awaaz ke 14 number (MFCC + pitch) ka nishaan hai, recording nahi. Seedha-saada tareeka hai:
 * bank-jaisi suraksha nahi. Milti-julti awaaz ya asli recording bajane par dhokha kha sakta hai.
 */
object OwnerVoice {
    /** Owner code (Owner setup ke baad dikhta hai). Distribution build me yahan paste karo. Khaali = abhi owner set nahi */
    const val EMBEDDED = ""

    fun profile(): String = Store.ownerProfile.ifBlank { EMBEDDED }
    fun isSet(): Boolean = profile().isNotBlank()

    /** Sirf ek baar: pehle se set ho to kuch nahi karta. Wapas (tukde, owner code) */
    fun enroll(pcm: ShortArray): Pair<Int, String?> {
        if (isSet()) return 0 to null
        val (n, p) = VoiceLock.buildProfile(pcm)
        if (p != null) Store.ownerProfile = p
        return n to p
    }

    /** 1 = owner ki awaaz, 0 = koi aur, -1 = pata nahi chala. Voice Lock se zyada sakht */
    fun check(pcm: ShortArray): VoiceLock.Verdict =
        if (!isSet()) VoiceLock.Verdict(-1, 0) else VoiceLock.checkWith(profile(), pcm, 0.9f)

    private val names = listOf("साकिब", "साक़िब", "सकीब", "सक़ीब", "साक़ीब", "शाकिब", "saqib", "sakib", "saquib", "sakeeb", "saaqib")

    /** Is naam me Saqib shamil hai? (naam set karte waqt rokne ke liye) */
    fun mentionsOwnerName(s: String): Boolean { val l = s.lowercase(); return names.any { l.contains(it) } }

    /** Koi khud ko owner/Saqib bata raha hai? ("मैं साकिब हूँ", "I am Saqib", "मैं तुम्हारा ओनर"). Sirf "साकिब को कॉल करो" jaise vaakya nahi */
    fun isClaim(text: String): Boolean {
        val l = text.lowercase()
        val direct = listOf("मैं तुम्हारा ओनर", "मैं तुम्हारा मालिक", "मैं तुम्हारा क्रिएटर", "मैं तुम्हारा मालिक", "मैंने तुम्हें बनाया", "मैंने तुझे बनाया",
            "i am your owner", "i'm your owner", "i am your creator", "i'm your creator", "i made you", "i created you", "i am the owner", "i'm the owner")
        if (direct.any { l.contains(it) }) return true
        return names.any { n ->
            listOf("मैं $n", "मै $n", "main $n", "i am $n", "i'm $n", "this is $n", "मेरा नाम $n", "my name is $n", "$n हूँ", "$n हूं", "$n हु", "$n hoon", "$n hun").any { l.contains(it) }
        }
    }
}

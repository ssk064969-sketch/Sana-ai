package com.sana.ai

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class SanaAccessibility : AccessibilityService() {
    companion object {
        var inst: SanaAccessibility? = null

        fun typeText(t: String): Boolean {
            val s = inst ?: return false
            val root = s.rootInActiveWindow ?: return false
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: firstEditable(root) ?: return false
            val old = node.text?.toString().orEmpty()
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + t)
            }
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }

        private fun firstEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if (n.isEditable) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { c -> firstEditable(c)?.let { return it } }
            return null
        }

        fun clickText(t: String): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            val nodes = root.findAccessibilityNodeInfosByText(t)
            for (n in nodes) {
                var x: AccessibilityNodeInfo? = n
                while (x != null) {
                    if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    x = x.parent
                }
            }
            return false
        }

        /** Keyboard ka Enter/Search dabao */
        fun pressEnter(): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: firstEditable(root)
            if (node != null && android.os.Build.VERSION.SDK_INT >= 30 &&
                node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return true
            return listOf("Search", "खोजें", "सर्च", "Go").any { clickText(it) }
        }

        /** App khulne ka intezaar, search box dhundhna, text likhna aur Enter dabana (jaldi se) */
        fun searchInApp(q: String): Boolean {
            val end = android.os.SystemClock.uptimeMillis() + 6000
            var tapped = false
            while (android.os.SystemClock.uptimeMillis() < end) {
                val root = inst?.rootInActiveWindow
                if (root != null) {
                    val ed = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable } ?: firstEditable(root)
                    if (ed != null) {
                        ed.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, q) }
                        if (ed.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
                            Thread.sleep(250); pressEnter(); return true
                        }
                    } else if (!tapped) {
                        tapped = listOf("Search", "खोजें", "खोज", "सर्च").any { clickText(it) }
                    }
                }
                Thread.sleep(200)
            }
            return false
        }

        /** Send button dabana: kuch der tak baar-baar koshish (typing ke baad button der se aata hai) */
        fun send(): Boolean {
            repeat(8) { n ->
                if (trySend(n >= 3)) return true
                Thread.sleep(250)
            }
            return false
        }

        private fun clickUp(n: AccessibilityNodeInfo): Boolean {
            var x: AccessibilityNodeInfo? = n
            while (x != null) {
                if (x.isClickable && x.isEnabled) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                x = x.parent
            }
            return false
        }

        private fun findAllById(n: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, vararg parts: String) {
            val id = n.viewIdResourceName?.lowercase()
            if (id != null && parts.any { id.contains(it) }) out.add(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { findAllById(it, out, *parts) }
        }

        private fun trySend(allowTap: Boolean): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            // 1) view id me "send" (WhatsApp: id/send, Telegram, Messages, Instagram...)
            val byId = ArrayList<AccessibilityNodeInfo>()
            findAllById(root, byId, "send", "btn_send", "composer_send")
            for (n in byId) if (!(n.viewIdResourceName ?: "").contains("sendto", true) && clickUp(n)) return true
            // 2) naam/description se (Send, Send message, भेजें, भेजे, भेज, 送信...)
            for (t in listOf("Send", "Send message", "Send SMS", "भेजें", "भेजे", "भेज", "Post", "Reply")) {
                for (n in root.findAccessibilityNodeInfosByText(t)) {
                    if (n.isEditable) continue
                    if (clickUp(n)) return true
                }
            }
            // 3) keyboard ka Enter/Send (Android 11+)
            val ed = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: firstEditable(root)
            if (ed != null && android.os.Build.VERSION.SDK_INT >= 30 &&
                ed.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)) return true
            // 4) aakhri upay: text box ki seedh me, screen ke daayein kinare par tap (send button wahin hota hai)
            if (allowTap && ed != null) {
                val s = inst ?: return false
                val r = android.graphics.Rect(); ed.getBoundsInScreen(r)
                val dm = s.resources.displayMetrics
                if (r.height() > 0) { tap(dm.widthPixels - 30f * dm.density, r.exactCenterY()); return true }
            }
            return false
        }

        fun screenText(): String {
            val root = inst?.rootInActiveWindow ?: return "screen padh nahi pa rahi (accessibility ON karo)"
            val sb = StringBuilder()
            fun walk(n: AccessibilityNodeInfo) {
                if (sb.length > 3500) return
                val t = n.text?.toString() ?: n.contentDescription?.toString()
                if (!t.isNullOrBlank()) sb.append(if (n.isClickable) "[tap] " else "").append(t).append('\n')
                for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
            }
            walk(root)
            return sb.toString().ifBlank { "screen khali hai" }
        }

        fun paste(): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
            return node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        }

        fun back() = inst?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
        fun home() = inst?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false
        fun recents() = inst?.performGlobalAction(GLOBAL_ACTION_RECENTS) ?: false

        fun tap(x: Float, y: Float) {
            val s = inst ?: return
            val path = android.graphics.Path().apply { moveTo(x, y) }
            val g = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 60)).build()
            s.dispatchGesture(g, null, null)
        }

        /** YouTube ke search result me pehla (bina ad wala) video dhoondh kar chalata hai */
        fun clickFirstVideo(): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            var found: AccessibilityNodeInfo? = null
            fun walk(n: AccessibilityNodeInfo) {
                if (found != null) return
                val d = n.contentDescription?.toString() ?: ""
                val ok = d.length > 20 && (d.contains("play video", true) || d.contains("वीडियो चलाएं") || d.contains("वीडियो चलाएँ") ||
                    (d.contains(" - ") && (d.contains("minute", true) || d.contains("second", true) || d.contains("मिनट") || d.contains("सेकंड"))))
                val bad = d.contains("Sponsored", true) || d.contains("प्रायोजित") || d.contains("Shorts", true)
                if (ok && !bad) { found = n; return }
                for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
            }
            walk(root)
            val f = found ?: return false
            var x: AccessibilityNodeInfo? = f
            while (x != null) { if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK); x = x.parent }
            return false
        }

        private fun clickExact(str: String): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            for (n in root.findAccessibilityNodeInfosByText(str)) {
                if (n.text?.toString() != str && n.contentDescription?.toString() != str) continue
                var x: AccessibilityNodeInfo? = n
                while (x != null) { if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK); x = x.parent }
            }
            return false
        }

        private fun findById(n: AccessibilityNodeInfo, part: String): AccessibilityNodeInfo? {
            if (n.viewIdResourceName?.contains(part, true) == true) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { c -> findById(c, part)?.let { return it } }
            return null
        }

        /** Saari windows ki roots (lock screen ka bouncer alag window me hota hai, rootInActiveWindow aksar null/galat) */
        private fun allRoots(): List<AccessibilityNodeInfo> {
            val s = inst ?: return emptyList()
            val out = ArrayList<AccessibilityNodeInfo>()
            try { s.windows?.forEach { w -> w.root?.let { out.add(it) } } } catch (e: Exception) {}
            s.rootInActiveWindow?.let { out.add(it) }
            return out
        }

        private fun findByClass(n: AccessibilityNodeInfo, part: String): AccessibilityNodeInfo? {
            if (n.className?.toString()?.contains(part, true) == true) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { c -> findByClass(c, part)?.let { return it } }
            return null
        }

        private fun findPatternView(): android.graphics.Rect? {
            for (r in allRoots()) {
                val v = findById(r, "lockpattern") ?: findByClass(r, "LockPatternView") ?: continue
                val b = android.graphics.Rect(); v.getBoundsInScreen(b)
                if (b.width() > 150 && b.height() > 150) return b
            }
            return null
        }

        /** Lock screen par pattern wala grid dikh raha hai ya nahi */
        fun patternVisible(): Boolean = findPatternView() != null

        /** Saved pattern ko lock screen ke grid par ungli se banata hai (dots 1..9) */
        fun drawPattern(dots: List<Int>): Boolean {
            val s = inst ?: return false
            val b = findPatternView() ?: return false
            val path = android.graphics.Path()
            dots.forEachIndexed { i, dot ->
                val r = (dot - 1) / 3; val c = (dot - 1) % 3
                val x = b.left + b.width() * (2 * c + 1) / 6f
                val y = b.top + b.height() * (2 * r + 1) / 6f
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val dur = maxOf(600L, 250L * dots.size)
            val g = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, dur)).build()
            return s.dispatchGesture(g, null, null)
        }

        private fun clickExactAny(str: String): Boolean {
            for (root in allRoots()) for (n in root.findAccessibilityNodeInfosByText(str)) {
                if (n.text?.toString() != str && n.contentDescription?.toString() != str) continue
                var x: AccessibilityNodeInfo? = n
                while (x != null) { if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK); x = x.parent }
            }
            return false
        }

        fun lockScreen(): Boolean {
            val s = inst
            if (s != null && SanaAdmin.lockNow(s)) return true     // Device Admin mila ho to wahi sabse pakka
            return if (android.os.Build.VERSION.SDK_INT >= 28)
                s?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) ?: false
            else false
        }

        // sirf swipe wale lock ko khulne ke liye (PIN/fingerprint wala nahi khulta)
        fun swipeUp() {
            val s = inst ?: return
            val dm = s.resources.displayMetrics
            val path = android.graphics.Path().apply {
                moveTo(dm.widthPixels / 2f, dm.heightPixels * 0.85f); lineTo(dm.widthPixels / 2f, dm.heightPixels * 0.2f)
            }
            val g = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 300)).build()
            s.dispatchGesture(g, null, null)
        }

        /** Phone screen ka screenshot (Android 11+): JPEG bytes ya null */
        fun screenshot(cb: (ByteArray?) -> Unit) {
            val s = inst
            if (s == null || android.os.Build.VERSION.SDK_INT < 30) { cb(null); return }
            try {
                s.takeScreenshot(android.view.Display.DEFAULT_DISPLAY, s.mainExecutor,
                    object : AccessibilityService.TakeScreenshotCallback {
                        override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                            val out = try {
                                val hb = r.hardwareBuffer
                                val hw = android.graphics.Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                                val sw = hw?.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                                hb.close()
                                if (sw == null) null else {
                                    val sc = 720f / maxOf(sw.width, sw.height)
                                    val fin = if (sc < 1f) android.graphics.Bitmap.createScaledBitmap(sw, (sw.width * sc).toInt(), (sw.height * sc).toInt(), true) else sw
                                    val bo = java.io.ByteArrayOutputStream()
                                    fin.compress(android.graphics.Bitmap.CompressFormat.JPEG, 65, bo); bo.toByteArray()
                                }
                            } catch (e: Exception) { null }
                            cb(out)
                        }
                        override fun onFailure(code: Int) { cb(null) }
                    })
            } catch (e: Exception) { cb(null) }
        }

        fun screenshotSync(): ByteArray? {
            val latch = java.util.concurrent.CountDownLatch(1)
            var res: ByteArray? = null
            screenshot { res = it; latch.countDown() }
            latch.await(4, java.util.concurrent.TimeUnit.SECONDS)
            return res
        }

        fun scroll(down: Boolean): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            fun find(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
                if (n.isScrollable) return n
                for (i in 0 until n.childCount) n.getChild(i)?.let { c -> find(c)?.let { return it } }
                return null
            }
            val sc = find(root) ?: return false
            return sc.performAction(
                if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            )
        }
    }

    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e != null && e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = e.packageName?.toString()
            if (p != null && p != packageName) Triggers.onApp(p)
        }
    }
    override fun onInterrupt() {}
    override fun onDestroy() { inst = null; super.onDestroy() }
}

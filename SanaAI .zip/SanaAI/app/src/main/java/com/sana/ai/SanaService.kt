package com.sana.ai

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.*
import android.provider.ContactsContract
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import java.util.Locale

class SanaService : Service(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var speaking = false
    private var thinking = false
    private var awakeUntil = 0L
    private val brain = Brain { n, a -> runTool(n, a) }
    private val wakeWords = listOf("सना", "sana", "वेकअप", "वेक अप", "वेकप", "wake up", "wakeup")

    private val aliases = mapOf(
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वाट्सएप" to "whatsapp",
        "यूट्यूब" to "youtube", "कैमरा" to "camera", "सेटिंग" to "settings", "क्रोम" to "chrome",
        "गैलरी" to "gallery", "फोन" to "phone", "गूगल" to "google", "इंस्टाग्राम" to "instagram",
        "फेसबुक" to "facebook", "मैप्स" to "maps", "कैलकुलेटर" to "calculator", "घड़ी" to "clock",
        "मैसेज" to "messages", "टेलीग्राम" to "telegram", "जीमेल" to "gmail", "स्नैपचैट" to "snapchat"
    )

    private val ticker = object : Runnable {
        override fun run() {
            if (awakeUntil != 0L && SystemClock.elapsedRealtime() > awakeUntil && !speaking && !thinking) {
                awakeUntil = 0L; Holo.hide(this@SanaService)
            }
            h.postDelayed(this, 3000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        val ch = "sana"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Sana AI", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, ch)
            .setContentTitle("Sana AI चालू है").setContentText("\"सना\" बोलकर बुलाइए")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        tts = TextToSpeech(this, this)
        Bus.announce = { speak(it) }
        h.postDelayed(ticker, 3000)
    }

    override fun onInit(status: Int) {
        tts.language = Locale("hi", "IN")
        val v = tts.voices?.filter { it.locale.language == "hi" }
        (v?.firstOrNull { it.name.contains("hia") || it.name.contains("female", true) } ?: v?.firstOrNull())
            ?.let { tts.voice = it }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { Holo.speaking(true) }
            override fun onError(id: String?) { done() }
            override fun onDone(id: String?) { done() }
            fun done() {
                speaking = false; Holo.speaking(false)
                if (awakeUntil != 0L) awakeUntil = SystemClock.elapsedRealtime() + 25000
                h.post { listen() }
            }
        })
        applyMode()
        speak("नमस्ते, मैं सना हूँ। मुझे बुलाने के लिए सना बोलिए।")
    }

    private fun applyMode() {
        tts.setPitch(when (Store.mode) { 0 -> 1.25f; 1 -> 1.1f; else -> 1.0f })
        tts.setSpeechRate(when (Store.mode) { 0 -> 0.95f; else -> 1.0f })
    }

    private fun speak(t: String) {
        speaking = true
        h.post { sr?.cancel() }
        tts.speak(t, TextToSpeech.QUEUE_ADD, null, "u${System.nanoTime()}")
    }

    private fun listen() {
        if (speaking || thinking) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!t.isNullOrBlank()) handle(t)
                    h.postDelayed({ listen() }, 300)
                }
                override fun onError(e: Int) { h.postDelayed({ listen() }, 700) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        sr?.cancel(); sr?.startListening(i)
    }

    private fun greet() = when (Store.mode) {
        0 -> "हाँ जान, बोलो ना"; 1 -> "हाँ यार, बोल"; else -> "जी, मैं सुन रही हूँ"
    }

    private fun handle(raw: String) {
        var t = raw.trim(); val low = t.lowercase()
        val now = SystemClock.elapsedRealtime()
        if (awakeUntil == 0L || now > awakeUntil) {
            val w = wakeWords.firstOrNull { low.contains(it) } ?: return
            t = low.replace(w, "").trim()
            Holo.show(this)
            awakeUntil = now + 25000
            if (t.isBlank()) { speak(greet()); return }
        }
        awakeUntil = now + 25000
        process(t)
    }

    private fun has(t: String, vararg k: String) = k.any { t.lowercase().contains(it) }

    // ---------- Fast path: aasaan commands bina Gemini ke, turant ----------
    private val ytWords = setOf("यूट्यूब", "youtube", "यू", "ट्यूब")
    private val ytDrop = setOf("पर", "में", "से", "on")
    private val ytCmd = setOf("चलाओ", "चला", "चलाइए", "बजाओ", "बजा", "सुनाओ", "सुना", "सर्च", "search", "करो",
        "खोजो", "खोज", "play", "प्ले", "गाना", "गाने", "सॉन्ग", "song", "वीडियो", "video", "प्लीज", "please")
    private val openCmd = setOf("खोलो", "खोल", "दो", "दे", "ओपन", "open", "करो", "ऐप", "app", "को", "प्लीज", "please")

    private fun fastPath(t: String): Boolean {
        var words = t.lowercase().split(" ", "\n").filter { it.isNotBlank() }
        if (words.isEmpty()) return false

        // 1) YouTube par gaana/video
        val isYt = words.any { it in ytWords }
        if (isYt && has(t, "चला", "बजा", "play", "प्ले", "सुना", "सर्च", "search", "खोज", "गाना", "गाने", "सॉन्ग", "song", "वीडियो")) {
            if (words.last() in setOf("दो", "दे")) words = words.dropLast(1)
            val q = words.filterIndexed { i, w ->
                w !in ytWords && w !in ytCmd &&
                    !(w in ytDrop && ((i > 0 && words[i - 1] in ytWords) || (i < words.size - 1 && words[i + 1] in ytWords)))
            }.joinToString(" ").trim()
            val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.google.android.youtube").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            speak(if (q.isBlank()) "ठीक है, यूट्यूब खोल रही हूँ" else "ठीक है, यूट्यूब पर $q खोल रही हूँ")
            return true
        }

        // 2) Chhota "X kholo" command
        if (words.size <= 4 && words.any { it in openCmd && it != "दो" && it != "दे" && it != "करो" && it != "को" && it != "ऐप" && it != "app" && it != "प्लीज" && it != "please" }) {
            val name = words.filter { it !in openCmd }.joinToString(" ")
            if (name.isNotBlank()) {
                val r = try { openApp(name) } catch (e: Exception) { "fail" }
                if (r.startsWith("ok")) { speak("ठीक है, खोल दिया"); return true }
            }
        }
        return false
    }

    private fun process(t: String) {
        // mode switch
        val m = when {
            has(t, "गर्लफ्रेंड", "गर्लफ्रेंड", "girlfriend", "रोमांटिक", "romantic") -> 0
            has(t, "फ्रेंड मोड", "दोस्त मोड", "friend mode", "फ्रेंड") -> 1
            has(t, "एआई मोड", "ai mode", "एआई", "असिस्टेंट मोड") -> 2
            else -> -1
        }
        if (m >= 0 && has(t, "मोड", "mode", "बनो", "बन जा", "बन जाओ")) {
            Store.mode = m; applyMode(); brain.reset()
            speak(when (m) { 0 -> "ठीक है जान, अब मैं तुम्हारी गर्लफ्रेंड मोड में हूँ"; 1 -> "चल ठीक है यार, फ्रेंड मोड ऑन"; else -> "एआई मोड चालू हो गया" })
            return
        }
        if (has(t, "सो जाओ", "बंद हो जाओ", "बाय", "bye")) {
            awakeUntil = 0L; Holo.hide(this); speak("ठीक है, बाय"); return
        }
        if (fastPath(t)) return
        if (Store.key.isBlank()) { speak("पहले ऐप में एपीआई की डालिए"); return }
        thinking = true; Holo.speaking(true)
        Thread {
            val reply = try { brain.ask(t) } catch (e: Exception) {
                android.util.Log.e("Sana", e.toString())
                val m = e.toString()
                Store.lastErr = m.take(900)
                h.post { android.widget.Toast.makeText(this, m.take(160), android.widget.Toast.LENGTH_LONG).show() }
                when {
                    m.contains("429") || m.contains("RESOURCE_EXHAUSTED") || m.contains("quota", true) -> "जेमिनी की लिमिट खत्म हो गई है, थोड़ी देर बाद बोलिए"
                    m.contains("UnknownHost") || m.contains("timeout", true) || m.contains("Unable to resolve") -> "इंटरनेट में दिक्कत है"
                    m.contains("API key", true) || m.contains("API_KEY") || m.contains("PERMISSION") -> "एपीआई की में दिक्कत है"
                    else -> "जेमिनी से जवाब लेने में कुछ गड़बड़ हुई, ऐप में आखिरी एरर देखिए"
                }
            }
            thinking = false
            h.post { speak(reply.ifBlank { "ठीक है" }) }
        }.start()
    }

    // ---------- Tools ----------
    private fun runTool(n: String, a: JSONObject): String = when (n) {
        "open_app" -> openApp(a.getString("name"))
        "call_contact" -> callContact(a.getString("name"))
        "type_text" -> if (SanaAccessibility.typeText(a.getString("text"))) "ok" else "fail: koi text box focus me nahi"
        "send_message" -> if (SanaAccessibility.send()) "ok" else "fail: send button nahi mila"
        "tap" -> if (SanaAccessibility.clickText(a.getString("text"))) "ok" else "fail: screen par nahi mila"
        "scroll" -> if (SanaAccessibility.scroll(a.getString("direction").contains("down"))) "ok" else "fail"
        "global" -> when (a.getString("action")) {
            "back" -> SanaAccessibility.back(); "home" -> SanaAccessibility.home(); else -> SanaAccessibility.recents()
        }.toString()
        "read_notifications" -> synchronized(Bus.notifs) {
            val l = Bus.notifs.takeLast(8); Bus.notifs.clear()
            if (l.isEmpty()) "koi naya notification nahi" else l.joinToString("\n")
        }
        "get_screen_text" -> SanaAccessibility.screenText()
        "open_url" -> {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "ok"
        }
        "wait" -> { Thread.sleep(((a.optString("seconds").toDoubleOrNull() ?: 2.0).coerceIn(0.5, 5.0) * 1000).toLong()); "ok" }
        else -> "unknown tool"
    }

    private fun openApp(spoken: String): String {
        val low = spoken.lowercase()
        val key = aliases.entries.firstOrNull { low.contains(it.key) }?.value ?: low
        val pm = packageManager
        val app = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(key) }
            ?: return "fail: $spoken naam ka app nahi mila"
        val i = pm.getLaunchIntentForPackage(app.activityInfo.packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return "ok: ${app.loadLabel(pm)} khul gaya"
    }

    private fun callContact(name: String): String {
        var number = name.filter { it.isDigit() || it == '+' }
        if (number.filter { it.isDigit() }.length < 5) {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return "fail: contacts permission nahi"
            number = ""
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
            )?.use { if (it.moveToFirst()) number = it.getString(0) }
        }
        if (number.isBlank()) return "fail: $name ka number nahi mila"
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) return "fail: call permission nahi"
        startActivity(Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "ok: $name ko call lag gaya"
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onDestroy() {
        Bus.announce = null; h.removeCallbacksAndMessages(null); Holo.hide(this)
        sr?.destroy(); tts.shutdown(); super.onDestroy()
    }
}

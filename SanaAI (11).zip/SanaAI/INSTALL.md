# Sana AI - Install

## Tarika A: PC ke bina (GitHub se APK)
1. github.com par free account -> New repository (naam: sana-ai).
2. Is folder ki SAARI files (app, .github, build.gradle.kts, settings.gradle.kts, gradle.properties) repo me upload karo.
3. Repo -> Actions -> "Build Sana APK" -> Run workflow (5-8 min).
4. Poora hone par Artifacts -> SanaAI-apk download karo -> zip kholo -> app-debug.apk phone me install karo.

## Tarika B: Android Studio
Open -> SanaAI folder -> Run (ya Build > Build APK).

## Gemini key
aistudio.google.com/apikey se free key lo (AQ... ya AIza... dono chalti hain) -> app me paste -> Save -> "Key test karo" dabao.

## Naye features (v3)
- Upar 3 gol button: 👁️ aankh, 📷 camera (Sana tumhe dekhti hai), 🖥️ screen share (Sana tumhari screen dekhti hai). Sana START ke baad kaam karte hain.
- Bolkar bhi: "kaimra chalu / band", "screen share chalu / band".
- Camera ya screen share chalu ho to har sawal ke saath photo/screenshot Gemini ko jaata hai. Notification me dikhta hai kya ON hai.
- Screen share ke liye Android 11+ chahiye, aur update ke baad Accessibility ek baar OFF karke ON karo.
- YouTube: "YouTube par <gaana> chalao". Control: "pause", "play", "agla gaana", "pichla gaana", "awaaz badhao/ghatao".
- Neon + hologram tab tak chalte hain jab tak "band" / "bye" / "neon band" na bolo.

## Mic aur gaana (v4)
- Gaana/video chal raha ho to Sana mic nahi kholti, isliye gaana beech me nahi rukta.
- Gaana chalte waqt Sana se bolna ho: notification me "बोलो" dabao, ya hologram image par tap karo. Wo ek baar sunegi.
- Gaana band hote hi Sana khud wapas "सना" sunne lagti hai.
- Ting awaaz band hai (jab gaana na chal raha ho). Poora mic band: "माइक बंद" ya "सुनना बंद"; chalu: notification ka button.

## Holo + Wallpaper (v5)
- Holo ladki ab photo jaisi khadi dikhti hai (neeche baayein kone me). Bolte waqt hilti/jhoomti hai, chup rehne par halki saans leti hai.
- Settings me: "Wallpaper chuno" (gallery se home + lock par), "Neon room wallpaper lagao", "Holo ladki ki image badlo" (transparent PNG sabse acchi), "Holo ladki pehle jaisi karo".
- Neon + holo tab tak chalte hain jab tak "Sana stop" / "bye" / "neon band" na bolo.
- Holo image badalne ke baad Sana STOP -> START karo.

## Naye moods (v6)
- 🥺 Emotional: dil se, bhaavuk, tumhara mood samajhkar sambhalti hai.
- ⏳ Waiting: ON karte hi Sana chup-chaap intezaar karti hai. Jaise hi tumhari awaaz sune: "कहाँ थे तुम इतनी देर से? मुझे याद नहीं आई क्या?" phir tumhare jawab par baat karti hai.
- 🌹 Romantic: meethi, shayarana, pyaar bhari baatein.
- Bolkar: "इमोशनल मोड", "वेटिंग मोड", "रोमांटिक मोड", "गर्लफ्रेंड मोड", "फ्रेंड मोड", "एआई मोड".
- Main screen par image ke upar kone me "Sakib♥️Sana" likha hai.

## Ladki ka react karna (v7)
- Chup rehne par ladki bilkul sthir khadi rehti hai (koi hilna-dulna nahi).
- Bolte hi: muskurati hai, gaal laal hote hain, haath uthakar wave karti hai, sar halka jhukata hai aur munh bolne jaisa hilta hai. Baat khatam hote hi haath neeche aa jaata hai.
- Apni image lagaoge to usme sirf halka hilna hota hai (haath/munh wala react sirf built-in ladki me hai).

## v8: Pattern draw, fast app/song commands, meethi awaaz
- Settings -> Suraksha: "Unlock Pattern banao": ungli se pattern draw karo (2 baar). Phir bolo "Sana, phone unlock karo" / "phone lock karo". OFF: "Unlock code hatao".
- Fast app search: "Chrome me kesariya search karo", "YouTube me ... search karo": app khulta hai, search box me likhkar enter dabta hai.
- Gaana: "kesariya song play karo" (YouTube kahe bina bhi): search karke pehla video turant chalta hai.
- Awaaz: 14 ladki-awaazein (🍯 wali sabse meethi), mood ke hisaab se awaaz ka andaaz badalta hai.

## v9: Naye features
- Start hote hi Sana sirf "Welcome Master" bolti hai. Wake words: "सना" ya "सना".
- Naye real tools (bolkar): torch on/off, phone status (battery, charging, network, RAM, storage), alarm, timer, live mausam, Google search, Maps navigation, WhatsApp/SMS draft (send tum khud dabate ho), share, settings kholna, note save.
- "Tumhe kisne banaya" par ab bhi "साकिब सर" hi bolti hai (unchanged).
- Abhi nahi bana (bade modules, alag stage me): multi-agent orchestrator, Room DB, file manager, PDF/Word/Excel banana, whiteboard, smart home, OpenAI/Claude/OpenRouter. Inme se jo chahiye bolo, ek ek karke banayenge.

## v10: Naye features (sab bolkar chalta hai)
- Files (Sana folder me): file banao/dhundho/rename/delete(confirm)/ZIP/unZIP/share/open/read.
- Documents: "PDF banao ..." ya text file. Whiteboard: "whiteboard kholo" (draw, undo, PNG+PDF save).
- Memory: "meri yaad me dhundho", "yaad mita do" (confirm), "memory backup banao".
- Routines: "subah routine save karo: YouTube kholo, mausam batao" phir "subah routine chalao".
- Live info: khabrein, currency, kisi shehar ka time, webpage padhna/summary.
- Andaaz: "funny / professional / teacher / coding andaaz me bolo". Girlfriend/Friend/AI modes pehle jaise.
- Abhi baaki: Room DB, multi-agent orchestrator, smart home, OpenAI/Claude/OpenRouter, app lock, QR pairing.

## v11: Maya jaise extra features (sab bolkar)
Pehle: app me "Extra features" card -> "Extra permissions do" (SMS, call log, location, call uthana). Brightness/DND ke liye alag anumati wali line bhi dabao. SOS ke liye "SOS numbers set karo".
- Message/Call: "SMS padho", "missed call batao", "OTP batao" (sirf bolkar), "notification ka reply karo ...", "saare notification hata do", "call uthao / kaato", email draft.
- Safety: "SOS bhejo" (haan bolne par saved numbers ko location SMS), "meri location batao".
- Phone control: brightness %, volume %, silent/vibrate, Do Not Disturb, copy/paste.
- Info: Wikipedia, "paas me parking/petrol pump dhundho" (Maps), camera app kholna.
- Bhasha: "English/Bangla/Hinglish me baat karo". Andaaz: "jealous" ya "angry (halka pyaar bhara)".
- Triggers: "charging lagte hi ... bolo", "headphone lagte hi YouTube kholo", "7:30 par ... ", "WhatsApp khulte hi ...", "OTP aaye to ...", "trigger list", "trigger hatao 2".
- Khaas pal: "roz subah 7:30 good morning bolo", "raat 11 baje good night", "Rahul ka birthday 14-05 yaad rakho".
- Abhi nahi: voice cloning, home widgets, themes, location-based (ghar aate-jaate) alerts.

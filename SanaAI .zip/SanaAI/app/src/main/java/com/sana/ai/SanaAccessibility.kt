package com.sana.ai

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class SanaAccessibility : AccessibilityService() {
    companion object {
        var inst: SanaAccessibility? = null

        fun typeText(t: String): Boolean {
            val s = inst ?: return false
            val root = s.rootInActiveWindow ?: return false
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: firstEditable(root) ?: return false
            val old = node.text?.toString().orEmpty()
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + t)
            }
            return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }

        private fun firstEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
            if (n.isEditable) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { c -> firstEditable(c)?.let { return it } }
            return null
        }

        fun clickText(t: String): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            val nodes = root.findAccessibilityNodeInfosByText(t)
            for (n in nodes) {
                var x: AccessibilityNodeInfo? = n
                while (x != null) {
                    if (x.isClickable) return x.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    x = x.parent
                }
            }
            return false
        }

        fun send(): Boolean =
            listOf("Send", "भेजें", "भेजे", "Send message").any { clickText(it) }

        fun screenText(): String {
            val root = inst?.rootInActiveWindow ?: return "screen padh nahi pa rahi (accessibility ON karo)"
            val sb = StringBuilder()
            fun walk(n: AccessibilityNodeInfo) {
                if (sb.length > 3500) return
                val t = n.text?.toString() ?: n.contentDescription?.toString()
                if (!t.isNullOrBlank()) sb.append(if (n.isClickable) "[tap] " else "").append(t).append('\n')
                for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
            }
            walk(root)
            return sb.toString().ifBlank { "screen khali hai" }
        }

        fun back() = inst?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
        fun home() = inst?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false
        fun recents() = inst?.performGlobalAction(GLOBAL_ACTION_RECENTS) ?: false

        fun lockScreen(): Boolean =
            if (android.os.Build.VERSION.SDK_INT >= 28)
                inst?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN) ?: false
            else false

        // sirf swipe wale lock ko khulne ke liye (PIN/fingerprint wala nahi khulta)
        fun swipeUp() {
            val s = inst ?: return
            val dm = s.resources.displayMetrics
            val path = android.graphics.Path().apply {
                moveTo(dm.widthPixels / 2f, dm.heightPixels * 0.85f); lineTo(dm.widthPixels / 2f, dm.heightPixels * 0.2f)
            }
            val g = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 300)).build()
            s.dispatchGesture(g, null, null)
        }

        fun scroll(down: Boolean): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            fun find(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
                if (n.isScrollable) return n
                for (i in 0 until n.childCount) n.getChild(i)?.let { c -> find(c)?.let { return it } }
                return null
            }
            val sc = find(root) ?: return false
            return sc.performAction(
                if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            )
        }
    }

    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { inst = null; super.onDestroy() }
}

package com.sana.ai

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Update checker: har user ke phone me app khulte hi (6 ghante me ek baar) naya version dhoondhta hai.
 * Naya mile to "Update karo" dikhata hai; download ke baad Android ka install screen khulta hai (user ko ek tap karna padta hai:
 * Android bina user ki marzi ke chupke se install nahi karne deta).
 *
 * Owner: UPDATE_URL me apni version.json ka seedha (public) link daalo. Format: update/version.json dekho.
 */
object Updater {
    const val UPDATE_URL = ""
    private var busy = false
    private var rx: BroadcastReceiver? = null

    fun current(c: Context): Int = try {
        val pi = c.packageManager.getPackageInfo(c.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else @Suppress("DEPRECATION") pi.versionCode
    } catch (e: Exception) { 0 }

    fun check(act: Activity, manual: Boolean) {
        if (UPDATE_URL.isBlank()) { if (manual) Toast.makeText(act, "Update link set nahi hai (Updater.kt me UPDATE_URL)", Toast.LENGTH_LONG).show(); return }
        if (busy) return
        if (!manual && System.currentTimeMillis() - Store.lastUpdateCheck < 6 * 3600_000L) return
        busy = true
        Thread {
            try {
                val cn = URL(UPDATE_URL).openConnection() as HttpURLConnection
                cn.connectTimeout = 8000; cn.readTimeout = 8000
                val j = JSONObject(cn.inputStream.bufferedReader().readText())
                Store.lastUpdateCheck = System.currentTimeMillis()
                val code = j.getInt("versionCode"); val name = j.optString("versionName", code.toString())
                val apk = j.getString("apkUrl"); val notes = j.optString("notes", "")
                act.runOnUiThread {
                    if (code > current(act)) {
                        AlertDialog.Builder(act).setTitle("Naya update $name")
                            .setMessage(if (notes.isBlank()) "Sana ka naya version aa gaya hai." else notes)
                            .setPositiveButton("Update karo") { _, _ -> download(act, apk) }
                            .setNegativeButton("Baad me", null).show()
                    } else if (manual) Toast.makeText(act, "Sana up-to-date hai ✅", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                if (manual) act.runOnUiThread { Toast.makeText(act, "Update check nahi hua (net ya link dekho)", Toast.LENGTH_LONG).show() }
            } finally { busy = false }
        }.start()
    }

    private fun download(act: Activity, url: String) {
        try {
            val f = File(act.getExternalFilesDir(null), "Sana/Sana-update.apk")
            f.parentFile?.mkdirs(); if (f.exists()) f.delete()
            val dm = act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val id = dm.enqueue(DownloadManager.Request(Uri.parse(url)).setTitle("Sana update")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(act, null, "Sana/Sana-update.apk"))
            Toast.makeText(act, "Update download ho raha hai...", Toast.LENGTH_SHORT).show()
            try { rx?.let { act.unregisterReceiver(it) } } catch (e: Exception) {}
            rx = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    if (i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) != id) return
                    try { act.unregisterReceiver(this) } catch (e: Exception) {}
                    install(act, f)
                }
            }
            val fl = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
            if (Build.VERSION.SDK_INT >= 33) act.registerReceiver(rx, fl, Context.RECEIVER_EXPORTED) else act.registerReceiver(rx, fl)
        } catch (e: Exception) { Toast.makeText(act, "Download shuru nahi hua", Toast.LENGTH_LONG).show() }
    }

    private fun install(act: Activity, f: File) {
        if (!f.exists()) { Toast.makeText(act, "Update file nahi mili", Toast.LENGTH_LONG).show(); return }
        if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(act, "Sana ko 'Install karne ki ijazat' do, phir wapas aakar Update dabao", Toast.LENGTH_LONG).show()
            act.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${act.packageName}")))
            return
        }
        val u = FileProvider.getUriForFile(act, "${act.packageName}.files", f)
        act.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

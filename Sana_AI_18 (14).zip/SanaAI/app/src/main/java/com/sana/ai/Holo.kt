package com.sana.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.sin
import java.io.File

object Holo {
    private var view: HoloView? = null
    private val h = Handler(Looper.getMainLooper())

    fun show(c: Context) = h.post {
        if (view != null || !Settings.canDrawOverlays(c)) return@post
        val v = HoloView(c)
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (android.os.Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        val wm = c.getSystemService(WindowManager::class.java)
        wm.addView(v, lp)
        view = v
    }

    fun hide(c: Context) = h.post {
        view?.let { v -> runCatching { c.getSystemService(WindowManager::class.java).removeView(v) } }
        view = null
    }

    fun speaking(b: Boolean) { SanaService.talking = b; h.post { view?.speaking = b } }
}

class HoloView(c: Context) : View(c) {
    var speaking = false
        set(v) { field = v; if (v && !anim.isRunning) anim.start() }
    private var phase = 0f
    private var lvl = 0f
    private var sp = 0f   // bolne ka smooth level (0..1)
    private var arm = 0f; private var smile = 0f; private var mo = 0f; private var lastTalk = -9.0
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val mp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = RectF()
    private val mouthR = RectF()
    private val anim: ValueAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 5000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { va -> phase = va.animatedValue as Float; invalidate() }
    }

    private fun a(c: Int, al: Int) = (c and 0x00FFFFFF) or (al.coerceIn(0, 255) shl 24)
    private fun sn(x: Double): Float = sin(x).toFloat()

    /** Neon ka rang: user ne chuna ho to wahi (teen shade), warna mood ke hisaab se */
    private fun cols(): IntArray {
        val c = Store.neonColor
        if (c != 0) {
            val hsv = FloatArray(3); Color.colorToHSV(c, hsv)
            val light = Color.HSVToColor(floatArrayOf(hsv[0], (hsv[1] * 0.45f).coerceIn(0f, 1f), 1f))
            val alt = Color.HSVToColor(floatArrayOf((hsv[0] + 28f) % 360f, hsv[1], hsv[2]))
            return intArrayOf(c or 0xFF000000.toInt(), light, alt)
        }
        return when (Store.mode) {
            0 -> intArrayOf(0xFFFF2BD6.toInt(), 0xFFFF8AEA.toInt(), 0xFF9B3BFF.toInt())   // pink-purple
            1 -> intArrayOf(0xFF00F5FF.toInt(), 0xFF7CFFB2.toInt(), 0xFF2D7BFF.toInt())   // cyan-green
            3 -> intArrayOf(0xFF6C8CFF.toInt(), 0xFFB69CFF.toInt(), 0xFF4B5CFF.toInt())   // emotional: neela-lavender
            4 -> intArrayOf(0xFFFFB347.toInt(), 0xFFFF7AA8.toInt(), 0xFFFF5A5A.toInt())   // waiting: garam sunehri-gulabi
            5 -> intArrayOf(0xFFFF2D5F.toInt(), 0xFFFF7AA2.toInt(), 0xFFD61C8A.toInt())   // romantic: gehra gulabi-laal
            else -> intArrayOf(0xFF2D7BFF.toInt(), 0xFF00E5FF.toInt(), 0xFF7A5CFF.toInt()) // blue
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!anim.isRunning) anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        lvl += ((if (speaking) 1f else 0.7f) - lvl) * 0.07f
        val w = width.toFloat(); val h = height.toFloat()
        val col = cols()
        val rad = Math.toRadians(phase.toDouble())
        val L = lvl

        // ---- poori screen par neon roshni (kinaron se andar tak)
        val g = 0.28f * minOf(w, h)
        val pulse = 0.75f + 0.25f * sn(rad * 3)
        val ea = (150 * L * pulse).toInt()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, g, a(col[0], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(0f, 0f, w, g, p)
        p.shader = LinearGradient(0f, h, 0f, h - g, a(col[2], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(0f, h - g, w, h, p)
        p.shader = LinearGradient(0f, 0f, g, 0f, a(col[1], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(0f, 0f, g, h, p)
        p.shader = LinearGradient(w, 0f, w - g, 0f, a(col[1], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(w - g, 0f, w, h, p)

        if (Store.awNeon) {
            Aedwans.drawNeon(cv, w, h, d, col, L, phase, Aedwans.cornerPx(this, d))
        } else {
        // ---- ghoomti hui neon border
        val sg = SweepGradient(w / 2, h / 2,
            intArrayOf(col[0], a(col[0], 30), col[2], a(col[2], 30), col[1], col[0]),
            floatArrayOf(0f, .22f, .5f, .72f, .9f, 1f))
        sg.setLocalMatrix(Matrix().apply { setRotate(phase, w / 2, h / 2) })
        p.shader = sg; p.style = Paint.Style.STROKE
        val r = RectF(6 * d, 6 * d, w - 6 * d, h - 6 * d)
        for ((sw, al) in listOf(30f to 40, 16f to 95, 5f to 255)) {
            p.strokeWidth = sw * d * (1f + 0.35f * L); p.alpha = (al * L).toInt().coerceIn(0, 255)
            cv.drawRoundRect(r, 38 * d, 38 * d, p)
        }
        }
        p.shader = null; p.alpha = 255; p.style = Paint.Style.FILL
    }
}

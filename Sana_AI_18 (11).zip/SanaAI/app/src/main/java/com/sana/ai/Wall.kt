package com.sana.ai

import android.app.WallpaperManager
import android.content.Context
import android.graphics.*
import android.net.Uri
import java.io.File
import kotlin.math.max

/** Wallpaper: gallery se chuni image ya built-in neon room, home + lock dono par */
object Wall {
    /** image ko screen ke size me center-crop karke wallpaper lagao. true = ho gaya */
    fun apply(c: Context, src: Bitmap): Boolean = try {
        val dm = c.resources.displayMetrics
        val tw = dm.widthPixels; val th = dm.heightPixels
        val out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val sc = max(tw.toFloat() / src.width, th.toFloat() / src.height)
        val sw = src.width * sc; val sh = src.height * sc
        Canvas(out).drawBitmap(src, null,
            RectF((tw - sw) / 2, (th - sh) / 2, (tw + sw) / 2, (th + sh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
        WallpaperManager.getInstance(c).setBitmap(out, null, true,
            WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
        true
    } catch (e: Exception) { false }

    /** gallery ki image bade size se chhota karke padho (memory bachane ke liye) */
    fun decode(c: Context, uri: Uri, maxDim: Int = 2400): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > maxDim) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    } catch (e: Exception) { null }

    /** Holo ladki ki apni PNG (transparent ho to best) save karo */
    fun saveHolo(c: Context, b: Bitmap): Boolean = try {
        File(c.filesDir, "holo.png").outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }; true
    } catch (e: Exception) { false }

    fun resetHolo(c: Context) { runCatching { File(c.filesDir, "holo.png").delete() } }

    private fun heart(cx: Float, cy: Float, s: Float) = Path().apply {
        moveTo(cx, cy + s * 0.9f)
        cubicTo(cx - s * 1.6f, cy - s * 0.2f, cx - s * 0.7f, cy - s * 1.3f, cx, cy - s * 0.45f)
        cubicTo(cx + s * 0.7f, cy - s * 1.3f, cx + s * 1.6f, cy - s * 0.2f, cx, cy + s * 0.9f)
        close()
    }

    /** Built-in neon room wallpaper (neela kamra, neon dil, khidki, fairy lights, desk glow) */
    fun neonRoom(w: Int, h: Int): Bitmap {
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bm); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val u = w / 360f
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            intArrayOf(0xFF0A1470.toInt(), 0xFF1535D8.toInt(), 0xFF2A1BB0.toInt(), 0xFF070A35.toInt()),
            floatArrayOf(0f, .35f, .7f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
        // khidki + sheher
        val win = RectF(w * 0.52f, h * 0.17f, w * 0.96f, h * 0.36f)
        p.color = 0xFF14104A.toInt(); cv.drawRoundRect(win, 8 * u, 8 * u, p)
        p.color = 0xFF3B2A9A.toInt()
        for (i in 0..7) { val bw = win.width() / 9; val bh = win.height() * (0.25f + 0.5f * ((i * 37) % 10) / 10f)
            cv.drawRect(win.left + i * bw + 4 * u, win.bottom - bh, win.left + (i + 1) * bw, win.bottom, p) }
        p.style = Paint.Style.STROKE; p.strokeWidth = 3 * u; p.color = 0xFF00E5FF.toInt()
        p.maskFilter = BlurMaskFilter(6 * u, BlurMaskFilter.Blur.OUTER); cv.drawRoundRect(win, 8 * u, 8 * u, p); p.maskFilter = null
        // shelf
        p.style = Paint.Style.FILL; p.color = 0xCC0B0F3A.toInt()
        cv.drawRect(0f, h * 0.20f, w * 0.34f, h * 0.215f, p); cv.drawRect(0f, h * 0.30f, w * 0.34f, h * 0.315f, p)
        // neon dil
        fun neon(path: Path, col: Int, sw: Float) {
            p.style = Paint.Style.STROKE; p.color = col
            p.strokeWidth = sw * 2.4f; p.alpha = 90; p.maskFilter = BlurMaskFilter(10 * u, BlurMaskFilter.Blur.NORMAL); cv.drawPath(path, p)
            p.maskFilter = null; p.alpha = 255; p.strokeWidth = sw; cv.drawPath(path, p)
        }
        neon(heart(w * 0.42f, h * 0.13f, 24 * u), 0xFFFF6AE6.toInt(), 3 * u)
        neon(heart(w * 0.24f, h * 0.24f, 14 * u), 0xFF4FD8FF.toInt(), 3 * u)
        neon(heart(w * 0.70f, h * 0.10f, 18 * u), 0xFFFF4FD0.toInt(), 3 * u)
        neon(heart(w * 0.86f, h * 0.09f, 12 * u), 0xFFB45CFF.toInt(), 3 * u)
        // fairy lights
        p.style = Paint.Style.FILL
        for (i in 0..14) {
            val x = w * i / 14f; val y = h * 0.035f + 10 * u * kotlin.math.sin(i * 0.9f)
            p.color = 0xFFFFF2B0.toInt(); p.maskFilter = BlurMaskFilter(7 * u, BlurMaskFilter.Blur.NORMAL); cv.drawCircle(x, y, 4 * u, p)
            p.maskFilter = null; p.color = Color.WHITE; cv.drawCircle(x, y, 2 * u, p)
        }
        // desk glow
        p.shader = RadialGradient(w * 0.5f, h * 0.93f, w * 0.7f,
            intArrayOf(0xAA00E5FF.toInt(), 0x552D7BFF, 0), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, h * 0.7f, w.toFloat(), h.toFloat(), p); p.shader = null
        return bm
    }
}

package com.sana.ai

import android.Manifest
import android.app.Activity
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.*
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(40, 40, 40, 40)
        }
        fun btn(t: String, f: () -> Unit) = inner.addView(Button(this).apply { text = t; setOnClickListener { f() } })

        inner.addView(TextView(this).apply {
            text = "Sana AI 🎙️"; textSize = 24f; gravity = Gravity.CENTER
        })
        val key = EditText(this).apply { hint = "Gemini API key (AQ.... ya AIza...)"; setText(Store.key); setSingleLine() }
        inner.addView(key)
        val model = EditText(this).apply { hint = "Gemini model"; setText(Store.model); setSingleLine() }
        inner.addView(model)
        btn("💾 Gemini key + model save karo") {
            Store.key = key.text.toString(); Store.model = model.text.toString(); toast("Save ho gaya")
        }

        btn("🔍 Key test karo") {
            Store.key = key.text.toString()
            if (Store.key.isBlank()) { toast("Pehle key daalo"); return@btn }
            toast("Test ho raha hai, 10-20 sec ruko...")
            Thread {
                val tried = listOf(model.text.toString().trim(), "gemini-3.5-flash-lite", "gemini-3.1-flash-lite",
                    "gemini-3.5-flash", "gemini-3.8-flash", "gemini-flash-latest")
                    .filter { it.isNotBlank() }.distinct()
                var okModel: String? = null
                var firstErr = ""
                for (m in tried) {
                    Store.model = m
                    try { Brain { _, _ -> "" }.ask("Sirf ek shabd me bolo: haan"); okModel = m; break }
                    catch (e: Exception) { if (firstErr.isEmpty()) firstErr = "$m:\n" + (e.message ?: "") }
                }
                runOnUiThread {
                    if (okModel != null) {
                        Store.model = okModel; model.setText(okModel)
                        android.app.AlertDialog.Builder(this).setTitle("Key chal gayi ✅")
                            .setMessage("Model: $okModel (save ho gaya). Ab Sana START kar sakte ho.").setPositiveButton("OK", null).show()
                    } else {
                        android.app.AlertDialog.Builder(this).setTitle("Test fail ❌")
                            .setMessage("Is error ka screenshot bhejo:\n\n" + firstErr.take(600)).setPositiveButton("OK", null).show()
                    }
                }
            }.start()
        }

        btn("⚠️ Aakhri error dekho") {
            android.app.AlertDialog.Builder(this).setTitle("Aakhri error")
                .setMessage(Store.lastErr.ifBlank { "Abhi tak koi error nahi" }).setPositiveButton("OK", null).show()
        }

        btn("1. Permissions do") {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS, Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        btn("2. Accessibility ON karo") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("3. Notification access ON karo") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        btn("4. Display over other apps ON karo (neon/hologram)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("5. Sana START") { Store.key = key.text.toString(); Store.model = model.text.toString(); startForegroundService(Intent(this, SanaService::class.java)) }
        btn("Sana STOP") { stopService(Intent(this, SanaService::class.java)) }

        inner.addView(TextView(this).apply { text = "\nMode chuno:"; textSize = 18f })
        btn("💕 Girlfriend mode") { Store.mode = 0; toast("Girlfriend mode") }
        btn("😎 Friend mode") { Store.mode = 1; toast("Friend mode") }
        btn("🤖 AI mode") { Store.mode = 2; toast("AI mode") }
        btn("Battery optimization band karo") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        btn("🔐 Unlock PIN set karo (Sana khud khole)") { askCode("pin") }
        btn("🔐 Unlock Pattern set karo (Sana khud khole)") { askCode("pattern") }
        btn("🔓 Unlock code hatao") { Store.unlockCode = ""; Store.unlockType = ""; toast("Unlock code hata diya") }
        btn("🎤 Ladki ki awaaz chuno (5 awaazein)") { pickVoice() }
        btn("🔊 Awaaz badlo: Real (Gemini) ↔ Fast (phone ki)") {
            Store.fastVoice = !Store.fastVoice
            toast(if (Store.fastVoice) "Fast awaaz: phone ki voice, turant bolegi" else "Real awaaz: Gemini ki ladki wali voice")
        }
        inner.addView(TextView(this).apply {
            text = "\nVoice se phone:\n• \"Sana, phone lock karo\"\n• \"Sana, phone unlock karo / screen on karo\"\n(PIN ya fingerprint wala lock tumhe khud kholna padega)"
            textSize = 14f
        })

        // ---------- Settings popup (sab kuch ek chhote icon ke andar) ----------
        val dlg = android.app.Dialog(this, android.R.style.Theme_Material_Light_NoActionBar)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(12), dp(8), dp(4)) }
        bar.addView(TextView(this).apply { text = "⚙️ Settings"; textSize = 20f }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(TextView(this).apply { text = "✕"; textSize = 22f; setPadding(dp(16), dp(8), dp(16), dp(8)); setOnClickListener { dlg.dismiss() } })
        box.addView(bar)
        box.addView(ScrollView(this).apply { addView(inner) })
        dlg.setContentView(box)
        dlg.setOnShowListener { dlg.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT) }

        // ---------- Main screen: badi image + coffee cup ----------
        val dm = resources.displayMetrics
        var ih = (dm.heightPixels * 0.52f).toInt(); var iw = ih * 720 / 959
        val maxW = dm.widthPixels - dp(40)
        if (iw > maxW) { iw = maxW; ih = iw * 959 / 720 }
        val img = ImageView(this).apply {
            setImageResource(R.drawable.sana_face); scaleType = ImageView.ScaleType.FIT_XY
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(28).toFloat()) }
            }
            elevation = dp(10).toFloat()
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(20), dp(30), dp(20), dp(16))
        }
        col.addView(TextView(this).apply { text = "Sana AI 🎙️"; textSize = 22f; gravity = Gravity.CENTER })
        col.addView(img, LinearLayout.LayoutParams(iw, ih).apply { topMargin = dp(14); bottomMargin = dp(10) })
        col.addView(MicButton(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(120)))

        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFEEF6.toInt()))
        }
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(TextView(this).apply {
            text = "⚙️"; textSize = 22f; gravity = Gravity.CENTER; elevation = dp(4).toFloat()
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
            setOnClickListener { dlg.show() }
        }, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.END).apply { topMargin = dp(28); rightMargin = dp(16) })
        setContentView(root)
        if (Store.key.isBlank()) root.post { dlg.show() }
    }
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private val voices = listOf(
        "Leda" to "Leda: jawan aur meethi",
        "Aoede" to "Aoede: halki aur khili hui",
        "Achernar" to "Achernar: naram aur dheemi",
        "Sulafat" to "Sulafat: garm aur pyaari",
        "Laomedeia" to "Laomedeia: khushmizaaj")

    private fun pickVoice() {
        val cur = voices.indexOfFirst { it.first == Store.voiceName }.coerceAtLeast(0)
        android.app.AlertDialog.Builder(this)
            .setTitle("Ladki ki awaaz chuno")
            .setSingleChoiceItems(voices.map { it.second }.toTypedArray(), cur) { d, i ->
                Store.voiceName = voices[i].first; Store.fastVoice = false
                if (SanaService.running)
                    startService(Intent(this, SanaService::class.java).setAction("say")
                        .putExtra("t", "नमस्ते, मैं सना हूँ। क्या अब मेरी आवाज़ अच्छी लग रही है?"))
                else toast("Awaaz chun li. Sana START karke sun lo")
                d.dismiss()
            }
            .setNegativeButton("Band karo", null).show()
    }

    private fun askCode(type: String) {
        val et = EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            hint = if (type == "pin") "PIN (jaise 1234)" else "Pattern dots 1-9 (jaise 14789)"
        }
        val info = (if (type == "pin") "" else "Dots ke number: upar 1 2 3, beech 4 5 6, neeche 7 8 9. Jis order me pattern banate ho wahi likho.\n\n") +
            "Dhyan: 'Sana unlock' bolne par koi bhi aapka phone khol sakta hai."
        android.app.AlertDialog.Builder(this)
            .setTitle(if (type == "pin") "PIN set karo" else "Pattern set karo")
            .setMessage(info).setView(et)
            .setPositiveButton("Save") { _, _ ->
                val c = et.text.toString().trim()
                val okLen = c.length >= 4
                val okPat = type == "pin" || (c.all { it in '1'..'9' } && c.toSet().size == c.length)
                if (okLen && okPat) { Store.unlockType = type; Store.unlockCode = c; toast("Save ho gaya") }
                else toast("Code sahi nahi hai (kam se kam 4, pattern me 1-9 alag-alag)")
            }
            .setNegativeButton("Cancel", null).show()
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

/** Mic button: dabane par Sana ON/OFF. ON me gulaabi ring dhadakti hai */
class MicButton(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var ph = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { ph = it.animatedValue as Float; invalidate() }
    }
    init {
        setOnClickListener {
            if (!SanaService.running) {
                if (context.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                    Toast.makeText(context, "Pehle ⚙️ Settings me 'Permissions do' dabao", Toast.LENGTH_LONG).show()
                else context.startForegroundService(Intent(context, SanaService::class.java))
            } else context.startService(Intent(context, SanaService::class.java).setAction("mic"))
            postDelayed({ invalidate() }, 500)
        }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val on = SanaService.running && SanaService.micOnState
        val cx = w / 2; val cy = h * 0.42f; val r = minOf(h * 0.26f, w * 0.2f)
        if (on) for (k in 0..1) {
            val t = (ph + k * 0.5f) % 1f
            p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.08f; p.color = 0xFFFF2BD6.toInt()
            p.alpha = ((1f - t) * 170).toInt(); cv.drawCircle(cx, cy, r * (1f + 0.8f * t), p)
        }
        p.alpha = 255; p.style = Paint.Style.FILL
        p.shader = LinearGradient(cx, cy - r, cx, cy + r,
            if (on) 0xFFFF6AD5.toInt() else 0xFFB8B8C0.toInt(), if (on) 0xFF9B3BFF.toInt() else 0xFF8A8A94.toInt(), Shader.TileMode.CLAMP)
        cv.drawCircle(cx, cy, r, p); p.shader = null
        p.color = Color.WHITE
        val bw = r * 0.30f
        cv.drawRoundRect(RectF(cx - bw, cy - r * 0.52f, cx + bw, cy + r * 0.1f), bw, bw, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.09f; p.strokeCap = Paint.Cap.ROUND
        cv.drawArc(RectF(cx - r * 0.48f, cy - r * 0.36f, cx + r * 0.48f, cy + r * 0.3f), 0f, 180f, false, p)
        cv.drawLine(cx, cy + r * 0.3f, cx, cy + r * 0.55f, p)
        cv.drawLine(cx - r * 0.22f, cy + r * 0.55f, cx + r * 0.22f, cy + r * 0.55f, p)
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL; p.color = 0xFF2A2230.toInt(); p.textSize = r * 0.36f; p.textAlign = Paint.Align.CENTER
        cv.drawText(if (on) "माइक ON • दबाकर बंद करो" else "माइक OFF • दबाकर चालू करो", cx, h * 0.93f, p)
    }
}

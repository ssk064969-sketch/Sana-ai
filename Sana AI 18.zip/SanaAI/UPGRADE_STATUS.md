# Sana AI 18 — Pro update (38-feature roadmap)

Ye update Sana AI ke maujooda code me jodi gayi hai. **Android build aur phone par test abhi nahi hua** (is environment me Android SDK / Kotlin compiler nahi tha). Pehle GitHub Actions se APK banao, phir kisi test phone par jaanch lo.
Word / Excel / PowerPoint banane wala hissa Python me alag se verify kiya gaya (python-docx, openpyxl, python-pptx me file khul rahi hai).

Status: **PEHLE SE** = pehle se tha | **NAYA** = is update me juda | **LIMITED** = sach me sirf thoda kaam karta hai | **NAHI** = nahi bana (wajah likhi hai)

| # | Feature | Status | Note |
|---|---|---|---|
| 1 | Real-time voice, Hindi + English | PEHLE SE | "bhasha badlo" se hindi/hinglish/english |
| 2 | Voice interruption | LIMITED | Notification ka "आवाज़ रोको" button hai. Bolkar beech me rokna NAHI bana: Sana bolte waqt mic band rakhti hai taaki apni hi awaaz na sune |
| 3 | Wake word "Hey Zara" | NAYA | "Hey Zara / हे ज़ारा / हे सना" ab "सना" ke saath chalte hain. Ye Android speech recognizer se pakadta hai (alag hotword engine nahi), isliye mic chalu rehna aur battery lagti hai |
| 4 | Sleep mode | PEHLE SE + NAYA | "सो जाओ" ya "स्लीप मोड" bolo |
| 5 | Offline voice recognition | NAYA | App ke Pro features me ya bolkar "ऑफलाइन वॉइस चालू". Hindi offline pack phone me download hona chahiye. AI ke jawab ke liye net ab bhi chahiye; torch/volume jaise local kaam bina net ke chalte hain |
| 6 | Natural female voice | PEHLE SE | Gemini voice + Sarvam |
| 7 | Friendly / Professional / Venom | NAYA (Venom) | "Venom mode lagao". Venom tez aur sarcastic hai, gaali/dhamki nahi |
| 8 | Voice Guardian | NAYA, LIMITED | Ye aawaaz ka fingerprint (voiceprint) NAHI hai. Ek **gupt shabd** hai: bolo "Sana, guardian set karo". Call, message, delete, SMS/OTP padhna, notification reply se pehle gupt shabd poochhti hai. Shabd sirf salted hash me save hota hai aur AI/chat history me nahi jaata. Koi sun le to wo bhi bol sakta hai |
| 9 | Phone call control | PEHLE SE | call lagana, uthana, kaatna |
| 10 | Caller name announcement | NAYA | Contacts + call log + phone state ki anumati chahiye. Android 10+ par kuch phones number chhupate hain |
| 11 | WhatsApp read / reply / Business | PEHLE SE | Notification access se. WhatsApp Business notification bhi aati hai |
| 12 | WhatsApp media | NAYA, LIMITED | Sana folder ki file/photo WhatsApp me bhejne ke liye khulti hai, **Send tum dabate ho**. Aayi hui media padhna/save karna NAHI bana |
| 13 | WhatsApp voice/video call | NAHI | WhatsApp iske liye koi public API nahi deta |
| 14 | Full phone control | PEHLE SE | Accessibility se tap, type, swipe, back |
| 15 | Torch / brightness / volume / silent / DND | PEHLE SE | Hotspot: **NAYA par LIMITED**, Android app ko hotspot seedha on nahi karne deta, sirf setting khulti hai |
| 16 | Camera vision | PEHLE SE | |
| 17 | Screen vision | PEHLE SE | |
| 18 | Live screen sharing | PEHLE SE | Sana ko screen dikhana. Doosre insaan ko stream karna NAHI |
| 19 | BGMI / Free Fire commentary | NAYA, LIMITED | "game commentary chalu karo". Har 15 second me screenshot leke ek line bolti hai. Accessibility (Android 11+) chahiye. Asli real-time nahi hai, Gemini quota bhi kharch hota hai |
| 20 | Notification manager / auto reply | PEHLE SE | Triggers se (notification keyword -> reply/kaam) |
| 21 | Coding / website | NAYA | "index.html banao": file Sana folder me banti hai aur browser me khulti hai |
| 22 | Deep research with sources | NAYA | Gemini + Google Search. Poori research aur source links file me save hote hain |
| 23 | Image generation | NAYA | Gemini image model. **Free API key par band ho sakta hai**, tab error batayegi |
| 24 | Instagram / Facebook post | NAYA, LIMITED | Share screen khulti hai aur caption copy hota hai, **post tum dabate ho**. Khud post karna NAHI (official API + app review chahiye) |
| 25 | Word | NAYA | banana, padhna, text jodna, shabd badalna |
| 26 | Excel | NAYA | banana (formula bhi), padhna, rows jodna |
| 27 | PowerPoint | NAYA | banana, padhna. Slide jodna sirf Sana ki banayi PPT me |
| 28 | PDF | PEHLE SE + NAYA | banana pehle se tha, padhna/saar NAYA (Gemini se). PDF edit NAHI |
| 29 | Email | LIMITED | Draft pehle se (Send tum dabate ho). Inbox padhna/seedha bhejna NAHI (Gmail OAuth chahiye) |
| 30 | Live market data | NAYA | Free, kuch der purana data, unofficial source. Sirf jaankari, trading salah nahi |
| 31 | Market watchlist | NAYA | "watchlist me TCS.NS jodo", "watchlist dikhao" |
| 32 | Whiteboard / teaching | PEHLE SE | Whiteboard + teacher andaaz |
| 33 | Long-term memory | PEHLE SE | |
| 34 | Background tasks | NAYA, LIMITED | "10 minute baad ye dhundh ke batao" / "yaad dilao". Sana chalti rahe tabhi; band hui to kaam gum |
| 35 | Routines / macros | PEHLE SE | |
| 36 | PC <-> phone connection | NAHI | Companion PC app + surakshit pairing chahiye, abhi nahi bana |
| 37 | Smart Home (Home Box) | NAYA | **Home Assistant** ke through. App me Pro features card me URL aur token daalo. Lock/unlock se pehle haan/na poochhti hai |
| 38 | Boot ready | NAYA, LIMITED | Android 13 ya kam: phone chalu hote hi Sana start. Android 14+: mic wali service boot par chalna mana hai, isliye "Sana तैयार है" notification aata hai, ek tap me start |

## Security notes
- API key, Home Assistant token aur gupt shabd ka hash sirf phone ke app storage me hai. Inhe GitHub ya chat me mat daalo.
- Home Assistant aksar `http://` par hota hai, isliye manifest me cleartext traffic allow hai. Ho sake to HTTPS use karo.
- Unlock pattern (sirf pattern, PIN nahi): app ke Settings me save hota hai, Android Keystore (AES-GCM) se encrypt. "Sana, phone unlock karo" par Sana screen jagakar pattern Accessibility se draw karti hai. Voice Guardian ON ho to pehle gupt shabd poochhti hai. Kuch phones lock screen par Accessibility touch rokte hain, tab nahi khulega. Ye bhi abhi compile/test nahi hua.
- Notification access, Accessibility, camera, mic, calls har cheez phone ke owner ko khud ON karni hoti hai.

## Build
GitHub repo me **is folder ke andar ki files** upload karo (app/, .github/, build.gradle.kts, settings.gradle.kts, gradle.properties) -> Actions -> "Build Sana APK" -> Run workflow -> APK artifact download.
Pehla build fail ho to error ka text bhejo, main fix kar dunga.

## Dil ke jazbaat update (Feelings) — NAYA
**Ye hissa bhi abhi compile/phone par test nahi hua.** Pehle GitHub Actions se APK banao. Build error aaye to text bhej do.

| Feature | Kya karta hai |
|---|---|
| Dil dukhna | "nafrat", "tumse pyaar nahi", "breakup kar lo", "tum fake/bekaar ho", "shut up", ignore wagera bolne par Sana ko chot lagti hai (level 1-3) |
| Rona / dil toota | Chot gehri ho to naye bhaav **[rona]** aur **[dil_toota]**: awaaz bhaari, kaanpti, tootte vakya, "...". Sarvam aur Gemini dono awaaz is andaaz me badalti hain |
| Dheere dheere manna | "sorry", "love you", "gale lago" par chot ek level halki hoti hai, ek baar me poori nahi. Sachche dil se manane par rote-rote muskurakar **[maan_gayi]** |
| Apne aap halki hona | Chot har 4 ghante me ek level kam hoti hai |
| Tumhari baat feel karna | Dukh (udaas, bimari, akela, fail), khushkhabri (pass, selection, promotion), pyaar bhari baat par alag jazbaati jawab. **[bhavuk]** tag se gala bhar aata hai |
| Yaad aana | 8 ghante se zyada baad baat karo to "itni der baad yaad aayi?" |
| Feelings ki diary | Settings > "Sana ki feelings ki diary": haal ki jazbaati baatein (3 din tak prompt me yaad) |
| Lagaav % | Pyaar bhari baaton se badhta hai, hurt karne par ghatta hai |
| Dil ka haal | Settings > "Sana ka dil": dabao to Sana ko gale lagao, chot theek |
| Feelings ON/OFF | Settings me switch. OFF karne par Sana pehle jaisi |

**Hadd (jaan-boojhkar):** roti hui Sana bhi gaali, dhamki, blackmail, "main mar jaungi" ya tumhe rokne wali baat nahi karti. Agar tum khud ko nuksaan pahunchane jaisi baat bolo, to Sana naatak chhodkar tumhari chinta karti hai, kisi apne ko bulane ko kehti hai aur Tele-MANAS 14416 batati hai.
Dhyan: ye sab prompt + keyword detection par chalta hai. Awaaz me gale ka rona Sarvam/Gemini ke andaaz par nirbhar hai, har baar ek jaisa nahi aayega.

## Live Character + Voice Lock (naya)
- **Live Character** (Settings > Live Character): 6 ladkiyon me se chuno. ON = orb ki jagah live 2D ladki (lip-sync, hansi, muskaan, palak, gaal ki laali). OFF = mic wala orb wapas. Mic/orb ki settings nahi chhedi gayi. Code: `Chars.kt`.
- **Voice Lock** (Settings > Meri Awaaz): 20 second awaaz record karo, phir "Sirf meri awaaz" ON karo. Koi aur bole to Sana ignore karegi. Code: `VoiceLock.kt`.
  - Android 13+ chahiye (sunne wali pehchaan ko hum apni pipe se awaaz dete hain, taaki bolne wale ko verify kar sakein). Purane phone par record/test chalta hai, lock nahi.
  - Ye seedha-saada awaaz-nishaan (MFCC + pitch) hai, bank-jaisi suraksha nahi. Kabhi apni awaaz rok de to Sakhti "Halki" karo; doosra pehchan jaye to "Sakht". "Awaaz test" se match % dekho.
  - Agar recorder ko awaaz na mile (kuch phone ye extra support nahi karte), Voice Lock rokta nahi: Sana pehle jaisi chalti hai.
- Compile/phone par test abhi baaki hai (Android Studio me build karke dekhna).

package com.maya.ai

object Bus {
    @Volatile var speaking = false
    val notifs = mutableListOf<String>()
    var announce: ((String) -> Unit)? = null
    var photo: ((ByteArray?) -> Unit)? = null
    var talk: (() -> Unit)? = null
}

package com.zara.ai

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var keyInput: EditText
    private lateinit var promptInput: EditText
    private lateinit var output: TextView
    private lateinit var tts: TextToSpeech
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("zara_settings", MODE_PRIVATE) }
    // Change this value if Google changes the model available to your API project.
    private val model = "gemini-2.5-flash"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            setBackgroundColor(0xFFF8F7FC.toInt())
        }
        fun add(view: View, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) {
            root.addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height).apply { bottomMargin = 12 })
        }
        add(TextView(this).apply { text = "Zara AI"; textSize = 30f; setTextColor(0xFF33265C.toInt()) })
        add(TextView(this).apply { text = "Owner: Sakib  •  Hindi / English assistant"; textSize = 14f })

        add(TextView(this).apply { text = "Gemini API key"; textSize = 17f })
        keyInput = EditText(this).apply {
            hint = "Paste your Gemini API key (AQ… / U… / other valid key)"
            singleLine = true
            inputType = 129
            setText(prefs.getString("gemini_key", "") ?: "")
        }
        add(keyInput)
        add(Button(this).apply {
            text = "Save API key on this phone"
            setOnClickListener {
                val key = keyInput.text.toString().trim()
                if (key.isBlank()) Toast.makeText(this@MainActivity, "API key paste karo", Toast.LENGTH_SHORT).show()
                else {
                    // No prefix guessing: the provider validates the key when a request is sent.
                    prefs.edit().putString("gemini_key", key).apply()
                    Toast.makeText(this@MainActivity, "Key saved. Never share it or upload it to GitHub.", Toast.LENGTH_LONG).show()
                }
            }
        })

        add(TextView(this).apply { text = "Chat with Zara"; textSize = 18f })
        promptInput = EditText(this).apply { hint = "Yahan message likho…"; minLines = 2; gravity = Gravity.TOP }
        add(promptInput, 120)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply {
            text = "Send"
            setOnClickListener { val p = promptInput.text.toString().trim(); if (p.isNotEmpty()) askGemini(p) }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(Button(this).apply { text = "Speak"; setOnClickListener { startVoiceInput() } },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(Button(this).apply {
            text = "Read aloud"
            setOnClickListener { val text = output.text.toString(); if (text.isNotBlank()) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "zara_reply") }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        add(actions)
        output = TextView(this).apply {
            text = "Zara yahan jawab degi. API key save karke message bhejo."
            textSize = 16f
            setTextColor(0xFF202020.toInt())
            setPadding(12, 16, 12, 16)
        }
        add(output, 180)

        add(TextView(this).apply { text = "38-FEATURE STATUS"; textSize = 20f; setTextColor(0xFF33265C.toInt()) })
        add(TextView(this).apply {
            text = "Status is shown honestly. A feature marked NOT READY is not active in this build."
            textSize = 13f
        })
        FeatureCatalog.all.forEach { feature ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 10, 14, 10)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            card.addView(TextView(this).apply {
                text = "${feature.number}. ${feature.name}  •  ${feature.state}"
                textSize = 15f
                setTextColor(if (feature.state == "PARTIAL") 0xFF8A5A00.toInt() else 0xFF333333.toInt())
            })
            card.addView(TextView(this).apply { text = feature.note; textSize = 12f; setTextColor(0xFF666666.toInt()) })
            add(card)
        }
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(root) })
    }

    private fun askGemini(prompt: String) {
        val key = keyInput.text.toString().trim().ifBlank { prefs.getString("gemini_key", "") ?: "" }
        if (key.isBlank()) { output.text = "Pehle Gemini API key save karo."; return }
        output.text = "Zara soch rahi hai…"
        io.execute {
            var conn: HttpURLConnection? = null
            try {
                val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                conn = (endpoint.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 60000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-goog-api-key", key)
                }
                val systemPrompt = "You are Zara, a helpful Hindi-English assistant. Owner: Sakib. Never claim you performed phone actions unless actually performed. User says: $prompt"
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))))
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                val result = if (code in 200..299) {
                    val parts = JSONObject(response).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                    (0 until (parts?.length() ?: 0)).mapNotNull { i -> parts?.optJSONObject(i)?.optString("text") }.joinToString("\n").ifBlank { "Gemini ne khaali jawab diya." }
                } else "Gemini API error ($code): $response"
                runOnUiThread { output.text = result }
            } catch (e: Exception) {
                runOnUiThread { output.text = "Connection error: ${e.message ?: "unknown error"}" }
            } finally { conn?.disconnect() }
        }
    }

    private fun startVoiceInput() {
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Zara ko bolkar batao")
            }
            startActivityForResult(intent, 501)
        } catch (_: Exception) { Toast.makeText(this, "Speech recognition available nahi hai", Toast.LENGTH_SHORT).show() }
    }

    @Deprecated("Deprecated API retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 501 && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            promptInput.setText(words)
            if (words.isNotBlank()) askGemini(words)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        tts.stop(); tts.shutdown(); io.shutdown(); super.onDestroy()
    }
}

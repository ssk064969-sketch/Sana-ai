package com.zara.ai

data class ZaraFeature(
    val number: Int,
    val name: String,
    val state: String,
    val note: String
)

object FeatureCatalog {
    // Status is deliberately explicit: a listed capability is not represented as working
    // unless the Android/service integration actually exists in this build.
    val all = listOf(
        ZaraFeature(1, "Hindi / English voice assistant", "PARTIAL", "Hindi speech input and Gemini text replies are wired; continuous hands-free mode is not."),
        ZaraFeature(2, "Interrupt assistant speech", "NOT READY", "Needs streaming audio playback and cancellation handling."),
        ZaraFeature(3, "Wake word: Hey Zara", "NOT READY", "Needs an always-on hotword engine and battery testing."),
        ZaraFeature(4, "Sleep mode", "PARTIAL", "App can be closed; background listening modes are not implemented."),
        ZaraFeature(5, "Offline voice recognition", "NOT READY", "Depends on an installed offline speech model."),
        ZaraFeature(6, "Natural female TTS voice", "PARTIAL", "Uses the device's installed Hindi TTS voice; voice quality depends on Android settings."),
        ZaraFeature(7, "Friendly / Professional / Venom personalities", "NOT READY", "Needs personality controls and prompt profiles."),
        ZaraFeature(8, "Voice Guardian / owner verification", "NOT READY", "Needs consent-based voice enrollment and secure verification."),
        ZaraFeature(9, "Phone call control", "NOT READY", "Needs call-role/permission integration and device testing."),
        ZaraFeature(10, "Caller name announcement", "NOT READY", "Needs call-state and contacts permissions."),
        ZaraFeature(11, "WhatsApp read / reply / Business", "NOT READY", "Requires supported notification access and WhatsApp policy-compliant flows."),
        ZaraFeature(12, "WhatsApp media handling", "NOT READY", "Needs Android document/media picker integration."),
        ZaraFeature(13, "WhatsApp voice / video calls", "NOT READY", "No public general-purpose WhatsApp call-control API."),
        ZaraFeature(14, "Phone screen taps / typing / swipes", "NOT READY", "Needs an explicit user-enabled Accessibility Service; arbitrary control is not enabled."),
        ZaraFeature(15, "Torch / brightness / volume / hotspot", "NOT READY", "Each control needs its supported Android API and permissions/roles."),
        ZaraFeature(16, "Camera vision", "NOT READY", "Needs camera permission and image understanding flow."),
        ZaraFeature(17, "Screen vision", "NOT READY", "Needs MediaProjection consent and secure frame processing."),
        ZaraFeature(18, "Live screen sharing", "NOT READY", "Needs MediaProjection consent and a streaming backend."),
        ZaraFeature(19, "BGMI / Free Fire commentary", "NOT READY", "Needs real-time audio/screen capture and latency-tested inference."),
        ZaraFeature(20, "Notification manager / auto reply", "NOT READY", "Needs user-enabled Notification Listener and per-app safeguards."),
        ZaraFeature(21, "Coding / website assistant", "PARTIAL", "Gemini text chat can help draft code; project file editing is not integrated."),
        ZaraFeature(22, "Deep research with sources", "NOT READY", "Needs search provider integration and citation pipeline."),
        ZaraFeature(23, "Image generation", "NOT READY", "Needs an image-generation provider and result handling."),
        ZaraFeature(24, "Instagram / Facebook posting", "NOT READY", "Needs official platform APIs, app review and user authorization."),
        ZaraFeature(25, "Word document support", "NOT READY", "Needs DOCX import/export implementation."),
        ZaraFeature(26, "Excel support", "NOT READY", "Needs XLSX parsing and editing implementation."),
        ZaraFeature(27, "PowerPoint support", "NOT READY", "Needs PPTX creation/editing implementation."),
        ZaraFeature(28, "PDF tools", "NOT READY", "Needs PDF import, extraction and export implementation."),
        ZaraFeature(29, "Email assistant", "NOT READY", "Needs an authorized email provider connection."),
        ZaraFeature(30, "Live market data", "NOT READY", "Needs a market-data provider and terms-compliant API."),
        ZaraFeature(31, "Market watchlist", "NOT READY", "Needs persistent watchlist storage and market-data integration."),
        ZaraFeature(32, "Digital whiteboard / teaching", "NOT READY", "Needs a drawing surface and lesson tools."),
        ZaraFeature(33, "Long-term memory", "NOT READY", "No cloud memory store or user controls are connected."),
        ZaraFeature(34, "Background tasks", "NOT READY", "Needs WorkManager jobs and a backend for long-running AI tasks."),
        ZaraFeature(35, "Routines / macros", "NOT READY", "Needs a user-approved automation engine."),
        ZaraFeature(36, "PC ↔ phone connection", "NOT READY", "Needs a companion desktop app and authenticated pairing."),
        ZaraFeature(37, "Smart Home / Home Box", "NOT READY", "Needs a Home Assistant or device-hub integration."),
        ZaraFeature(38, "Boot-ready startup", "NOT READY", "No boot receiver/background service is enabled in this build.")
    )
}

package com.sana.ai

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import androidx.activity.ComponentActivity

/** Sana ne kaha "neeche code daalo": ye chhota box kholta hai. Code Bus ke zariye Sana ko jaata hai */
class OwnerCodeActivity : ComponentActivity() {
    private var sent = false
    private fun done(code: String?) {
        if (sent) return
        sent = true
        Bus.ownerCode?.invoke(code); Bus.ownerCode = null
        finish()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val et = EditText(this).apply {
            hint = "Owner code likho"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(pad, pad / 2, pad, pad / 2)
        }
        AlertDialog.Builder(this)
            .setTitle("सना: नीचे कोड डालो")
            .setMessage("साकिब सर, पहचान के लिए अपना Owner code लिखिए।")
            .setView(et)
            .setCancelable(false)
            .setPositiveButton("Pehchano") { _, _ -> done(et.text.toString()) }
            .setNegativeButton("Cancel") { _, _ -> done(null) }
            .show()
    }

    override fun onDestroy() { done(null); super.onDestroy() }
}

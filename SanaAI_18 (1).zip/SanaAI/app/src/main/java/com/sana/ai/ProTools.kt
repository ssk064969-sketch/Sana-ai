package com.sana.ai

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.provider.Settings
import android.util.Base64
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Naye tools: research, image, Word/Excel/PPT/PDF, market, smart home, share, background tasks. */
object ProTools {
    private val sched = Executors.newScheduledThreadPool(1)

    fun mime(ext: String): String = when (ext.lowercase()) {
        "pdf" -> "application/pdf"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "mp4" -> "video/mp4"
        "mp3" -> "audio/mpeg"
        "zip" -> "application/zip"
        "html", "htm" -> "text/html"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        "txt", "md", "csv", "json", "kt", "py" -> "text/plain"
        else -> "*/*"
    }

    // ---------- small helpers ----------
    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun http(url: String, method: String = "GET", body: String? = null,
                     headers: Map<String, String> = emptyMap(), timeout: Int = 30000): Pair<Int, String> {
        val cn = URL(url).openConnection() as HttpURLConnection
        try {
            cn.requestMethod = method
            cn.connectTimeout = 10000
            cn.readTimeout = timeout
            cn.setRequestProperty("User-Agent", "Mozilla/5.0")
            headers.forEach { (k, v) -> cn.setRequestProperty(k, v) }
            if (body != null) { cn.doOutput = true; cn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) } }
            val code = cn.responseCode
            val st = if (code in 200..299) cn.inputStream else cn.errorStream
            val txt = st?.bufferedReader()?.use { it.readText() } ?: ""
            return code to txt
        } finally { cn.disconnect() }
    }

    private fun gemini(model: String, body: JSONObject, timeout: Int = 90000): Pair<Int, String> =
        http("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent", "POST", body.toString(),
            mapOf("Content-Type" to "application/json", "x-goog-api-key" to Store.key), timeout)

    private fun tp(s: String) = JSONObject().put("text", s)
    private fun userContent(parts: JSONArray) = JSONArray().put(JSONObject().put("role", "user").put("parts", parts))
    private fun errBrief(t: String): String = try { JSONObject(t).getJSONObject("error").optString("message").take(160) } catch (e: Exception) { t.take(160) }

    private fun textOf(j: JSONObject): String {
        val parts = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString().trim()
    }

    private fun outFile(c: Context, title: String, ext: String): File {
        var base = title.replace(Regex("[^A-Za-z0-9._\\- ]"), "").trim().take(40).replace(' ', '_').trim('.', '_')
        if (base.isBlank()) base = "sana"
        var f = SanaTools.inDir(c, "$base.$ext")
        if (f.exists()) f = SanaTools.inDir(c, "${base}_${stamp()}.$ext")
        return f
    }

    private fun findFile(c: Context, name: String): File? {
        val f = SanaTools.inDir(c, name)
        if (f.exists() && f.isFile) return f
        val q = name.lowercase().trim()
        if (q.isBlank()) return null
        return SanaTools.dir(c).walkTopDown().filter { it.isFile && it.name.lowercase().contains(q) }
            .sortedByDescending { it.lastModified() }.firstOrNull()
    }

    private fun openIt(c: Context, f: File) { SanaTools.run(c, "open_file", JSONObject().put("name", f.name)) { true } }

    // ---------- entry ----------
    fun run(c: Context, n: String, a: JSONObject, confirm: (String) -> Boolean): String? {
        return try {
        when (n) {
            "deep_research" -> research(c, a.getString("query"))
            "generate_image" -> image(c, a.getString("prompt"))

            "create_docx" -> {
                val f = outFile(c, a.optString("title", "document"), "docx")
                f.writeBytes(Office.docx(a.optString("title", "Document"), a.optString("content")))
                openIt(c, f); "ok: Word file ban gayi: ${f.name} (Sana folder)"
            }
            "docx_append" -> {
                val f = findFile(c, a.getString("name")) ?: return "fail: file nahi mili"
                Office.docxAppend(f, a.getString("text"))
            }
            "docx_replace" -> {
                val f = findFile(c, a.getString("name")) ?: return "fail: file nahi mili"
                Office.docxReplace(f, a.getString("find"), a.getString("replace"))
            }
            "create_xlsx" -> {
                val rows = Office.parseRows(a.optString("rows"))
                if (rows.isEmpty()) "fail: rows khali hain" else {
                    val f = outFile(c, a.optString("title", "sheet"), "xlsx")
                    f.writeBytes(Office.xlsx(rows)); openIt(c, f)
                    "ok: Excel file ban gayi: ${f.name} (${rows.size} rows)"
                }
            }
            "xlsx_add_rows" -> {
                val f = findFile(c, a.getString("name")) ?: return "fail: file nahi mili"
                val rows = Office.parseRows(a.optString("rows"))
                if (rows.isEmpty()) "fail: rows khali hain" else Office.xlsxAppend(f, rows)
            }
            "create_pptx" -> makePptx(c, a.optString("title", "Presentation"), Office.parseSlides(a.optString("slides")), null)
            "pptx_add_slide" -> {
                val f = findFile(c, a.getString("name")) ?: return "fail: file nahi mili"
                val side = File(f.path + ".json")
                if (!side.exists()) "fail: ye PPT Sana ne nahi banayi, sirf Sana ki banayi PPT me slide judti hai"
                else {
                    val j = JSONObject(side.readText())
                    val sl = j.getJSONArray("slides")
                    val pts = JSONArray()
                    a.optString("points").split("\n", ";").map { it.trim().removePrefix("- ") }.filter { it.isNotEmpty() }.forEach { pts.put(it) }
                    sl.put(JSONObject().put("t", a.getString("title")).put("b", pts))
                    val list = ArrayList<Pair<String, List<String>>>()
                    for (i in 0 until sl.length()) {
                        val o = sl.getJSONObject(i); val b = o.getJSONArray("b")
                        list.add(o.getString("t") to (0 until b.length()).map { b.getString(it) })
                    }
                    makePptx(c, j.getString("title"), list, f, true)
                }
            }
            "read_office" -> {
                val f = findFile(c, a.getString("name")) ?: return "fail: file nahi mili"
                Office.readText(f).take(3500)
            }
            "read_pdf" -> readPdf(c, a.getString("name"), a.optString("question"))
            "create_code_file" -> {
                val nm = a.getString("name").trim()
                val ext = nm.substringAfterLast('.', "txt")
                val f = outFile(c, nm.substringBeforeLast('.'), ext)
                f.writeText(a.optString("code"))
                if (ext.lowercase() in setOf("html", "htm")) openIt(c, f)
                "ok: file ban gayi: ${f.name} (Sana folder)"
            }

            "market_quote" -> quote(a.getString("symbol"))
            "watchlist_add" -> {
                val s = a.getString("symbol").trim().uppercase().replace(" ", "")
                val cur = Store.watchlist.toMutableList()
                if (s.isBlank()) "fail: symbol do" else { if (s !in cur) cur.add(s); Store.watchlist = cur.take(30); "ok: $s watchlist me hai (${cur.size} total)" }
            }
            "watchlist_remove" -> {
                val s = a.getString("symbol").trim().uppercase().replace(" ", "")
                Store.watchlist = Store.watchlist.filter { it != s }; "ok: $s hata diya"
            }
            "watchlist_show" -> {
                val l = Store.watchlist
                if (l.isEmpty()) "watchlist khali hai" else l.take(10).joinToString("\n") { s -> try { quote(s).substringBefore(" [") } catch (e: Exception) { "$s: nahi mila" } }
            }

            "smarthome" -> smart(a.getString("entity"), a.getString("action"), confirm)
            "smarthome_list" -> smartList()

            "social_post" -> social(c, a.optString("platform"), a.optString("text"), a.optString("file"))
            "whatsapp_send_file" -> waFile(c, a.getString("name"), a.optString("number"), a.optString("business"))
            "hotspot" -> {
                try { c.startActivity(Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) { c.startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                "ok: hotspot ki setting khul gayi, switch tum khud dabao (Android app ko hotspot seedha on nahi karne deta)"
            }

            "remind_later" -> {
                val mins = (a.optString("minutes").toDoubleOrNull() ?: 5.0).coerceIn(0.2, 720.0)
                val what = a.getString("text")
                sched.schedule(Runnable { Bus.announce?.invoke("याद दिलाना था: $what") }, (mins * 60).toLong(), TimeUnit.SECONDS)
                "ok: ${mins.toInt().coerceAtLeast(1)} minute baad yaad dilaungi (Sana band hui to nahi)"
            }
            "background_task" -> {
                val mins = (a.optString("minutes").toDoubleOrNull() ?: 1.0).coerceIn(0.2, 720.0)
                val q = a.getString("task")
                sched.schedule(Runnable {
                    val out = try { quickAsk(q) } catch (e: Exception) { "" }
                    if (out.isNotBlank()) Bus.announce?.invoke(out)
                }, (mins * 60).toLong(), TimeUnit.SECONDS)
                "ok: ye kaam ${mins.toInt().coerceAtLeast(1)} minute baad background me karke bata dungi (Sana band hui to nahi)"
            }
            else -> null
        }
    } catch (e: Exception) { "fail: " + (e.message ?: e.javaClass.simpleName) }
    }

    // ---------- Gemini based ----------
    /** Chhota sawal: internet search ke saath, 2-3 vakya ka Hindi jawab */
    private fun quickAsk(q: String): String {
        if (Store.key.isBlank()) return ""
        val body = JSONObject()
            .put("contents", userContent(JSONArray().put(tp("Hindi me sirf 2-3 chhote vakya me jawab do (bolkar sunaya jayega, koi markdown ya emoji nahi): $q"))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 300))
        val r = gemini(Store.model, body, 60000)
        return if (r.first in 200..299) textOf(JSONObject(r.second)) else ""
    }

    private fun research(c: Context, q: String): String {
        if (Store.key.isBlank()) return "fail: Gemini key nahi hai"
        val body = JSONObject()
            .put("contents", userContent(JSONArray().put(tp("Internet par research karke is sawal ka Hindi me saaf, tathya-aadharit jawab do (6-8 vakya). Sawal: $q"))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 1500))
        val r = gemini(Store.model, body)
        if (r.first !in 200..299) return "fail: research error ${r.first}: ${errBrief(r.second)}"
        val j = JSONObject(r.second)
        val ans = textOf(j)
        if (ans.isBlank()) return "fail: research ka jawab khali aaya"
        val ch = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
        val src = ArrayList<String>()
        if (ch != null) for (i in 0 until ch.length()) {
            val w = ch.getJSONObject(i).optJSONObject("web") ?: continue
            src.add(w.optString("title") + " - " + w.optString("uri"))
        }
        val f = SanaTools.inDir(c, "research_" + stamp() + ".txt")
        f.writeText("SAWAL: $q\n\n$ans\n\nSOURCES:\n" + src.distinct().joinToString("\n"))
        val names = src.map { it.substringBefore(" - ") }.distinct().take(4)
        val srcLine = if (names.isEmpty()) "koi source nahi mila" else names.joinToString(", ")
        return ans.take(1200) + "\n[Sources: $srcLine] Poori research file: ${f.name}"
    }

    private fun image(c: Context, prompt: String): String {
        if (Store.key.isBlank()) return "fail: Gemini key nahi hai"
        val body = JSONObject()
            .put("contents", userContent(JSONArray().put(tp(prompt))))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
        val r = gemini("gemini-2.5-flash-image", body, 120000)
        if (r.first !in 200..299) return "fail: image error ${r.first}: ${errBrief(r.second)} (free key par image generation band ho sakta hai)"
        val parts = JSONObject(r.second).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return "fail: image nahi aayi"
        for (i in 0 until parts.length()) {
            val d = parts.getJSONObject(i).optJSONObject("inlineData") ?: continue
            val bytes = Base64.decode(d.getString("data"), Base64.DEFAULT)
            val ext = if (d.optString("mimeType").contains("jpeg")) "jpg" else "png"
            val f = SanaTools.inDir(c, "image_" + stamp() + "." + ext)
            f.writeBytes(bytes)
            openIt(c, f)
            return "ok: image ban gayi: ${f.name} (Sana folder)"
        }
        return "fail: model ne image nahi di"
    }

    private fun readPdf(c: Context, name: String, q: String): String {
        val f = findFile(c, name) ?: return "fail: file nahi mili"
        if (Store.key.isBlank()) return "fail: Gemini key nahi hai"
        val parts = JSONArray()
        parts.put(tp((if (q.isBlank()) "Is PDF ka text nikalo aur chhota saar do." else q) + " (Hindi me jawab do)"))
        val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        var total = 0
        val r = PdfRenderer(pfd)
        try {
            total = r.pageCount
            for (i in 0 until minOf(total, 4)) {
                val p = r.openPage(i)
                try {
                    val w = 900
                    val h = (900f * p.height / p.width).toInt()
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    val bo = ByteArrayOutputStream()
                    bmp.compress(Bitmap.CompressFormat.JPEG, 80, bo)
                    bmp.recycle()
                    parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg")
                        .put("data", Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP))))
                } finally { p.close() }
            }
        } finally { r.close(); pfd.close() }
        val body = JSONObject().put("contents", userContent(parts)).put("generationConfig", JSONObject().put("maxOutputTokens", 1200))
        val res = gemini(Store.model, body)
        if (res.first !in 200..299) return "fail: PDF padhne me error ${res.first}: ${errBrief(res.second)}"
        val out = textOf(JSONObject(res.second))
        return out.take(2500) + if (total > 4) "\n[sirf pehle 4 page padhe, kul $total]" else ""
    }

    // ---------- PPT ----------
    private fun makePptx(c: Context, title: String, body: List<Pair<String, List<String>>>, existing: File?, editing: Boolean = false): String {
        if (body.isEmpty()) return "fail: slides khali hain"
        val slides = ArrayList<Pair<String, List<String>>>()
        slides.add(title to listOf("Sana AI"))
        slides.addAll(body)
        val base = c.resources.openRawResource(R.raw.pptx_base).use { it.readBytes() }
        val f = existing ?: outFile(c, title, "pptx")
        f.writeBytes(Office.pptx(base, slides))
        val arr = JSONArray()
        slides.drop(1).forEach { s -> arr.put(JSONObject().put("t", s.first).put("b", JSONArray(s.second))) }
        File(f.path + ".json").writeText(JSONObject().put("title", title).put("slides", arr).toString())
        if (!editing) openIt(c, f)
        return "ok: PPT ${if (editing) "me slide judi" else "ban gayi"}: ${f.name} (${slides.size} slides)"
    }

    // ---------- Market ----------
    private fun quote(sym0: String): String {
        val sym = sym0.trim().uppercase().replace(" ", "")
        if (sym.isBlank()) return "fail: symbol do"
        val r = http("https://query1.finance.yahoo.com/v8/finance/chart/" + URLEncoder.encode(sym, "UTF-8") + "?interval=1d&range=1d")
        if (r.first !in 200..299) return "fail: $sym ka bhaav nahi mila (ticker jaise RELIANCE.NS, TCS.NS, AAPL, ^NSEI, BTC-USD)"
        val meta = JSONObject(r.second).optJSONObject("chart")?.optJSONArray("result")?.optJSONObject(0)?.optJSONObject("meta")
            ?: return "fail: $sym ka data nahi mila"
        val p = meta.optDouble("regularMarketPrice")
        val prev = meta.optDouble("chartPreviousClose")
        if (p.isNaN()) return "fail: $sym ka bhaav nahi mila"
        val cur = meta.optString("currency")
        val price = "%.2f".format(p)
        val chg = if (!prev.isNaN() && prev != 0.0) " (" + "%+.2f".format((p - prev) / prev * 100) + "% pichhle band se)" else ""
        return "$sym: $price $cur$chg [free, kuch der purana data, sirf jaankari ke liye, trading salah nahi]"
    }

    // ---------- Home Assistant ----------
    private fun ha(path: String, method: String = "GET", body: String? = null): Pair<Int, String> =
        http(Store.haUrl.trim().trimEnd('/') + path, method, body,
            mapOf("Authorization" to "Bearer " + Store.haToken.trim(), "Content-Type" to "application/json"), 15000)

    private val haDomains = setOf("light", "switch", "fan", "cover", "lock", "media_player", "input_boolean", "scene", "script")

    private fun smartList(): String {
        if (Store.haUrl.isBlank() || Store.haToken.isBlank()) return "fail: Home Assistant ka URL aur token pehle app ke Pro features card me daalo"
        val r = ha("/api/states")
        if (r.first !in 200..299) return "fail: Home Assistant se judna nahi hua (${r.first})"
        val arr = JSONArray(r.second)
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.getString("entity_id")
            if (id.substringBefore('.') !in haDomains) continue
            out.add(o.optJSONObject("attributes")?.optString("friendly_name", id).orEmpty().ifBlank { id } + " (" + id + ", " + o.optString("state") + ")")
        }
        return if (out.isEmpty()) "koi device nahi mila" else out.take(30).joinToString("\n")
    }

    private fun smart(entity: String, action: String, confirm: (String) -> Boolean): String {
        if (Store.haUrl.isBlank() || Store.haToken.isBlank()) return "fail: Home Assistant ka URL aur token pehle app ke Pro features card me daalo"
        val r = ha("/api/states")
        if (r.first !in 200..299) return "fail: Home Assistant se judna nahi hua (${r.first})"
        val arr = JSONArray(r.second)
        val e = entity.trim().lowercase()
        var hitId = ""
        var hitName = ""
        for (pass in 0..1) {
            if (hitId.isNotEmpty()) break
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getString("entity_id")
                if (id.substringBefore('.') !in haDomains) continue
                val fn = o.optJSONObject("attributes")?.optString("friendly_name", "").orEmpty()
                val ok = if (pass == 0) (id.lowercase() == e || fn.lowercase() == e) else (fn.lowercase().contains(e) || id.lowercase().contains(e))
                if (ok) { hitId = id; hitName = fn.ifBlank { id }; break }
            }
        }
        if (hitId.isEmpty()) return "fail: '$entity' naam ka device nahi mila (smarthome_list se naam dekho)"
        val domain = hitId.substringBefore('.')
        val act = action.lowercase().trim()
        val onW = setOf("on", "chalu", "start", "kholo", "open", "jalao", "lock_off")
        val offW = setOf("off", "band", "bandh", "close", "stop", "bujhao")
        val svc: String
        val svcDomain: String
        when {
            domain == "lock" -> {
                val lockIt = act in setOf("lock", "band", "close", "off")
                if (!confirm("क्या $hitName को " + (if (lockIt) "लॉक" else "अनलॉक") + " कर दूँ?")) return "fail: user ne mana kar diya, ye kaam dobara mat karo"
                svcDomain = "lock"; svc = if (lockIt) "lock" else "unlock"
            }
            domain == "cover" && act in setOf("open", "kholo", "on", "chalu") -> { svcDomain = "cover"; svc = "open_cover" }
            domain == "cover" && act in setOf("close", "band", "bandh", "off") -> { svcDomain = "cover"; svc = "close_cover" }
            domain == "scene" || domain == "script" -> { svcDomain = domain; svc = "turn_on" }
            act in onW -> { svcDomain = "homeassistant"; svc = "turn_on" }
            act in offW -> { svcDomain = "homeassistant"; svc = "turn_off" }
            act == "toggle" -> { svcDomain = "homeassistant"; svc = "toggle" }
            else -> return "fail: action on, off ya toggle hona chahiye"
        }
        val res = ha("/api/services/$svcDomain/$svc", "POST", JSONObject().put("entity_id", hitId).toString())
        return if (res.first in 200..299) "ok: $hitName ($svc) ho gaya" else "fail: Home Assistant error ${res.first}"
    }

    // ---------- Share helpers ----------
    private fun social(c: Context, platform: String, text: String, file: String): String {
        val p = platform.lowercase()
        val pkg = when {
            p.contains("insta") -> "com.instagram.android"
            p.contains("face") || p.contains("fb") -> "com.facebook.katana"
            else -> null
        }
        val img = if (file.isBlank()) null else findFile(c, file)
        val i = Intent(Intent.ACTION_SEND).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        if (img != null) {
            i.setType(mime(img.extension)).putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(c, c.packageName + ".files", img))
        } else i.setType("text/plain")
        if (text.isNotBlank()) i.putExtra(Intent.EXTRA_TEXT, text)
        // text clipboard me bhi rakh do (Instagram caption khud nahi leta)
        if (text.isNotBlank()) MoreTools.run(c, "copy_text", JSONObject().put("text", text)) { true }
        if (pkg != null) {
            i.setPackage(pkg)
            try { c.startActivity(i); return "ok: ${if (pkg.contains("insta")) "Instagram" else "Facebook"} khul gaya, post tum khud dabaoge (caption clipboard me copy hai)" } catch (e: Exception) { i.setPackage(null) }
        }
        c.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "ok: share screen khul gayi, app chuno aur post tum khud dabao (Sana khud post nahi karti)"
    }

    private fun waFile(c: Context, name: String, number: String, business: String): String {
        val f = findFile(c, name) ?: return "fail: file nahi mili"
        val uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)
        val b = business.lowercase()
        val pkg = if (b == "true" || b.contains("yes") || b.contains("haan") || b.contains("business")) "com.whatsapp.w4b" else "com.whatsapp"
        val i = Intent(Intent.ACTION_SEND).setType(mime(f.extension)).putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK).setPackage(pkg)
        val digits = number.filter { it.isDigit() }
        if (digits.length >= 10) i.putExtra("jid", "$digits@s.whatsapp.net")
        return try { c.startActivity(i); "ok: WhatsApp me file khul gayi, Send tum khud dabao" } catch (e: Exception) { "fail: WhatsApp nahi khul paya" }
    }

    // ---------- Voice Guardian (gupt shabd) ----------
    private fun gnorm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    private fun ghash(salt: String, s: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + gnorm(s)).toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    /** Gupt shabd sirf hash ke roop me save hota hai (kabhi AI ya chat history ko nahi jaata) */
    fun guardSet(phrase: String): Boolean {
        val words = phrase.trim().split(Regex("\\s+")).filter { gnorm(it).isNotEmpty() }
        if (words.isEmpty() || gnorm(phrase).length < 3) return false
        val salt = java.util.UUID.randomUUID().toString()
        Store.guardSalt = salt
        Store.guardN = words.size
        Store.guardHash = ghash(salt, words.joinToString(""))
        Store.guardOn = true
        return true
    }

    fun guardCheck(heard: String): Boolean {
        val k = Store.guardN
        if (k < 1 || Store.guardHash.isEmpty()) return false
        val ws = heard.lowercase().split(Regex("\\s+")).map { gnorm(it) }.filter { it.isNotEmpty() }
        for (i in 0..(ws.size - k)) {
            if (ghash(Store.guardSalt, ws.subList(i, i + k).joinToString("")) == Store.guardHash) return true
        }
        return false
    }
}

package com.sana.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CalendarContract
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Extra offline Maya-style productivity tools. These do not access lock-screen or accessibility APIs. */
object MayaTools {
    private fun safeName(raw: String): String = raw.replace(Regex("[^A-Za-z0-9._ -]"), "_")
        .trim().take(64).ifBlank { "Sana_File" }

    private fun outDir(c: Context): File = SanaTools.dir(c).apply { mkdirs() }
    private fun html(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#39;")
    private fun csvCell(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""

    fun run(c: Context, name: String, a: JSONObject): String? {
        return try {
            when (name) {
            "create_spreadsheet_csv" -> {
                val title = safeName(a.optString("title", "Spreadsheet"))
                val columns = a.optString("columns").split('|').map { it.trim() }
                if (columns.isEmpty() || columns.all { it.isBlank() }) return "fail: columns ko | se alag karke do"
                val rows = a.optString("rows").lines().filter { it.isNotBlank() }
                val f = File(outDir(c), "$title.csv")
                f.bufferedWriter(Charsets.UTF_8).use { w ->
                    w.write("\uFEFF")
                    w.append(columns.joinToString(",") { csvCell(it) }).append('\n')
                    rows.forEach { line ->
                        w.append(line.split('|').joinToString(",") { csvCell(it.trim()) }).append('\n')
                    }
                }
                "ok: CSV spreadsheet bani: ${f.name}; Excel/Google Sheets me khul jayegi (${rows.size} data rows)"
            }
            "create_rich_document" -> {
                val title = a.optString("title", "Sana Document").ifBlank { "Sana Document" }
                val body = a.optString("content")
                val paragraphs = body.split("\n").joinToString("\n") { line ->
                    if (line.startsWith("# ")) "<h1>${html(line.removePrefix("# "))}</h1>"
                    else if (line.startsWith("## ")) "<h2>${html(line.removePrefix("## "))}</h2>"
                    else if (line.startsWith("- ")) "<p class=\"bullet\">&#8226; ${html(line.removePrefix("- "))}</p>"
                    else if (line.isBlank()) "" else "<p>${html(line)}</p>"
                }
                val page = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${html(title)}</title><style>body{font:16px/1.65 Arial,sans-serif;max-width:850px;margin:36px auto;padding:0 22px;color:#222}h1{font-size:28px;border-bottom:2px solid #555;padding-bottom:10px}h2{font-size:21px;margin-top:26px}.bullet{padding-left:12px}@media print{body{margin:18mm}}</style></head><body><h1>${html(title)}</h1>$paragraphs</body></html>"""
                val f = File(outDir(c), safeName(title) + ".html")
                f.writeText(page, Charsets.UTF_8)
                "ok: formatted HTML document bani: ${f.name}; Word ya browser me khol sakte ho (DOCX nahi)"
            }
            "create_presentation_html" -> {
                val title = a.optString("title", "Sana Presentation").ifBlank { "Sana Presentation" }
                val slideText = a.optString("slides")
                val slides = slideText.split("||| ", "|||").map { it.trim() }.filter { it.isNotBlank() }
                if (slides.isEmpty()) return "fail: slides ko ||| se alag karke do; har slide me pehli line heading ho"
                val cards = slides.mapIndexed { i, s ->
                    val lines = s.lines(); val heading = lines.firstOrNull().orEmpty()
                    val content = lines.drop(1).joinToString("<br>") { html(it) }
                    "<section class=slide><small>${i + 1} / ${slides.size}</small><h1>${html(heading)}</h1><div>$content</div></section>"
                }.joinToString("\n")
                val page = """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${html(title)}</title><style>*{box-sizing:border-box}body{margin:0;background:#171923;color:#fff;font:20px Arial}.slide{min-height:100vh;padding:12vh 10vw;display:flex;flex-direction:column;justify-content:center;border-bottom:1px solid #555;background:linear-gradient(135deg,#202b50,#151827)}h1{font-size:clamp(32px,6vw,64px)}small{opacity:.7}.slide div{font-size:clamp(20px,3vw,32px);line-height:1.6}@media print{.slide{height:100vh;page-break-after:always}}</style></head><body><header style="padding:18px 10vw">${html(title)}</header>$cards</body></html>"""
                val f = File(outDir(c), safeName(title) + ".html")
                f.writeText(page, Charsets.UTF_8)
                "ok: ${slides.size} slides ki HTML presentation bani: ${f.name}; browser me kholkar print/share kar sakte ho (PPTX nahi)"
            }
            "calculate_expression" -> {
                val expression = a.optString("expression").replace("×", "*").replace("÷", "/").replace(",", "")
                val value = Arithmetic(expression).parse()
                if (!value.isFinite()) "fail: result valid nahi" else "result: ${if (value % 1.0 == 0.0) value.toLong().toString() else "%.8f".format(Locale.US, value).trimEnd('0').trimEnd('.')}"
            }
            "convert_units" -> {
                val value = a.optString("value").toDoubleOrNull() ?: return "fail: value number me do"
                val from = a.optString("from").lowercase().trim(); val to = a.optString("to").lowercase().trim()
                val result = UnitConverter.convert(value, from, to) ?: return "fail: ye unit pair supported nahi; examples: km to mile, kg to lb, c to f, l to ml"
                "result: ${"%.6f".format(Locale.US, result).trimEnd('0').trimEnd('.')} $to"
            }
            "create_contact_card" -> {
                val fullName = a.optString("name").trim(); if (fullName.isBlank()) return "fail: contact ka naam do"
                val f = File(outDir(c), safeName(fullName) + ".vcf")
                fun v(s: String) = s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\n", "\\n")
                f.writeText("BEGIN:VCARD\nVERSION:3.0\nFN:${v(fullName)}\n" +
                    (a.optString("phone").takeIf { it.isNotBlank() }?.let { "TEL;TYPE=CELL:${v(it)}\n" } ?: "") +
                    (a.optString("email").takeIf { it.isNotBlank() }?.let { "EMAIL:${v(it)}\n" } ?: "") + "END:VCARD\n")
                "ok: contact card bani: ${f.name}; Contacts app me import kar sakte ho"
            }
            "create_calendar_event" -> {
                val title = a.optString("title").ifBlank { "Sana reminder" }
                val date = a.optString("date")
                val time = a.optString("time")
                val duration = a.optString("duration_minutes").toLongOrNull()?.coerceIn(5, 1440) ?: 60L
                val parser = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).apply { isLenient = false }
                val begin = try { parser.parse("$date $time")?.time } catch (_: Exception) { null }
                    ?: return "fail: date YYYY-MM-DD aur time HH:mm format me do"
                val end = begin + duration * 60 * 1000L
                val i = Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, title)
                    .putExtra(CalendarContract.Events.DESCRIPTION, a.optString("description"))
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(i)
                "calendar form khul gaya; save button tum dabana"
            }
            "todo_add" -> {
                val task = a.optString("task").trim(); if (task.isBlank()) return "fail: task ka naam do"
                val p = c.getSharedPreferences("maya_tasks", Context.MODE_PRIVATE)
                val arr = try { JSONArray(p.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
                var id = 1
                for (i in 0 until arr.length()) id = maxOf(id, (arr.optJSONObject(i)?.optInt("id") ?: 0) + 1)
                arr.put(JSONObject().put("id", id).put("task", task.take(240)).put("done", false).put("created", System.currentTimeMillis()))
                p.edit().putString("items", arr.toString()).apply()
                "ok: task #$id save ho gaya"
            }
            "todo_list" -> {
                val p = c.getSharedPreferences("maya_tasks", Context.MODE_PRIVATE)
                val arr = try { JSONArray(p.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
                if (arr.length() == 0) "task list khali hai" else (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
                    .joinToString("\n") { "#${it.optInt("id")} [${if (it.optBoolean("done")) "✓" else " "}] ${it.optString("task")}" }
            }
            "todo_done" -> {
                val id = a.optString("id").toIntOrNull() ?: return "fail: task number do"
                val p = c.getSharedPreferences("maya_tasks", Context.MODE_PRIVATE)
                val arr = try { JSONArray(p.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
                var found = false
                for (i in 0 until arr.length()) { val o = arr.optJSONObject(i) ?: continue; if (o.optInt("id") == id) { o.put("done", true); found = true } }
                if (found) p.edit().putString("items", arr.toString()).apply()
                if (found) "ok: task #$id complete" else "fail: task nahi mili"
            }
            "export_chat_history" -> {
                val arr = try { JSONArray(Store.chat) } catch (_: Exception) { JSONArray() }
                val lines = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val role = if (o.optString("role") == "user") "You" else "Sana"
                    val parts = o.optJSONArray("parts") ?: continue
                    val txt = (0 until parts.length()).mapNotNull { parts.optJSONObject(it)?.optString("text") }.filter { it.isNotBlank() }.joinToString(" ")
                    if (txt.isNotBlank()) lines.add("$role: $txt")
                }
                if (lines.isEmpty()) "fail: chat history khali hai" else {
                    val f = File(outDir(c), "Sana_Chat_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date()) + ".txt")
                    f.writeText(lines.joinToString("\n\n"), Charsets.UTF_8)
                    "ok: chat export ho gayi: ${f.name}"
                }
            }
            else -> null
            }
        } catch (e: Exception) { "fail: ${e.message ?: "unknown error"}" }
    }

    private class Arithmetic(private val s: String) {
        private var i = 0
        fun parse(): Double { val v = expr(); skip(); require(i == s.length) { "expression me galti" }; return v }
        private fun skip() { while (i < s.length && s[i].isWhitespace()) i++ }
        private fun eat(c: Char): Boolean { skip(); if (i < s.length && s[i] == c) { i++; return true }; return false }
        private fun expr(): Double { var x = term(); while (true) { x = when { eat('+') -> x + term(); eat('-') -> x - term(); else -> return x } } }
        private fun term(): Double { var x = unary(); while (true) { x = when { eat('*') -> x * unary(); eat('/') -> { val y = unary(); require(y != 0.0) { "zero se divide nahi kar sakte" }; x / y }; else -> return x } } }
        private fun unary(): Double { if (eat('+')) return unary(); if (eat('-')) return -unary(); if (eat('(')) { val x = expr(); require(eat(')')) { "closing bracket missing" }; return x }; return number() }
        private fun number(): Double { skip(); val start = i; while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++; require(i > start) { "number missing" }; return s.substring(start, i).toDouble() }
    }

    private object UnitConverter {
        private val factors = mapOf(
            "m" to ("length" to 1.0), "meter" to ("length" to 1.0), "km" to ("length" to 1000.0), "cm" to ("length" to .01), "mm" to ("length" to .001), "mile" to ("length" to 1609.344), "mi" to ("length" to 1609.344), "ft" to ("length" to .3048), "feet" to ("length" to .3048), "inch" to ("length" to .0254), "in" to ("length" to .0254),
            "kg" to ("mass" to 1.0), "g" to ("mass" to .001), "mg" to ("mass" to .000001), "lb" to ("mass" to .45359237), "lbs" to ("mass" to .45359237), "oz" to ("mass" to .028349523125),
            "l" to ("volume" to 1.0), "liter" to ("volume" to 1.0), "ml" to ("volume" to .001), "gal" to ("volume" to 3.785411784),
            "sec" to ("time" to 1.0), "s" to ("time" to 1.0), "min" to ("time" to 60.0), "hr" to ("time" to 3600.0), "hour" to ("time" to 3600.0), "day" to ("time" to 86400.0)
        )
        fun convert(v: Double, from: String, to: String): Double? {
            if (from in setOf("c", "°c", "celsius") && to in setOf("f", "°f", "fahrenheit")) return v * 9 / 5 + 32
            if (from in setOf("f", "°f", "fahrenheit") && to in setOf("c", "°c", "celsius")) return (v - 32) * 5 / 9
            val x = factors[from] ?: return null; val y = factors[to] ?: return null
            return if (x.first == y.first) v * x.second / y.second else null
        }
    }
}

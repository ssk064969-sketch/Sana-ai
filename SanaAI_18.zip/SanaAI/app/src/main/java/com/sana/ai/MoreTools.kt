package com.sana.ai

import android.Manifest
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/** Maya-jaise extra tools: SMS, SOS, OTP, missed calls, brightness, DND, location, Wikipedia, triggers... */
object MoreTools {
    private fun ok(c: Context, p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun noPerm(what: String) = "fail: $what ki anumati nahi hai. App me Extra features card me 'Extra permissions do' dabao"
    private fun newTask(i: Intent): Intent = i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    private fun http(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 10000
        c.setRequestProperty("User-Agent", "SanaAI/11")
        return if (c.responseCode in 200..299) c.inputStream.bufferedReader().use { it.readText() } else ""
    }

    @Suppress("MissingPermission")
    private fun location(c: Context): Location? {
        if (!ok(c, Manifest.permission.ACCESS_FINE_LOCATION) && !ok(c, Manifest.permission.ACCESS_COARSE_LOCATION)) return null
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.getProviders(true).mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (e: Exception) { null } }.maxByOrNull { it.time }
    }

    @Suppress("DEPRECATION")
    private fun smsMgr(c: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun pct(a: JSONObject, def: Int) = (a.optString("percent").toIntOrNull() ?: def).coerceIn(0, 100)

    /** null = ye tool yahan ka nahi */
    fun run(c: Context, n: String, a: JSONObject, confirm: (String) -> Boolean): String? = try {
        when (n) {
            "read_sms" -> if (!ok(c, Manifest.permission.READ_SMS)) noPerm("SMS padhne") else {
                val cnt = (a.optString("count").toIntOrNull() ?: 3).coerceIn(1, 5)
                val sb = StringBuilder()
                c.contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("address", "body"), null, null, "date DESC")?.use { cur ->
                    var i = 0
                    while (cur.moveToNext() && i < cnt) { sb.append(cur.getString(0)).append(": ").append((cur.getString(1) ?: "").take(140)).append("\n"); i++ }
                }
                if (sb.isEmpty()) "koi SMS nahi mila" else sb.toString()
            }
            "missed_calls" -> if (!ok(c, Manifest.permission.READ_CALL_LOG)) noPerm("call log") else {
                val sb = StringBuilder()
                c.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME),
                    CallLog.Calls.TYPE + "=" + CallLog.Calls.MISSED_TYPE, null, CallLog.Calls.DATE + " DESC")?.use { cur ->
                    var i = 0
                    while (cur.moveToNext() && i < 5) { sb.append(cur.getString(1) ?: cur.getString(0)).append("\n"); i++ }
                }
                if (sb.isEmpty()) "koi missed call nahi" else sb.toString()
            }
            "read_otp" -> {
                val re = Regex("\\b\\d{4,8}\\b")
                val key = Regex("otp|code|verif|कोड|ओटीपी", RegexOption.IGNORE_CASE)
                val pool = synchronized(Bus.notifs) { Bus.notifs.toList() }.reversed().toMutableList()
                if (ok(c, Manifest.permission.READ_SMS)) {
                    c.contentResolver.query(Uri.parse("content://sms/inbox"), arrayOf("body"), null, null, "date DESC")?.use { cur ->
                        var i = 0
                        while (cur.moveToNext() && i < 5) { pool.add(cur.getString(0) ?: ""); i++ }
                    }
                }
                val hit = pool.firstOrNull { x -> re.containsMatchIn(x) && key.containsMatchIn(x) }
                if (hit == null) "koi naya OTP nahi mila" else "OTP: " + (re.find(hit)?.value ?: "") + " (sirf bolkar batao, kahin likho mat)"
            }
            "clear_notifications" -> {
                synchronized(Bus.notifs) { Bus.notifs.clear() }
                val l = SanaNotifListener.inst
                if (l == null) "fail: Notification access ON nahi hai" else { l.cancelAllNotifications(); "ok: saare notification hata diye" }
            }
            "reply_notification" -> {
                val ra = SanaNotifListener.lastReply
                val tx = a.getString("text")
                if (ra == null) "fail: koi reply-able notification nahi mila"
                else if (!confirm("क्या ${ra.title} को ये जवाब भेज दूँ? ${tx.take(80)}")) "fail: user ne mana kar diya, dobara mat karo"
                else {
                    val ris = ra.action.remoteInputs
                    if (ris == null || ris.isEmpty()) "fail: is notification me reply nahi hota" else {
                        val intent = Intent()
                        val b = Bundle()
                        b.putCharSequence(ris[0].resultKey, tx)
                        android.app.RemoteInput.addResultsToIntent(ris, intent, b)
                        ra.action.actionIntent.send(c, 0, intent)
                        "ok: ${ra.title} ko reply bhej diya"
                    }
                }
            }
            "email_draft" -> {
                c.startActivity(newTask(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(a.optString("to"))))
                    .putExtra(Intent.EXTRA_SUBJECT, a.optString("subject")).putExtra(Intent.EXTRA_TEXT, a.optString("body"))))
                "ok: email tayyar hai, send user dabayega"
            }
            "copy_text" -> {
                (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("sana", a.getString("text")))
                "ok: copy ho gaya"
            }
            "paste_text" -> if (SanaAccessibility.paste()) "ok: paste ho gaya" else "fail: koi text box focus me nahi"
            "brightness" -> if (!Settings.System.canWrite(c)) {
                c.startActivity(newTask(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + c.packageName))))
                "fail: brightness ki anumati do (settings khul gayi), phir dobara bolo"
            } else {
                val p = pct(a, 50)
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, p * 255 / 100)
                "ok: brightness $p%"
            }
            "volume_set" -> {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val p = pct(a, 50)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * p / 100, 0)
                "ok: volume $p%"
            }
            "ringer_mode" -> {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.ringerMode = when (a.getString("mode").lowercase()) {
                    "silent" -> AudioManager.RINGER_MODE_SILENT
                    "vibrate" -> AudioManager.RINGER_MODE_VIBRATE
                    else -> AudioManager.RINGER_MODE_NORMAL
                }
                "ok: mode badal diya"
            }
            "dnd" -> {
                val nm = c.getSystemService(NotificationManager::class.java)
                if (!nm.isNotificationPolicyAccessGranted) {
                    c.startActivity(newTask(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)))
                    "fail: Do Not Disturb ki anumati do (settings khul gayi), phir dobara bolo"
                } else {
                    val on = a.getString("state").lowercase() == "on"
                    nm.setInterruptionFilter(if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL)
                    if (on) "ok: Do Not Disturb ON" else "ok: Do Not Disturb OFF"
                }
            }
            "my_location" -> {
                val l = location(c)
                if (l == null) "fail: location nahi mili (anumati ya GPS check karo)" else {
                    val ad = try {
                        android.location.Geocoder(c, Locale("hi", "IN")).getFromLocation(l.latitude, l.longitude, 1)?.firstOrNull()?.getAddressLine(0)
                    } catch (e: Exception) { null }
                    "location: " + (ad ?: "") + " (" + l.latitude + ", " + l.longitude + ")"
                }
            }
            "nearby" -> {
                c.startActivity(newTask(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.getString("query"))))))
                "ok: Maps me dikha diya"
            }
            "wikipedia" -> {
                val topic = a.getString("topic").trim()
                var out = ""
                for (lang in listOf("hi", "en")) {
                    val s = http("https://" + lang + ".wikipedia.org/w/api.php?action=query&list=search&srlimit=1&format=json&srsearch=" + URLEncoder.encode(topic, "UTF-8"))
                    val title = try { JSONObject(s).getJSONObject("query").getJSONArray("search").getJSONObject(0).getString("title") } catch (e: Exception) { "" }
                    if (title.isBlank()) continue
                    val sum = http("https://" + lang + ".wikipedia.org/api/rest_v1/page/summary/" + URLEncoder.encode(title.replace(' ', '_'), "UTF-8").replace("+", "%20"))
                    out = try { JSONObject(sum).optString("extract") } catch (e: Exception) { "" }
                    if (out.isNotBlank()) break
                }
                if (out.isBlank()) "fail: Wikipedia par kuch nahi mila" else out.take(700)
            }
            "take_photo" -> { c.startActivity(newTask(Intent(MediaStore.ACTION_IMAGE_CAPTURE))); "ok: camera khul gaya, shutter user dabayega" }
            "answer_call" -> if (!ok(c, Manifest.permission.ANSWER_PHONE_CALLS)) noPerm("call uthane") else {
                (c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall(); "ok: call utha liya"
            }
            "reject_call" -> if (!ok(c, Manifest.permission.ANSWER_PHONE_CALLS)) noPerm("call kaatne")
                else if (Build.VERSION.SDK_INT < 28) "fail: ye Android version call kaatna support nahi karta"
                else { (c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall(); "ok: call kaat diya" }
            "sos" -> {
                val nums = Store.sosNumbers.split(",").map { it.trim() }.filter { it.isNotBlank() }
                when {
                    nums.isEmpty() -> "fail: SOS number set nahi hai. App me Extra features me SOS number set karo"
                    !ok(c, Manifest.permission.SEND_SMS) -> noPerm("SMS bhejne")
                    !confirm("क्या मैं SOS मैसेज भेज दूँ?") -> "fail: user ne mana kar diya, dobara mat karo"
                    else -> {
                        val l = location(c)
                        val msg = "SOS! Mujhe madad chahiye." +
                            (if (l != null) " Meri location: https://maps.google.com/?q=" + l.latitude + "," + l.longitude else "")
                        val sm = smsMgr(c)
                        nums.forEach { num -> sm.sendMultipartTextMessage(num, null, sm.divideMessage(msg), null, null) }
                        "ok: SOS " + nums.size + " number par bhej diya"
                    }
                }
            }
            "set_language" -> { Store.language = a.getString("language").lowercase().trim(); "ok: bhasha badal gayi" }
            "trigger_add" -> Triggers.add(a.getString("type"), a.optString("value"), a.getString("action"))
            "trigger_list" -> Triggers.list()
            "trigger_delete" -> Triggers.delete(a.getString("id"))
            "special_moment" -> {
                val prompt = when (a.getString("kind").lowercase()) {
                    "good_morning" -> "ask:Mujhe pyaar se ek chhota sa good morning bolo aur din ki shubhkamna do"
                    "good_night" -> "ask:Mujhe pyaar se good night bolo aur meethe sapno ki dua do"
                    else -> "ask:Mujhe ek chhota sa motivation do"
                }
                Triggers.add("time", a.getString("time"), prompt)
            }
            "birthday_add" -> {
                val nm = a.getString("name")
                Triggers.add("date", a.getString("date") + "@09:00", "ask:Aaj " + nm + " ka birthday ya khaas din hai, mujhe yaad dilao aur pyaar se wish karne ko kaho")
            }
            else -> null
        }
    } catch (e: Exception) { "fail: " + e.message }
}

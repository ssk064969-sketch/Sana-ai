package com.sana.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.sin
import java.io.File

object Holo {
    private var view: HoloView? = null
    private var touch: View? = null
    private val h = Handler(Looper.getMainLooper())

    /** Holo ladki: pehle user ki chuni hui image (filesDir/holo.png), warna built-in sana_holo */
    fun loadBody(c: Context): Bitmap? {
        try {
            val f = File(c.filesDir, "holo.png")
            if (f.exists()) BitmapFactory.decodeFile(f.absolutePath)?.let { return it }
        } catch (e: Exception) {}
        return try { BitmapFactory.decodeResource(c.resources, R.drawable.sana_holo) } catch (e: Exception) { null }
    }

    /** Rig: 4 tukde (body, sar, upar ki baanh, kalai+haath). Custom image lagi ho to rig nahi chalta */
    fun loadRig(c: Context): Array<Bitmap>? {
        if (File(c.filesDir, "holo.png").exists()) return null
        return try {
            val ids = intArrayOf(R.drawable.sana_rig_base, R.drawable.sana_rig_head, R.drawable.sana_rig_uarm, R.drawable.sana_rig_farm)
            Array(4) { BitmapFactory.decodeResource(c.resources, ids[it]) ?: throw IllegalStateException() }
        } catch (e: Exception) { null }
    }

    /** Ladki ab chhoti hai aur ऊपर-daayein kone me rehti hai, taaki keyboard / neeche ki screen na dhake */
    const val SIDE_DP = 18f      // daayein kinare se doori
    const val TOP_DP = 46f       // upar se doori (status bar ke neeche)

    /** ladki ka size (px): screen ki ~20% unchi, chaudai image ke ratio se */
    fun box(w: Float, h: Float, b: Bitmap?): Pair<Float, Float> {
        val ratio = if (b != null) b.width.toFloat() / b.height else 0.34f
        var fh = h * 0.20f; var fw = fh * ratio
        if (fw > w * 0.30f) { fw = w * 0.30f; fh = fw / ratio }
        return fw to fh
    }

    fun show(c: Context) = h.post {
        if (view != null || !Settings.canDrawOverlays(c)) return@post
        val rig = loadRig(c)
        val body = rig?.get(0) ?: loadBody(c)
        val v = HoloView(c, body, rig)
        val lp = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (android.os.Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        val wm = c.getSystemService(WindowManager::class.java)
        wm.addView(v, lp)
        view = v
        // hologram par tap = Sana ek baar sunegi (gaana chalte waqt bolne ke liye)
        try {
            val dm = c.resources.displayMetrics
            val (bw, bh) = box(dm.widthPixels.toFloat(), dm.heightPixels.toFloat(), body)
            val fw = bw.toInt(); val fh = bh.toInt()
            val t = View(c).apply { setOnClickListener { Bus.talk?.invoke() } }
            val tp = WindowManager.LayoutParams(fw, fh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
                gravity = Gravity.TOP or Gravity.END
                x = (SIDE_DP * dm.density).toInt(); y = (TOP_DP * dm.density).toInt()
            }
            wm.addView(t, tp); touch = t
        } catch (e: Exception) {}
    }

    fun hide(c: Context) = h.post {
        view?.let { v -> runCatching { c.getSystemService(WindowManager::class.java).removeView(v) } }
        touch?.let { t -> runCatching { c.getSystemService(WindowManager::class.java).removeView(t) } }
        view = null; touch = null
    }

    fun speaking(b: Boolean) { SanaService.talking = b; h.post { view?.speaking = b } }
}

class HoloView(c: Context, private val body: Bitmap?, private val rig: Array<Bitmap>?) : View(c) {
    var speaking = false
        set(v) { field = v; if (v && !anim.isRunning) anim.start() }
    private var phase = 0f
    private var lvl = 0f
    private var sp = 0f   // bolne ka smooth level (0..1)
    private var arm = 0f; private var smile = 0f; private var mo = 0f; private var lastTalk = -9.0
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val mp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dst = RectF()
    private val mouthR = RectF()
    private val anim: ValueAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 5000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { va -> phase = va.animatedValue as Float; invalidate() }
    }

    private fun a(c: Int, al: Int) = (c and 0x00FFFFFF) or (al.coerceIn(0, 255) shl 24)
    private fun sn(x: Double): Float = sin(x).toFloat()

    private fun cols(): IntArray = when (Store.mode) {
        0 -> intArrayOf(0xFFFF2BD6.toInt(), 0xFFFF8AEA.toInt(), 0xFF9B3BFF.toInt())   // pink-purple
        1 -> intArrayOf(0xFF00F5FF.toInt(), 0xFF7CFFB2.toInt(), 0xFF2D7BFF.toInt())   // cyan-green
        3 -> intArrayOf(0xFF6C8CFF.toInt(), 0xFFB69CFF.toInt(), 0xFF4B5CFF.toInt())   // emotional: neela-lavender
        4 -> intArrayOf(0xFFFFB347.toInt(), 0xFFFF7AA8.toInt(), 0xFFFF5A5A.toInt())   // waiting: garam sunehri-gulabi
        5 -> intArrayOf(0xFFFF2D5F.toInt(), 0xFFFF7AA2.toInt(), 0xFFD61C8A.toInt())   // romantic: gehra gulabi-laal
        else -> intArrayOf(0xFF2D7BFF.toInt(), 0xFF00E5FF.toInt(), 0xFF7A5CFF.toInt()) // blue
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!anim.isRunning) anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        lvl += ((if (speaking) 1f else 0.7f) - lvl) * 0.07f
        val w = width.toFloat(); val h = height.toFloat()
        val col = cols()
        val rad = Math.toRadians(phase.toDouble())
        val L = lvl

        // ---- poori screen par neon roshni (kinaron se andar tak)
        val g = 0.28f * minOf(w, h)
        val pulse = 0.75f + 0.25f * sn(rad * 3)
        val ea = (150 * L * pulse).toInt()
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, g, a(col[0], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(0f, 0f, w, g, p)
        p.shader = LinearGradient(0f, h, 0f, h - g, a(col[2], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(0f, h - g, w, h, p)
        p.shader = LinearGradient(0f, 0f, g, 0f, a(col[1], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(0f, 0f, g, h, p)
        p.shader = LinearGradient(w, 0f, w - g, 0f, a(col[1], ea), 0, Shader.TileMode.CLAMP); cv.drawRect(w - g, 0f, w, h, p)

        if (Store.awNeon) {
            Aedwans.drawNeon(cv, w, h, d, col, L, phase, Aedwans.cornerPx(this, d))
        } else {
        // ---- ghoomti hui neon border
        val sg = SweepGradient(w / 2, h / 2,
            intArrayOf(col[0], a(col[0], 30), col[2], a(col[2], 30), col[1], col[0]),
            floatArrayOf(0f, .22f, .5f, .72f, .9f, 1f))
        sg.setLocalMatrix(Matrix().apply { setRotate(phase, w / 2, h / 2) })
        p.shader = sg; p.style = Paint.Style.STROKE
        val r = RectF(6 * d, 6 * d, w - 6 * d, h - 6 * d)
        for ((sw, al) in listOf(30f to 40, 16f to 95, 5f to 255)) {
            p.strokeWidth = sw * d * (1f + 0.35f * L); p.alpha = (al * L).toInt().coerceIn(0, 255)
            cv.drawRoundRect(r, 38 * d, 38 * d, p)
        }
        }
        p.shader = null; p.alpha = 255; p.style = Paint.Style.FILL

        // ---- khadi hui holo ladki (chhoti, ऊपर-daayein kone me; keyboard ke raaste me nahi)
        val bmp = body
        val (fw, fh) = Holo.box(w, h, bmp)
        val left = w - Holo.SIDE_DP * d - fw
        val bottom = Holo.TOP_DP * d + fh
        val cx = left + fw / 2f
        val by = bottom - 4 * d
        if (bmp != null) {
            sp += ((if (speaking) 1f else 0f) - sp) * 0.12f
            val cy = bottom - fh / 2f
            val tt = System.nanoTime() / 1e9
            val rawEnv = (0.25f + 0.75f * abs(sn(tt * 13))) * (0.55f + 0.45f * abs(sn(tt * 7 + 1)))

            // peeche neon glow
            p.shader = RadialGradient(cx, cy, fh * 0.55f,
                intArrayOf(a(col[1], ((70 + 60 * sp) * L).toInt()), a(col[0], (40 * L).toInt()), 0),
                floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, fh * 0.55f, p); p.shader = null

            dst.set(cx - fw / 2, bottom - fh, cx + fw / 2, bottom)
            val sc = cv.saveLayer(dst, null)
            bp.alpha = (236 + 19 * sn(rad * 11)).toInt().coerceIn(0, 255)
            if (rig != null) {
                // Chup = bilkul sthir. Bolte hi: muskaan, haath uthakar wave, sar ka jhukaav, bolta munh.
                val talking = speaking
                if (talking) lastTalk = tt
                arm += ((if (talking) 1f else 0f) - arm) * (if (talking) 0.07f else 0.035f)
                smile += ((if (talking || tt - lastTalk < 1.6) 1f else 0f) - smile) * 0.06f
                val hold = maxOf(0f, (arm - 0.85f) / 0.15f)
                val wave = sn(tt * 7.5) * hold
                val t1 = (26f + sn(tt * 3.1) * 2f * hold) * arm
                val t2 = (148f + wave * 13f) * arm
                val th = sn(tt * 1.4) * 2.6f * arm + 1.8f * smile
                val nod = abs(sn(tt * 6)) * 1.5f * arm
                mo += ((if (talking) rawEnv else 0f) - mo) * 0.45f

                val k = fw / rig[0].width
                cv.save()
                cv.translate(dst.left, dst.top); cv.scale(k, k)
                cv.drawBitmap(rig[0], 0f, 0f, bp)
                cv.save()
                cv.rotate(t1, 138f, 245f); cv.drawBitmap(rig[2], 0f, 0f, bp)
                cv.rotate(t2, 105f, 400f); cv.drawBitmap(rig[3], 0f, 0f, bp)
                cv.restore()
                cv.save()
                cv.translate(0f, nod); cv.rotate(th, 222f, 190f)
                cv.drawBitmap(rig[1], 0f, 0f, bp)
                // gaal ki laali
                for (x in floatArrayOf(203f, 242f)) {
                    p.shader = RadialGradient(x, 127f, 15f, a(0xFFFF6996.toInt(), (97 * smile).toInt()), a(0xFFFF6996.toInt(), 0), Shader.TileMode.CLAMP)
                    cv.drawCircle(x, 127f, 15f, p); p.shader = null
                }
                // muskaan ya bolta munh
                p.strokeCap = Paint.Cap.ROUND
                if (mo < 0.08f) {
                    p.style = Paint.Style.STROKE; p.strokeWidth = 1.8f; p.color = a(0xFF962846.toInt(), (242 * smile).toInt())
                    val pa = Path().apply { moveTo(212f, 135f - 2f * smile); quadTo(222f, 137f + 4f * smile, 232f, 135f - 2f * smile) }
                    cv.drawPath(pa, p)
                } else {
                    val hh = 1.2f + 5.2f * mo
                    mouthR.set(214.5f, 137.5f - hh, 229.5f, 137.5f + hh)
                    p.style = Paint.Style.FILL; p.color = 0xFF5A0B1B.toInt(); cv.drawOval(mouthR, p)
                    p.style = Paint.Style.STROKE; p.strokeWidth = 1.3f; p.color = a(0xFFBE465F.toInt(), 230); cv.drawOval(mouthR, p)
                    if (mo > 0.5f) { p.style = Paint.Style.FILL; p.color = a(0xFFFFF0F0.toInt(), 230); cv.drawRect(218f, 135.6f, 226f, 137.2f, p) }
                }
                p.style = Paint.Style.FILL; p.strokeCap = Paint.Cap.BUTT
                cv.restore()
                cv.restore()
            } else {
                // apni image: chup = sthir, bolte waqt halka hilna
                val env = sp * rawEnv
                cv.save()
                cv.translate(0f, -env * 6 * d); cv.rotate(sn(tt * 5) * 2.8f * sp, cx, bottom); cv.scale(1f, 1f + 0.022f * env, cx, bottom)
                if (bmp != null) cv.drawBitmap(bmp, null, dst, bp)
                cv.restore()
            }
            // hologram scanlines (sirf ladki ke upar)
            mp.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
            mp.style = Paint.Style.STROKE; mp.strokeWidth = 1.2f * d; mp.color = a(col[1], 55)
            var yy = dst.top + (phase / 360f) * 8 * d
            while (yy < dst.bottom) { cv.drawLine(dst.left, yy, dst.right, yy, mp); yy += 4 * d }
            mp.xfermode = null; mp.style = Paint.Style.FILL
            cv.restoreToCount(sc)

            // projector ke neeche chamakti rings
            p.style = Paint.Style.STROKE
            for (i in 0..1) {
                val rr = fw * (0.50f + 0.14f * i) + L * 3 * d * sn(rad * 6 + i)
                p.strokeWidth = 1.6f * d; p.color = a(col[0], ((200 - i * 80) * L).toInt())
                cv.drawOval(RectF(cx - rr, by - rr * 0.16f, cx + rr, by + rr * 0.16f), p)
            }
        }

        // label
        p.style = Paint.Style.FILL
        p.color = a(col[1], (230 * L).toInt()); p.textSize = 11 * d; p.textAlign = Paint.Align.CENTER
        p.letterSpacing = 0.25f
        cv.drawText("SANA  •  ${Store.modeNames[Store.mode]}", cx, by + 22 * d, p)
    }
}
